let input = [
	{
		Before: "",
		After: "Xóa",
	},
	{
		Before: ".",
		After: "Xóa",
	},
	{
		Before: "(chuyên Văn)",
		After: "Xóa",
	},
	{
		Before: "@ Vietnam Commercial University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "* Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "* Đại Học Kinh tế Quốc dân (10/2020 - 10/2025)",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "• Bachelor Of Economic, Foreign Trade University, Vietnam",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before:
			"01/2010 - NOT TRINH NGI NGUY NGI NGU NGU NGU NGU NGU NGU NGU NGU NGU NGU NGU NGU NGU NGU NGHIỆM IN ESC TR I N C I N C I N C I N",
		After: "Xóa",
	},
	{
		Before:
			"03 2020-07 2020--------Graduated From Da Nang Tester Training Center",
		After: "Xóa",
	},
	{
		Before:
			"04 2019 - Current: Operation Manager Deputy Director - Korean Construction Company",
		After: "Xóa",
	},
	{
		Before: "04 2019 05 2021  Cao đẳng Sư Phạm Trung Ương",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "05 2018  Đại Học Sư Phạm Hà Nội 2",
		After: "Đại Học Sư Phạm Hà Nội 2",
	},
	{
		Before: "05 2020 Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "05 2021 Đại Học Công Nghiệp Thực Phẩm Tp Hcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "05 2021 Đại Học Spkt Nam Định",
		After: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
	},
	{
		Before: "05 2021 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "05 2021  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "05-2020 Đại Học XÂY DỰNG",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "05-2020  Đại Học TÀI CHÍNH KẾ TOÁN",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "06 2009-8 2012 Học Tại  Cđ Bách Khoa Đà Nẵng",
		After: "Cao Đẳng Bách Khoa Đà Nẵng",
	},
	{
		Before: "06 2013 Đại Học Dân Lập Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "06 2017 Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "06 2019  Đại Học Giao Thông Vận Tải Phân Hiệu Tại Tphcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "06 2021  Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "06 2022 Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "06 2022  Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before:
			"07 2014 07 2017  Cđ Kinh Tế Kế Hoạch Đã Nẵng Chuyên Ngành Kế Toán Tổng Hợp",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: "07 2017- 05 2021 Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "07 2020 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "07 2021  Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "07 2022 Đại Học Tài Chính Ngân Hàng",
		After: "Đại Học Tài Chính - Ngân Hàng",
	},
	{
		Before: "07 2022 Đại Học Tân Trào",
		After: "Đại Học Tân Trào",
	},
	{
		Before: "07-2020 Đại Học kinh tế quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "08 2008- 01 2013 Đại Học Đà Lạt",
		After: "Đại Học Đà Lạt",
	},
	{
		Before: "08 2012- 06 2016 Đại Học Công Nghiệp Tp Hcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "08 2012-07 2016 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "08 2015 06 2019  Đại Học Sư Phạm Hà Nội",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "08 2017--05 2021 Đại Học Đại Nam",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "08 2018 10 2021 Đại Học Kinh Tế Tp Hcm Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "08 2019  Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "08 2021 Học Viện Chính Sách Và Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "08 2022 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "082014-082018 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "09 2011  06 2015  Hanoi Vietnam",
		After: "",
	},
	{
		Before: "09 2011- 06 2015 Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "09 2012 - 09 2016 Học Viện Nông Nghiệp Việt Nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "09 2014- 06 2018 Học Viện Hậu Cần",
		After: "Học Viện Hậu Cần",
	},
	{
		Before: "09 2016--11 2021 Đại Học Văn Hiến",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "09 2018  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "09 2020 Đại Học Thành Đô",
		After: "Đại Học Thành Đô",
	},
	{
		Before: "09 2022 Đại Học Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "09-2015 Đại Học DUY TÂN",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "09-2018 - Now Academy Of Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "09-2020 - 09-2022 | Cao đẳng Thực Hành FPT Polytechnic",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "09-2021 Học VIỆN TÀI CHÍNH",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "09/2015  FOREIGN TRADE UNIVERSITY",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "092009 052013  Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "1 Cao đẳng Đại Học",
		After: "",
	},
	{
		Before: "1 Cao đẳng Thương Mại Đà Nẵng",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "1 H  H N H           H   Ệ N",
		After: "",
	},
	{
		Before: "1-Medical Booking System",
		After: "",
	},
	{
		Before: "10 2008--11 2012 Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "10 2010-06 2015  Đh Công Nghiệp Tphcm Khoa Công Nghệ Thông Tin",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "10 2014-05 2018 Đại Học Công Nghiệp Hà Nội Haui",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "10 2018-12 2018------------Tester Ha Noi Center",
		After: "",
	},
	{
		Before: "10 2021  Đại Học Tài Chính Ngân Hàng Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "12 2014  Đại Học Kiến Trúc Đà Nẵng",
		After: "Đại Học Kiến Trúc Đà Nẵng",
	},
	{
		Before: "12 2021 Cao đẳng FPT Polytechnic",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "12 2021 Đại Học Công Nghiệp Thực Phẩm Tp Hcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "12 2021  Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "12 2022  Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "12-2020 Đại Học công nghiệp hà nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "12-2020  Đại Học CÔNG NGHIỆP HÀ NỘI",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "2002-2006  Đại Học Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "2004 - 2007 Saigon Technology",
		After: "Đại Học Công Nghệ Sài Gòn",
	},
	{
		Before: "2004 - 2008 Hutech University",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "2004 2007 Cao đẳng Sư Phạm",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "2006  2010   Open University",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "2006-2010-Đh Bình Dương",
		After: "Đại Học Bình Dương",
	},
	{
		Before: "2007 2011: Vinh University",
		After: "Đại Học Vinh",
	},
	{
		Before: "2007- 2009 Cao đẳng Kinh Tế Tp Hcm",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "2007-2010 | Công ty TNHH Gamuda Land Việt Nam",
		After: "",
	},
	{
		Before: "2008 2012 Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "2008- 2012 Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "2009  2013  Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2009 2013 Engineers Degree Information Technology",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2010 2014 National Economic University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "2011 2014 Đại Học Công Nghiệp Hn Hệ Liên Thông",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "2011- 2016 Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "2011-2015 Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "2012 2016 National Economics University, Hanoi, Vietnam",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "2013  2017  hanoi foreign trade university",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2013 2014 Bournemouth University",
		After: "Đại Học Bournemouth",
	},
	{
		Before: "2013 2018: Vietnam Maritime University",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "2013- 2017 Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2014-2018 Posts And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "2014-2018  Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "2014: La Trobe University Academic Excellence Scholarship",
		After: "Đại Học La Trobe",
	},
	{
		Before: "2015 Degree Of Associate Ha Noi Metropolitan University",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "2015-2017 Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "2016 2017-Thiết Kế Đồ Họa Itplus Academy",
	},
	{
		Before: "2016 2020 Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2016- 2019 University Economy Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "2016: Tốt nghiệp: Đại Học Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "2017 - 2021 National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "2017- 2021-National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"2017-Completed The Ielts Course Of The Ielts Training Center The Ielts Workshop",
	},
	{
		Before: "2018 : University Certificate",
	},
	{
		Before: "2018 2020 -  Cao đẳng THỰC HÀNH FPT POLYTECHNIC",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "2018 2022 Đại Học Luật Tphcm",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "2018 Đến Nay Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "2018- 2022 Học Viện Chính Sách Và Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "2018- 2022 Học Viện Công Nghệ Bưu Chính Viễn",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "2018- Nay Học Viện Công Nghệ Bưu",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "2019 2021 Cao đẳng Công Nghệ Thủ Đức",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "2019Achieved A Lot Of Scholarships Of Thuyloi University",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "2020 2021 Công Ty Alphawaytech",
		After: "",
	},
	{
		Before: "2020-Trade Union University",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "2021: Cử nhân Đại Học Khoa Học xã hội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "2NF GROUP",
		After: "",
	},
	{
		Before: "3 working years in logistics, import-",
		After: "",
	},
	{
		Before: "3Rd Year Student Of FPT University",
		After: "Đại Học FPT",
	},
	{
		Before: "4 Công Ty Cổ Phần Dược Phẩm Vipharco",
		After: "",
	},
	{
		Before:
			"53 Support Vision Knowledge And The Way To Reach Goals For Each Project",
		After: "",
	},
	{
		Before:
			"6 2019--2 2020 Tổng Công Ty Viễn Thông Quân Đội Viettel Chi Nhánh Telesale Miền Trung",
		After: "",
	},
	{
		Before: "7 8 2020   11 9 2020 Internship as Developer at Fsoft",
		After: "",
	},
	{
		Before: "8 2017-11 2021  Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "82 Duy Tân, Cầu Giấy, Hà Nội",
		After: "",
	},
	{
		Before: "A Joint Program With York St John University",
		After: "Đại Học York St John",
	},
	{
		Before: "A T8 Time City Hanoi",
		After: "",
	},
	{
		Before:
			"A Team Always Towards The Common Goals And Interests Of The Company",
		After: "",
	},
	{
		Before: "Ability to work with Misa software",
		After: "",
	},
	{
		Before: "Academy Bachelor",
		After: "",
	},
	{
		Before: "Academy Corporate Accounting",
		After: "",
	},
	{
		Before: "Academy Cryptography Techniques",
		After: "",
	},
	{
		Before: "Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy International Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "academy journalism",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Academy Journalism And Communication",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Academy Of",
		After: "",
	},
	{
		Before: "Academy Of Cryptography",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Academy Of Cryptography Techniques Major Cyber Security",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Academy Of Education Management Vietnam",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "academy of fianance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "ACADEMY OF FINANCE",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "ACADEMY OF FINANCE HA NOI VIETNAM",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy Of Finance Hanoi Vietnam",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy Of Finance Major Business Administration",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy Of Finance Master",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy Of Finance Masters Degree",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Academy Of Jounalism And Communication",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Academy Of Journalism And",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Academy Of Journalism And Communication",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "ACADEMY OF VIETNAM",
		After: "",
	},
	{
		Before: "Academy Policy and Development",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "ACADEMY present",
		After: "",
	},
	{
		Before: "Academy Techniques",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Academy Vinalink Dgm Litado Pti",
		After: "",
	},
	{
		Before: "Accounting",
		After: "",
	},
	{
		Before: "Acet Academy",
		After: "",
	},
	{
		Before: "ACTIVITIES",
		After: "",
	},
	{
		Before: "AD: UNMTPTRbDXITNHI2WTVY",
		After: "",
	},
	{
		Before: "AD: VLPOJAMDNIBNIBNIBH FoM AN",
		After: "",
	},
	{
		Before: "Address- Thanh Xuân Hà Nội",
		After: "",
	},
	{
		Before: "AEG MEDIA",
		After: "",
	},
	{
		Before: "Ai Viet Nam",
		After: "",
	},
	{
		Before: "Ajou University",
		After: "Đại Học Ajou",
	},
	{
		Before: "American International School",
		After: "",
	},
	{
		Before: "American Polytechnic College Apc",
		After: "Cao Đẳng Việt Mỹ",
	},
	{
		Before: "An Giang University",
		After: "Đại Học An Giang - ĐHQG TPHCM",
	},
	{
		Before: "Anhalt University Of Applied",
		After: "Đại Học Khoa Học Ứng dụng Anhalt",
	},
	{
		Before: "Applicable Documentation To The Immigration Department",
		After: "",
	},
	{
		Before: "Approtrain- Aptech",
		After: "",
	},
	{
		Before: "Aptech",
		After: "",
	},
	{
		Before: "Aptech Computer education Center",
		After: "",
	},
	{
		Before: "Aptechaptech",
		After: "",
	},
	{
		Before: "Arena Multimedia",
		After: "",
	},
	{
		Before: "Ashram And Tufts Center Engineering",
		After: "",
	},
	{
		Before: "Assistant Brand Manager",
		After: "",
	},
	{
		Before: "Associate Degree Ho Chi Minh City University Of Science Vnuhcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Association Of Chartered Certified Accountants",
		After: "",
	},
	{
		Before: "Assumption University Abac Graduate School Of",
		After: "Đại Học Assumption",
	},
	{
		Before: "Assumption University Of Thailand",
		After: "Đại Học Assumption",
	},
	{
		Before: "at College Of Foreign Economics Relation",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "At Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Auckland University",
		After: "Đại Học Auckland",
	},
	{
		Before: "Audiovisual Industry, Media",
		After: "",
	},
	{
		Before: "Audit",
		After: "",
	},
	{
		Before: "Auditing- National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Auditing-International Accounting",
		After: "",
	},
	{
		Before: "Augustana College",
		After: "Cao Đẳng Augustana",
	},
	{
		Before: "B1-Đại Học Sư Phạm",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "BA English 2011 Ha Noi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Bà Rịa- Vũng Tàu University",
		After: "Đại Học Bà Rịa - Vũng Tàu",
	},
	{
		Before: "Bac Ha International University",
		After: "Đại Học Quốc Tế Bắc Hà",
	},
	{
		Before: "Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Bách khoa Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bach Khoa Book Lovers Club",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Bach Khoa Education Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Bách khoa HN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Bach Khoa University",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Bách khoa-aptech",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "bachelor   international school   hanoi national university",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Bachelor - Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Bachelor Banking Academy",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Bachelor Degree Of Finance - Marketing University",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Bachelor Degree Of Hcm University Of Industry",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Bachelor Degree-Ho Chi Minh Open University Ho Chi Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Bachelor Hanoi University Of Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before:
			"Bachelor Of Commerce Marketing Major Curtin University Of Technology Perth Australia",
		After: "Đại Học Curtin",
	},
	{
		Before: "Bachelor Of Commerce, University Of Melbourne",
		After: "Đại Học Melbourne",
	},
	{
		Before:
			"Bachelor Of Development Economic, University Of Business And Economic",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before:
			"Bachelor Of Economics - National Economics University, Hanoi, Vietnam",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Bachelor Of Economics - University Queensland",
		After: "Đại Học Queensland",
	},
	{
		Before: "Bachelor Of Economics | National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Bachelor Of Economics- International Economics",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "bachelor of english language teacher education",
		After: "",
	},
	{
		Before: "bachelor of information technology",
		After: "",
	},
	{
		Before: "Bachelor Of International Affair",
		After: "",
	},
	{
		Before: "Bachelor Of International Business",
		After: "",
	},
	{
		Before: "Bachelor Of International Business Economics",
		After: "",
	},
	{
		Before:
			"Bachelor Of International Business Economics Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Bachelor Of International Business English",
		After: "",
	},
	{
		Before: "Bachelor Of International Economic",
		After: "",
	},
	{
		Before: "Bachelor Of International Economics, Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "bachelor of it at cantho university",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Bachelor Of It, Rmit International University Vietnam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Bachelor Of Law - Vietnam National University",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Bachelor Of Science- Information System",
		After: "",
	},
	{
		Before: "Bachelor Of Science- Le Mans University Affiliate Program",
		After: "Đại Học Le Mans",
	},
	{
		Before:
			"Bachelor Of Scientist Computer Posts And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Bachelor Of Technology",
		After: "",
	},
	{
		Before: "Bachelor Of Technology- Btech Information Technology",
		After: "",
	},
	{
		Before: "Bachelor Of Thuong Mai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Bachelor Science Of Computing-University Of Greenwich England",
		After: "Đại Học Greenwich London",
	},
	{
		Before: "Bachelor- Ho Chi Minh City University Of Food Industry",
		After: "Đại Học Công Thương TPHCM",
	},
	{
		Before: "Bachelor- Ho Chi Minh City University Of Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Bachelor- Khóa 19- Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Bachelor-Mar 2021-University Of Economics Ho Chi Minh City",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Bachelor-Of Academy Journalism",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Bachelor-The Sai Gon International University Ho Chi Minh City",
		After: "Đại Học Quốc Tế Sài Gòn",
	},
	{
		Before: "Bachelor, Hanoi University Science And Technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "BACHELOROFACADEMY OF FINANCE",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Bachelors Banking Academy",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Bachelors Degree- Hanoi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Bachelors Hanoi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Bachelors School Of Foreign Languages Thai Nguyen University",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Bachelors Thuongmai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Bachelors- Delaware County Community College The",
		After: "Cao Đẳng Cộng Đồng Quận Delaware",
	},
	{
		Before: "Bachelors- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Bachelors- Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Bachelors- Đại Học Thăng Long",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Bachelors- Gujarat University",
		After: "Đại Học Gujarat",
	},
	{
		Before: "Bachelors- Hanoi University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Bachelors- Học Viện Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Bachelors- Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Bachelors- Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Bachelors-  Đại Học Ngoại Ngữ",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Bachelors- University Ain Temouchent Belhadj Bouchaib",
		After: "Đại Học Ain Temouchent",
	},
	{
		Before: "Bachelors- University Finance And Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Bachelors- University Of Labour Social Affairs",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "bachkhoa aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bachkhoa Aptech Education",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bachkhoa Aptech Education System",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bachkhoa- Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Bachkhoa-Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Baking Academy",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Ban Cao đẳng Đại Học Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Ban Chấp Hành Khoa Qtkd",
		After: "",
	},
	{
		Before: "Bank Việt Nam",
		After: "",
	},
	{
		Before: "Banking Academy",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking Academy Dong Da",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking Academy Ha Noi",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking Academy Major International Business",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking Academy Of Vietnam",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking And Finance Cardiff University",
		After: "Đại Học Cardiff",
	},
	{
		Before: "banking university",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Banking University Hcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University HCM City",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Hcmc",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "banking university hochiminh city",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Hcm City",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Hcmc",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Hcmcity",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Ho Chi Minh City",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before:
			"Banking University Of Ho Chi Minh City Bachelor Of Banking And Finance",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Ho Chi Minh City Ho Chi Minh City",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Banking University Of Hochiminh City",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Baolien220600@Gmail.Com",
		After: "",
	},
	{
		Before: "Baruch College",
		After: "Cao đẳng Baruch",
	},
	{
		Before: "Bằng Cử Nhân Đại Học Công Nghệ Tphcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Bằng Đại Học Kinh Tế Và Quản Lý",
		After: "",
	},
	{
		Before: "Bằng Tiếng Anh B2 Của  Đại Học Ngoại Ngữ Huế Cấp",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before:
			"Being on the list of students to be rewarded in 2019 2020 by the University",
		After: "",
	},
	{
		Before: "Benedictine University Usa Vietnam",
		After: "Đại Học Benedictine",
	},
	{
		Before: "Bệnh Viện Máy Tính Quốc Tế I Care",
		After: "",
	},
	{
		Before:
			"Bí Thư Lớp Sinh Viên Ủy Viên Ban Chấp Hành Đoàn  Cao đẳng Cộng Đồng Hà Nội",
		After: "Cao Đẳng Cộng Đồng Hà Nội",
	},
	{
		Before: "BINGHAMTON UNIVERSITY",
		After: "Đại Học Binghamton",
	},
	{
		Before: "Binh Duong University",
		After: "Đại Học Bình Dương",
	},
	{
		Before: "Binh Duong University Major",
		After: "Đại Học Bình Dương",
	},
	{
		Before: "Birmingham City University Uk",
		After: "Đại Học Thành Phố Birmingham",
	},
	{
		Before: "Bkacad Academy Technology",
		After: "Học Viện Công Nghệ Bkacad",
	},
	{
		Before: "Bkacad Information Technology Academy",
		After: "Học Viện Công Nghệ Bkacad",
	},
	{
		Before: "Blue Mountains International Hotel",
		After: "",
	},
	{
		Before: "Bournemouth University",
		After: "Đại Học Bournemouth",
	},
	{
		Before: "Bournemouth University, United Kingdom",
		After: "Đại Học Bournemouth",
	},
	{
		Before: "Bộ phận khác khách hàng và nhà cung cấp",
		After: "",
	},
	{
		Before: "Bộ Tài Chính",
		After: "",
	},
	{
		Before: "BPP University",
		After: "Đại Học BPP ",
	},
	{
		Before: "Brand Communications Academy Oct",
		After: "",
	},
	{
		Before: "British University Vietnam",
		After: "Đại Học Anh Quốc",
	},
	{
		Before: "Bsoft Company",
		After: "",
	},
	{
		Before: "BTEC FPT International College",
		After: "Cao Đẳng Anh Quốc BTEC FPT",
	},
	{
		Before: "Build Sustainable Brand By International Standard Class",
		After: "",
	},
	{
		Before: "Business & Hotel Management School",
		After: "",
	},
	{
		Before: "Business Administration National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Business Administration Southampton Solent University England Erasmus Exchange Program",
		After: "Đại Học Solent",
	},
	{
		Before: "Business Analysis Academy",
		After: "",
	},
	{
		Before: "Business Analysis Academy Major Standard It Ba",
		After: "",
	},
	{
		Before: "Business Analytics",
		After: "",
	},
	{
		Before: "Business And Technology University",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Business English Department",
		After: "",
	},
	{
		Before: "Business English Thuong Mai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "bưu chính viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Camlinhlai27Gmailcom",
		After: "",
	},
	{
		Before: "Can Tho University",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Can Tho University August",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Can Tho University Can Tho",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Can Tho University May",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Can Tho University, Viet Nam",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Cantho University",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Cao",
		After: "",
	},
	{
		Before: "Cao Ba Quat Highschool",
		After: "",
	},
	{
		Before: "Cao Dang Cong Nghe-Ha Noi- Information Technology",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "Cao dàng FPT Polyechme",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao dẳng kinh tế đối ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng",
		After: "",
	},
	{
		Before: "Cao đẳng ( Đang Học ) 2021-2022",
		After: "",
	},
	{
		Before: "Cao đẳng | 09/2019---05/2022",
		After: "",
	},
	{
		Before: "Cao đẳng Anh Quốc Btec FPT",
		After: "Cao Đẳng Anh Quốc BTEC FPT",
	},
	{
		Before: "Cao đẳng Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Cao đẳng asean",
		After: "Cao Đẳng Y Dược Asean",
	},
	{
		Before: "Cao đẳng Bác Khoa",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: "Cao đẳng Bách Khoa",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: "Cao đẳng Bách Khoa Đà Nẵng",
		After: "Cao Đẳng Bách Khoa Đà Nẵng",
	},
	{
		Before: "Cao đẳng bách khoa hà nội",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: "Cao đẳng Bách Khoa Hưng Yên",
		After: "Cao Đẳng Bách Khoa Hưng Yên",
	},
	{
		Before: "Cao đẳng Bách Nghệ Hải Phòng",
		After: "Cao Đẳng Bách Nghệ Hải Phòng",
	},
	{
		Before: "Cao đẳng Bách Việt",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: "Cao đẳng Bán Công Công Nghệ Và Quản Trị Doanh",
		After: "Cao Đẳng Ctim",
	},
	{
		Before: "Cao đẳng Bán Công Công Nghệ Và Quản Trị Doanh Nghiệp",
		After: "Cao Đẳng Ctim",
	},
	{
		Before: "Cao đẳng Bình Định",
		After: "Cao Đẳng Bình Định",
	},
	{
		Before: "Cao đẳng Cao đẳng Công Nghiệp Hải Phòng",
		After: "Cao Đẳng Công Nghiệp Hải Phòng",
	},
	{
		Before: "Cao đẳng Cao đẳng Công Nghiệp Huế",
		After: "Cao Đẳng Công Nghiệp Huế",
	},
	{
		Before: "Cao đẳng Cao đẳng Du Lịch",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Cao đẳng Du Lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Cao đẳng Kinh Tế Công Nghệ Tphcm",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Cao đẳng Kinh Tế Đối Ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Cao đẳng Kinh Tế Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Cao đẳng Kỹ Thuật Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: "Cao đẳng Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: "Cao đẳng Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Cao đẳng Cần Thơ 2017 - 2020",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Cao đẳng CĐ thực hành FPT Polytechnic",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Cao đẳng Chính Quy",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng chuyên ngành qtkd",
		After: "",
	},
	{
		Before: "Cao đẳng cn bách khoa hà nội",
		After: "Cao Đẳng Công Nghệ Bách Khoa Hà Nội",
	},
	{
		Before: "Cao đẳng CNTT Đà Nẵng",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Cao đẳng CNTT HỮU NGHỊ VIỆT HÀN",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Cao đẳng CNTT Tphcm",
		After: "#N/A",
	},
	{
		Before: "Cao đẳng cộng đồng Cà Mau",
		After: "Cao Đẳng Cộng Đồng Cà Mau",
	},
	{
		Before: "Cao đẳng Cộng Đồng Đồng Tháp",
		After: "Cao Đẳng Cộng Đồng Đồng Tháp",
	},
	{
		Before: "Cao đẳng Cộng Đồng Hà Nội",
		After: "Cao Đẳng Cộng Đồng Hà Nội",
	},
	{
		Before: "Cao đẳng cộng đồng lào cai",
		After: "Cao Đẳng Cộng Đồng Lào Cai",
	},
	{
		Before: "Cao đẳng Cộng Đồng, Quản Trị Kinh Doanh",
		After: "Cao Đẳng Cộng Đồng Hà Nội",
	},
	{
		Before: "Cao đẳng Công Nghệ",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "Cao đẳng Công Nghệ & Kinh tế Công Nghiệp, Chuyên",
		After: "Cao Đẳng Công Nghệ & Kinh Tế Công Nghiệp",
	},
	{
		Before: "Cao Đăng Công Nghệ & Quản Trị Doanh Nghiệp",
		After: "Cao Đẳng Công Nghệ Quản Trị Doanh Nghiệp",
	},
	{
		Before: "Cao đẳng Công Nghệ Bách Khoa Hà Nội",
		After: "Cao Đẳng Công Nghệ Bách Khoa Hà Nội",
	},
	{
		Before: "Cao đẳng Công Nghệ Cao Đồng An",
		After: "Cao Đẳng Công Nghệ Cao Đồng An",
	},
	{
		Before: "Cao đẳng Công Nghệ Cao Hà Nội",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "Cao đẳng Công Nghệ Đà Nẵng",
		After: "Cao Đẳng Công nghệ - ĐH Đà Nẵng",
	},
	{
		Before: "Cao đẳng Công Nghệ Hà Nội",
		After: "#N/A",
	},
	{
		Before: "Cao đẳng Công nghệ Kinh tế Công nghiệp",
		After: "Cao Đẳng Công nghệ Và Kinh tế Công nghiệp",
	},
	{
		Before: "Cao đẳng Công Nghệ Thông Tin",
		After: "#N/A",
	},
	{
		Before: "Cao đẳng Công Nghệ Thông Tin Đại Học Đà Nẵng",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Cao đẳng Công Nghệ Thông Tin Tp Hồ Chí Minh",
		After: "#N/A",
	},
	{
		Before: "Cao đẳng Công Nghệ Thủ Đức",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Cao đẳng Công Nghệ Thủ Đức Quản Trị Khách Sạn",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Cao đẳng Công Nghệ Thương Mại Hà Nội",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: "Cao đẳng Công nghệ TPHCM",
		After: "Cao Đẳng Công nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Công Nghệ Và Kinh Tế Bảo Lộc",
		After: "#N/A",
	},
	{
		Before: "Cao đẳng Công Nghệ Và Kinh Tế Công Nghiệp",
		After: "Cao Đẳng Công nghệ Và Kinh tế Công nghiệp",
	},
	{
		Before: "Cao đẳng Công Nghệ Và Kinhtế Công Nghiệp",
		After: "Cao Đẳng Công nghệ Và Kinh tế Công nghiệp",
	},
	{
		Before: "Cao đẳng Công nghệ và Thương mại",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: "Cao đẳng CÔNG NGHỆ VÀ THƯƠNG MẠI HÀ NỘI",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before:
			"Cao Đằng Công Nghệ Và Thương Mại Hà Nội | Chuyên Ngành: Quản Trị Kinh Doanh",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: "Cao đẳng công nghệ Việt Hàn Đà Nẵng",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Cao đẳng CÔNG NGHIỆP",
		After: "Cao Đẳng Nghề Công Nghiệp Hà Nội",
	},
	{
		Before: "Cao đẳng Công Nghiệp Hưng Yên",
		After: "Cao Đẳng Công Nghiệp Hưng Yên",
	},
	{
		Before: "Cao đẳng Công nghiệp Phúc Yên",
		After: "Cao Đẳng Công Nghiệp Hưng Yên",
	},
	{
		Before: "Cao đẳng Công Nghiệp Quốc Phòng",
		After: "Cao Đẳng Công Nghiệp Quốc Phòng",
	},
	{
		Before: "Cao đẳng công nghiệp tuy hòa",
		After: "Cao Đẳng Công Thương Miền Trung",
	},
	{
		Before: "Cao đẳng Công Nghiệp Và Thương Mại Hà Nội",
		After: "Cao Đẳng Công Nghiệp Và Thương Mại Hà Nội",
	},
	{
		Before: "Cao đẳng công thương",
		After: "Cao Đẳng Công Thương Hà Nội",
	},
	{
		Before: "Cao đẳng Công Thương Hà Nội",
		After: "Cao Đẳng Công Thương Hà Nội",
	},
	{
		Before: "Cao đẳng Công Thương Hcm",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương TPHCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương Tp Hcm",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương Tp Hồ Chí Minh",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng công thương tp. Hcm",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương Tp. Hồ Chí Minh",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương TPHCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương TPHCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương Tphcm Kế Toán Tài Chính",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "Cao đẳng Công Thương Việt Nam",
		After: "Cao Đẳng Công Thương Việt Nam",
	},
	{
		Before: "Cao đẳng Cơ Điện Hà Nội",
		After: "Cao Đẳng Cơ Điện Hà Nội",
	},
	{
		Before: "Cao đẳng DH Nong Lam Tp hcm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Cao đẳng Dịch vụ pháp lý",
		After: "",
	},
	{
		Before: "Cao đẳng du lịch",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Du Lịch Cần Thơ",
		After: "Cao Đẳng Du Lịch Cần Thơ",
	},
	{
		Before: "Cao đẳng du lịch Đà Nẵng",
		After: "Cao Đẳng Du Lịch Đà Nẵng",
	},
	{
		Before: "Cao đẳng Du Lịch Đà Nẵng Chuyên Ngành Quản Trị Khu",
		After: "Cao Đẳng Du Lịch Đà Nẵng",
	},
	{
		Before: "Cao đẳng Du Lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Du Lịch Huế",
		After: "Cao Đẳng Du Lịch Huế",
	},
	{
		Before: "Cao đẳng Du Lịch Sài Gòn",
		After: "Cao Đẳng Du Lịch Sài Gòn",
	},
	{
		Before: "Cao đẳng Du Lịch Và Thương Mại",
		After: "Cao Đẳng Công Nghiệp Và Thương Mại Hà Nội",
	},
	{
		Before: "Cao đẳng dược",
		After: "Cao Đẳng Dược Hà Nội",
	},
	{
		Before: "Cao đẳng dược hà nội",
		After: "Cao Đẳng Dược Hà Nội",
	},
	{
		Before: "Cao đẳng Dược Phú Thọ",
		After: "Cao Đẳng Dược Phú Thọ",
	},
	{
		Before: "Cao đẳng Đại Học Công Nghệ Tp Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng đai Học công nghiệp hà nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Cao đẳng Đại Học Công Nghiệp Tp Hcm Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Cao đẳng Đại Học Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Cao đẳng Đại Học Khác",
		After: "",
	},
	{
		Before: "Cao đẳng Đai Học Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Cao đẳng Đại Việt",
		After: "Cao Đẳng Đại Việt Sài Gòn",
	},
	{
		Before: "Cao đẳng Đại Việt Sài Gòn",
		After: "Cao Đẳng Đại Việt Sài Gòn",
	},
	{
		Before: "Cao đẳng Điện Lạnh Hà Nội",
		After: "Cao Đẳng Điện Tử - Điện Lạnh Hà Nội",
	},
	{
		Before: "Cao đẳng Điện Lạnh Hà Nội",
		After: "Cao Đẳng Điện Tử - Điện Lạnh Hà Nội",
	},
	{
		Before: "Cao đẳng Đông Á",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "Cao đẳng Đức",
		After: "",
	},
	{
		Before: "Cao đẳng FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Cao đẳng FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "Cao đẳng FPT Polytechnic",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Digital Marketing",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Hà Nội",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Hcm",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Marketing Sale",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Tây Nguyên",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnic Thiết Kế Website",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Polytechnich Chuyên Ngành Digital Marketing",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Quản Trị Doanh Nghiệp",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng FPT Tây Nguyên Quản Trị Doanh Nghiệp",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng GIAO THÔNG VẬN TẢI",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cao đẳng Giao Thông Vận Tải Tp Hcm",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cao đẳng Giao Thông Vận Tải Tphcm",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cao đẳng Giao Thông Vận Tải Trung",
		After: "Cao Đẳng Giao Thông Vận Tải Trung Ương",
	},
	{
		Before: "Cao đẳng Giao Thông Vận Tải Trung Ương Iii",
		After: "Cao Đẳng Giao Thông Vận Tải Trung Ương",
	},
	{
		Before: "Cao đẳng Giao Thông Vận Tải Trung Ương Iv",
		After: "Cao Đẳng Giao Thông Vận Tải Trung Ương",
	},
	{
		Before: "Cao đẳng Giờ Là  Đại Học Thủ Đô Hà Nội",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "Cao đẳng Gtvt",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cao đẳng Gtvt Đường Thủy Ii",
		After: "Cao Đẳng Giao Thông Vận Tải Đường Thủy II",
	},
	{
		Before: "Cao đẳng Hàng Hải",
		After: "Cao Đẳng Hàng Hải",
	},
	{
		Before: "Cao đẳng hệ chính quy Ngành kế toán doanh nghiệp tại  Đại Học Tài",
		After: "",
	},
	{
		Before: "Cao đẳng Hòa Bình Xuân Lộc",
		After: "Cao Đẳng Hòa Bình Xuân Lộc",
	},
	{
		Before: "Cao đẳng Học Viện Ktqs Hà Nội",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Cao đẳng Hồ Chí Minh",
		After: "",
	},
	{
		Before: "Cao đẳng KẾ TOÁN",
		After: "",
	},
	{
		Before: "Cao đẳng Kế Toán Quảng Ngãi",
		After: "Cao Đẳng Quảng Ngãi",
	},
	{
		Before: "Cao đẳng kĩ thuật cao thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: "Cao đẳng Kiên Giang",
		After: "Cao Đẳng Kiên Giang",
	},
	{
		Before: "Cao đẳng Kinh",
		After: "",
	},
	{
		Before: "Cao đẳng kinh kế kỹ thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: "Cao đẳng Kinh Tế",
		After: "",
	},
	{
		Before: "Cao đẳng kinh tế - công nghệ TPHCM",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Kinh tế - Kế hoạch Đà Nẵng",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "Cao đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Cần Thơ",
	},
	{
		Before: "Cao đẳng Kinh tế - Kỹ thuật Hòa Bình",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Hòa Bình",
	},
	{
		Before: "Cao đẳng Kinh tế - Kỹ thuật TpHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế công nghệ",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Công Nghệ Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghệ Hà Nội",
	},
	{
		Before: "Cao đẳng kinh tế công nghệ TP HCM",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Công Nghệ Tp Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế công nghệ tpcm",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng KINH TẾ CÔNG NGHỆ TPHCM",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: "Cao đẳng Kinh tế Công nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại Kế Toán",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại Marketing Thương Mại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại Quản Trị Doanh Nghiệp Thương Mai",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại Quản Trị Kinh",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại TPHCM",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng kinh tế đối ngoại tp hồ chí minh",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng Kinh Tế Đối Ngoại Tphcm",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Cao đẳng kinh tế hà nội",
		After: "",
	},
	{
		Before: "Cao đẳng kinh tế hoạch đà nẵng",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "Cao đẳng Kinh tế Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kế Hoạch",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "Cao đẳng kinh tế kế hoạch đà nẵng",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "Cao đẳng Kinh Tế Kế Hoạch Đà Nẵng Kế Toán",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "Cao đẳng kinh tế kĩ thuật",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế kĩ thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: "Cao đẳng kinh tế kĩ thuật Kiên Giang",
		After: "Cao Đẳng Kiên Giang",
	},
	{
		Before: "Cao đẳng Kinh Tế Kĩ Thuật Thương Mại",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Thương Mại",
	},
	{
		Before: "Cao đăng kinh tê Kon Tum",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Kon Tum",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng KINH TẾ KỸ THUẬT CẦN THƠ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật miền nam",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Nghệ An",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Nghệ An",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật phú lâm",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật quảng nam",
		After: "Cao Đẳng Quảng Nam",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Thái Nguyên",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật - ĐH Thái Nguyên",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật TPHCM",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Thương Mại",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Thương Mại",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật tp",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật tp hcm cơ sở bình dương",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Tp Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Tphcm",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Trung Ương",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: "Cao đẳng kinh tế kỹ thuật tw",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: "Cao đẳng Kinh Tế Kỹ Thuật Vinatex",
		After: "Cao Đẳng Nghề Kinh Tế Kỹ Thuật Vinatex",
	},
	{
		Before: "Cao đẳng Kinh tế Kỹ thuật Vinatex TPHCM",
		After: "Cao Đẳng Nghề Kinh Tế Kỹ Thuật Vinatex",
	},
	{
		Before: "Cao đẳng Kinh Tế Nghệ An",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Nghệ An",
	},
	{
		Before: "Cao đẳng Kinh Tế Tài Chính Thái Nguyên",
		After: "Cao Đẳng Kinh Tế - Tài Chính Thái Nguyên",
	},
	{
		Before: "Cao đẳng Kinh Tế Tài Chính Vĩnh Long",
		After: "Cao Đẳng Kinh Tế Tài Chính Vĩnh Long",
	},
	{
		Before: "Cao đẳng kinh tế thành phố HCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Thành Phố Hồ Chí",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng KINH TẾ TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế TPHCM Kinh Doanh Thương Mại",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Kinh Tế Tp Hcm",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế tp hồ chí minh",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng Kinh tế TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng kinh tế TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng KINH TẾ TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Cao đẳng KINH TẾ VÀ CÔNG NGHIỆP HÀ NỘI",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "Cao đẳng Kinh Tếtphcm Quản Trị Kinh Doanh",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Kt Kt Miền Nam",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Ktcn",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Cao đẳng KỸ",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Cao đẳng Kỹ Nghệ Ii",
		After: "Cao Đẳng Kỹ Nghệ Ii",
	},
	{
		Before: "Cao đẳng Kỹ Thuật Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: "Cao đẳng kỹ thuật đồng nai",
		After: "Cao Đẳng Kỹ Thuật Đồng Nai",
	},
	{
		Before: "Cao đẳng Kỹ Thuật Trang Thiết Bị Y Tế",
		After: "Cao Đẳng Kỹ Thuật Trang Thiết Bị Y Tế",
	},
	{
		Before: "Cao đẳng Lạc Việt",
		After: "Cao Đẳng Lạc Việt ",
	},
	{
		Before: "Cao đẳng Lương Thực Thực Phẩm",
		After: "Cao Đẳng Lương Thực Thực Phẩm",
	},
	{
		Before: "Cao đẳng Lý Tự Trọng",
		After: "Cao Đẳng Lý Tự Trọng TPHCM",
	},
	{
		Before: "Cao đẳng Lý Tự Trọng Kế Toán Doanh Nghiệp",
		After: "Cao Đẳng Lý Tự Trọng TPHCM",
	},
	{
		Before: "Cao đẳng Marketing Executive",
		After: "",
	},
	{
		Before: "Cao đẳng Miền Nam",
		After: "",
	},
	{
		Before: "Cao đẳng Ngân Hàng Phân Viện Bắc Ninh",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Cao đẳng nghê an giang",
		After: "Cao Đẳng Nghề An Giang",
	},
	{
		Before: "Cao đẳng Nghề Bách Khoa",
		After: "Cao Đẳng Nghề Bách Khoa Hà Nội",
	},
	{
		Before: "Cao đẳng Nghề Bách Khoa Hà Nội",
		After: "Cao Đẳng Nghề Bách Khoa Hà Nội",
	},
	{
		Before: "Cao đẳng Nghề CNTT",
		After: "",
	},
	{
		Before: "Cao đẳng Nghề Công Nghệ Cao Hà Nội",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "Cao đẳng Nghề Công Nghệ Việt Hàn Bắc Giang",
		After: "Cao Đẳng Nghề Công Nghệ Việt - Hàn Bắc Giang",
	},
	{
		Before: "Cao đẳng Nghề Du Lịch Sài Gòn",
		After: "Cao Đẳng Nghề Du Lịch Sài Gòn",
	},
	{
		Before: "Cao đẳng Nghề Du Lịch Sài Gòn Quản Trị Nhà Hàng Khách Sạn",
		After: "Cao Đẳng Nghề Du Lịch Sài Gòn",
	},
	{
		Before: "Cao đẳng nghề đà nẵng",
		After: "Cao Đẳng Nghề Đà Nẵng",
	},
	{
		Before: "Cao đẳng nghề giao thông vận tải trung ương 3",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cao đẳng NGHỀ HÀNG HẢI",
		After: "",
	},
	{
		Before: "Cao đẳng Nghề Ispace",
		After: "Cao Đẳng An Ninh Mạng iSPACE",
	},
	{
		Before: "Cao đẳng Nghề Kế Toán  Đại Học Công Nghiêp Hà Nôi",
		After: "",
	},
	{
		Before: "Cao đẳng Nghề Kỹ Thuật Công Nghệ Tphcm",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Cao đẳng Nghề Phú Châu",
		After: "",
	},
	{
		Before: "Cao đẳng Nghề Số",
		After: "",
	},
	{
		Before: "Cao đẳng nghề số 8",
		After: "",
	},
	{
		Before: "Cao đẳng nghề thành phố HCM",
		After: "Cao Đẳng Nghề TPHCM",
	},
	{
		Before: "Cao đẳng Nghề TPHCM",
		After: "Cao Đẳng Nghề TPHCM",
	},
	{
		Before: "Cao đẳng Nghệ Thuật Hà Nội",
		After: "Cao Đẳng Nghệ Thuật Hà Nội",
	},
	{
		Before: "Cao đẳng nghề tp hồ chí minh",
		After: "Cao Đẳng Nghề TPHCM",
	},
	{
		Before: "Cao đẳng Nghề Vtc",
		After: "",
	},
	{
		Before: "Cao đẳng ngoại ngữ và công nghệ Việt Nam",
		After: "Cao Đẳng Ngoại Ngữ Và Công Nghệ Việt Nam",
	},
	{
		Before: "Cao đẳng Ngoại thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cao đẳng NIIT Cần Thơ",
		After: "",
	},
	{
		Before: "Cao đẳng Ninh Thuận",
		After: "Cao Đẳng Nghề Ninh Thuận",
	},
	{
		Before: "Cao đẳng Nova",
		After: "Cao Đẳng Nova",
	},
	{
		Before: "Cao đẳng Phát Thanh Truyền Hình I khóa",
		After: "Cao Đẳng Phát Thanh - Truyền Hình I",
	},
	{
		Before: "Cao đẳng Phát Thanh Truyền Hình Ii",
		After: "Cao Đẳng Phát Thanh - Truyền Hình II",
	},
	{
		Before: "Cao đẳng Phuơng Đong Đà Nẵng",
		After: "Cao Đẳng Phương Đông Đà Nẵng",
	},
	{
		Before: "Cao đẳng PHƯƠNG ĐÔNG - ĐÀ NẴNG",
		After: "Cao Đẳng Phương Đông Đà Nẵng",
	},
	{
		Before: "Cao đẳng Phương Đông Kế Toán Tổng Hợp",
		After: "Cao Đẳng Phương Đông Đà Nẵng",
	},
	{
		Before: "Cao đẳng Quản Trị Doanh Nghiệp Thương Mại",
		After: "",
	},
	{
		Before: "Cao đẳng Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Cao đẳng Quản Trị Nhà Hàng",
		After: "",
	},
	{
		Before: "Cao đẳng Quốc Tế Btec FPT",
		After: "Cao Đẳng Anh Quốc BTEC FPT",
	},
	{
		Before: "Cao đẳng Quốc Tế Kent",
		After: "Cao Đẳng Quốc tế KENT",
	},
	{
		Before: "Cao đẳng Quốc Tế Thành Phố Hồ",
		After: "Cao Đẳng Quốc Tế TPHCM",
	},
	{
		Before: "Cao đẳng Quốc Tế Tp Hồ Chí Minh",
		After: "Cao Đẳng Quốc Tế TPHCM",
	},
	{
		Before: "Cao đẳng quốc tế tphcm",
		After: "Cao Đẳng Quốc Tế TPHCM",
	},
	{
		Before: "Cao đẳng Sài Gòn",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: "Cao đẳng Sài Gòn Act",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: "Cao đẳng South Seattle Community College",
		After: "Cao Đẳng Cộng Đồng South Seattle",
	},
	{
		Before: "Cao đẳng Sư Phạm",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "Cao đẳng Sư Phạm Hà Nội",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "Cao đẳng Sư Phạm Kiên Giang",
		After: "Cao Đẳng Sư Phạm Kiên Giang",
	},
	{
		Before: "Cao đẳng sư phạm trung ương",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "Cao đẳng Tài Chính Hải Quan",
		After: "Cao Đẳng Tài Chính Hải Quan",
	},
	{
		Before: "Cao đẳng Tài Chính Hải Quan Kế Toán Doanh Nghiệp",
		After: "Cao Đẳng Tài Chính Hải Quan",
	},
	{
		Before: "Cao đẳng Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Cao đẳng Tài Chính Ngân Hàng Tphcm",
		After: "",
	},
	{
		Before: "Cao đẳng Tài Chính Quản Trị Kinh Doanh",
		After: "Cao Đẳng Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: "Cao đẳng thái bình",
		After: "Cao Đẳng Nghề Thái Bình",
	},
	{
		Before: "Cao đẳng Thực Hành F FPT Polyt",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng thực hành FPT",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng thực hành FPT Cần Thơ",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng THỰC HÀNH FPT POLYTECHNIC",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng thực hành FPT polytechnic cần thơ",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng Thực Hành FPT Polytechnic Hà Nội",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng Thực Hành FPT Polytechnic Marketing Sales",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng Thực Hành FPT Skillking",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng Thực Hành FPT Trực Thuộc Đh FPT",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Cao đẳng THƯƠNG MẠI",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "Cao đẳng Thương Mại | Quản Trị Dịch Vụ Du Lịch Và",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "Cao đẳng thương mại đà nẵng",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "Cao đẳng Thương Mại Kế Toán Doanh Nghiệp",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "Cao đẳng thương mại và du lịch",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Thương Mại Và Du Lịch Hà Nội",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Thương Mại Và Du Lịch Quản Trị Kinh Doanh",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "Cao đẳng Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Cao đẳng Trung Cấp Quản Trị Khách Sạn Nghiệp Vụ Lễ Tân",
		After: "",
	},
	{
		Before: "Cao đẳng Truyền Hình",
		After: "Cao Đẳng Truyền Hình",
	},
	{
		Before: "Cao đẳng  Đại Học Công Nghiệp Tphcm Chuyên Ngành Kế Toán",
		After: "",
	},
	{
		Before: "Cao đẳng Văn Hóa Nghệ Thuật Du Lịch Sài Gòn",
		After: "Cao Đẳng Văn Hóa Nghệ Thuật Và Du Lịch Sài Gòn",
	},
	{
		Before: "Cao đẳng văn hóa nghệ thuật Đà Năng",
		After: "Cao Đẳng Văn Hóa Nghệ Thuật Đà Nẵng",
	},
	{
		Before: "Cao đẳng về Kế Toán Doanh Nghiệp",
		After: "",
	},
	{
		Before: "Cao đẳng Về Kỹ Thuật Xây Dựng",
		After: "Cao Đẳng Xây Dựng Số 1",
	},
	{
		Before: "Cao đẳng viễn đông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: "Cao đẳng viễn thông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: "Cao đẳng Việt Mỹ",
		After: "Cao Đẳng Việt Mỹ",
	},
	{
		Before: "Cao đẳng X Đại Học",
		After: "",
	},
	{
		Before: "Cao đẳng Xây Dựng",
		After: "Cao Đẳng Xây Dựng Số 1",
	},
	{
		Before: "Cao đẳng Xây Dựng Số",
		After: "Cao Đẳng Xây Dựng Số 1",
	},
	{
		Before: "Cao đẳng Xây Dựng Số 1",
		After: "Cao Đẳng Xây Dựng Số 1",
	},
	{
		Before: "Cao đẳng xây dựng TPHCM",
		After: "Cao Đẳng Xây Dựng TPHCM",
	},
	{
		Before: "Cao đẳng Xây Dựng Tp Hồ Chí Minh",
		After: "Cao Đẳng Xây Dựng TPHCM",
	},
	{
		Before: "Cao đẳng Xây Dựng Tp Hồ Chí Minh Kế Toán",
		After: "Cao Đẳng Xây Dựng TPHCM",
	},
	{
		Before: "Cao đẳng Xây Dựng Tphcm",
		After: "Cao Đẳng Xây Dựng TPHCM",
	},
	{
		Before: "Cao đẳng Y Dược Hà Nội",
		After: "Cao Đẳng Y Dược Hà Nội",
	},
	{
		Before: "Cao đẳng Y DƯỢC PASTEUR",
		After: "Cao Đẳng Y Dược Pasteur",
	},
	{
		Before: "Cao đẳng y tê",
		After: "Cao Đẳng Y Tế Hà Nội",
	},
	{
		Before: "Cao đẳng Y Tế Bình Định",
		After: "Cao Đẳng Y Tế Bình Định",
	},
	{
		Before: "Cao đẳng Y Tế Cần Thơ",
		After: "Cao Đẳng Y Tế Cần Thơ",
	},
	{
		Before: "Cao đẳng Y Tế Hà Đông",
		After: "Cao Đẳng Y Tế Hà Đông",
	},
	{
		Before: "Cao đẳng Y Tế Hà Nội",
		After: "Cao Đẳng Y Tế Hà Nội",
	},
	{
		Before: "Cao đẳng Y tế kiên giang",
		After: "Cao Đẳng Y Tế Kiên Giang",
	},
	{
		Before:
			"Cao đẳng Y Tế Ninh Bình Hiện Đang Học Liên Thông Đh Kế Toán  Đh Đông Á",
		After: "Cao Đẳng Y tế Ninh Bình",
	},
	{
		Before: "Cao đẳng Y Tế Quảng Trị",
		After: "Cao Đẳng Y Tế Quảng Trị",
	},
	{
		Before: "Cass Business School",
		After: "Đại Học City London",
	},
	{
		Before:
			"Cầu Của Công Ty Tôi Hy Vọng Thời Gian Tới Có Thể Được Làm Việc Tại Công Ty",
		After: "",
	},
	{
		Before: "Cầu giấy- Hà Nội",
		After: "",
	},
	{
		Before: "CDN bách khoa",
		After: "",
	},
	{
		Before: "CĐ Bách Việt - TPHCM",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: "CĐ Bến Tre",
		After: "Cao Đẳng Bến Tre",
	},
	{
		Before: "CĐ Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "CĐ Cộng đồng Houston",
		After: "Cao Đẳng Cộng Đồng Houston",
	},
	{
		Before: "CĐ Cộng đồng Kiên Giang",
		After: "Cao Đẳng Cộng Đồng Kiên Giang",
	},
	{
		Before: "CĐ Công Nghệ Bách Khoa Hà Nội",
		After: "Cao Đẳng Công Nghệ Bách Khoa Hà Nội",
	},
	{
		Before: "CĐ Công nghệ Hà Nội",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "CĐ Công nghệ thông tin (Thuộc Đại Học Đà Nẵng)",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "CĐ Công nghệ thông tin Hữu nghị Việt Hàn",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "CĐ Công Nghệ Thông Tin TPHCM",
		After: "Cao Đẳng Công Nghệ Thông Tin TPHCM",
	},
	{
		Before: "CĐ Công Nghệ Thủ Đức",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "CĐ Công nghệ và Kinh tế Công nghiệp",
		After: "Cao Đẳng Công nghệ Và Kinh tế Công nghiệp",
	},
	{
		Before: "CĐ Công nghệ và Quản trị Sonadezi",
		After: "Cao Đẳng Công Nghệ Và Quản Trị Sonadezi",
	},
	{
		Before: "CĐ Công nghệ và Thương mại Hà Nội",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: "CĐ Công nghiệp Hưng Yên",
		After: "Cao Đẳng Công Nghiệp Hưng Yên",
	},
	{
		Before: "CĐ Công Nghiệp Thực Phẩm TPHCM",
		After: "Cao Đẳng Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "CĐ Công thương",
		After: "Cao Đẳng Công Thương Hà Nội",
	},
	{
		Before: "CĐ Công Thương HCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "CĐ Công Thương TPHCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: "CĐ cơ điện Hà Nội",
		After: "Cao Đẳng Cơ Điện Hà Nội",
	},
	{
		Before: "CĐ Du lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "CĐ Đại Việt Sài Gòn",
		After: "Cao Đẳng Đại Việt Sài Gòn",
	},
	{
		Before: "CĐ FPT",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "CĐ FPT POLYTECHNIC",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "CĐ Giao thông Vận tải",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "CĐ Giao Thông Vận Tải 3",
		After: "Cao Đẳng Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "CĐ Kinh tế",
		After: "",
	},
	{
		Before: "CĐ Kinh tế - Công nghệ TPHCM",
		After: "Cao Đẳng Kinh tế - Công Nghệ TPHCM",
	},
	{
		Before: "CĐ Kinh tế - Kế hoạch Đà Nẵng",
		After: "Cao Đẳng Kinh Tế - Kế Hoạch Đà Nẵng",
	},
	{
		Before: "CĐ Kinh Tế - Kỹ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: "CĐ Kinh tế - Kỹ thuật Sài Gòn",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "CĐ Kinh tế - Kỹ thuật Trung ương",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: "CĐ Kinh Tế Công Nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "CĐ Kinh tế đối ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "CĐ Kinh tế HCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "CĐ Kinh tế kỹ thuật Phú Lâm",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật - Thương Mại",
	},
	{
		Before: "CĐ Kinh Tế Kỹ Thuật Vinatex TPHCM",
		After: "Cao Đẳng Nghề Kinh Tế Kỹ Thuật Vinatex",
	},
	{
		Before: "CĐ Kinh Tế TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "CĐ Kỹ thuật Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: "CĐ Kỹ Thuật Lý Tự Trọng TPHCM",
		After: "Cao Đẳng Lý Tự Trọng TPHCM",
	},
	{
		Before: "CĐ Lý Tự Trọng",
		After: "Cao Đẳng Lý Tự Trọng TPHCM",
	},
	{
		Before: "CĐ nghềTây Nguyên",
		After: "",
	},
	{
		Before: "CĐ Nova",
		After: "",
	},
	{
		Before: "CĐ Phát thanh Truyền hình II",
		After: "Cao Đẳng Phát Thanh - Truyền Hình II",
	},
	{
		Before: "CĐ Sài gòn",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: "CĐ Sư Phạm Đắk Lắk",
		After: "Cao Đẳng Sư Phạm Đắk Lắk",
	},
	{
		Before: "CĐ Tài chính - Hải quan",
		After: "Cao Đẳng Tài Chính - Hải Quan",
	},
	{
		Before: "CĐ Tài chính hải quan",
		After: "Cao Đẳng Tài Chính - Hải Quan",
	},
	{
		Before: "CĐ Tài nguyên và môi  Hà Nội",
		After: "Cao Đẳng Tài Nguyên Và Môi Trường Hà Nội",
	},
	{
		Before: "CĐ Thương mại",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "CĐ Thương mại và Du lịch Hà Nội",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "CĐ Văn hoá nghệ thuật Quân đội",
		After: "Đại Học Văn Hóa Nghệ Thuật Quân Đội",
	},
	{
		Before: "CĐ Văn hoá Nghệ thuật TP. HCM",
		After: "Cao Đẳng Văn Hóa Nghệ Thuật TPHCM",
	},
	{
		Before: "CĐ Viễn Đông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: "CĐ Việt Mỹ",
		After: "Cao Đẳng Việt Mỹ",
	},
	{
		Before: "Celadon Sport-Resort Club",
		After: "",
	},
	{
		Before: "Center Hanoi",
		After: "",
	},
	{
		Before: "Certificate Of Advanced Business Analysis University Of London",
		After: "Đại Học London",
	},
	{
		Before: "Cfvg Centre Franco Vietnamien",
		After: "",
	},
	{
		Before: "Chemical Technology",
		After: "",
	},
	{
		Before: "Chỉ Do Bộ Kinh Tế Và Công",
		After: "",
	},
	{
		Before: "Chi Nhánh Hà Nội",
		After: "",
	},
	{
		Before: "Chief Accountant Certificate By Ministry Finance",
		After: "",
	},
	{
		Before: "China",
		After: "",
	},
	{
		Before: "Chính Ngân Hàng Hệ Chính Quy",
		After: "",
	},
	{
		Before: "Chính Quy Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Chính Trị Học Viện Báo Chí Và",
		After: "",
	},
	{
		Before: "Chu Van An National High School Hanoi",
		After: "",
	},
	{
		Before: "Chu Van An Specialty High School",
		After: "",
	},
	{
		Before: "Chubb Life Vietnam",
		After: "",
	},
	{
		Before: "Chung Ang University Korea Food Engineering",
		After: "Đại Học Chung Ang",
	},
	{
		Before: "Chuyên Ngành Báo Chí Đại Học Văn Hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Chuyên Ngành Kế Toán Đại Học Lao Động Và Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before:
			"Chuyên Ngành Quản Lý Công- Khoa Chính Trị Học Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Chuyên Ngành Quản Trị Kinh Doanh- Đại",
		After: "",
	},
	{
		Before: "Chuyên Ngành Quản Trị Nhân Sự Và Dự Án- Khoa Đào",
		After: "",
	},
	{
		Before: "Chuyên Ngành Sư Phạm Hải Dương",
		After: "Đại Học Hải Dương",
	},
	{
		Before: "Chuyên Ngành Tài Chính Ngân Hàng Nay",
		After: "",
	},
	{
		Before: "Chưa",
		After: "",
	},
	{
		Before: "Chưa Cập Nhật Bộ Tài Chính",
		After: "",
	},
	{
		Before:
			"Chưa Tốt Nghiệp- T Hạc Sỹ Chuyê N Ngành T Ài Chính Ngân Hàng  Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Chưa Tốt Nghiệp--Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"Chứn G- C Hỉ Nghiệ P Vụ Waiter Ban Q U E T A T T E D A N T Bari S T A R Fb Lễ Tân Và Chăm Sóc K H Á C H H À N G",
		After: "",
	},
	{
		Before: "Chứng Chỉ Kế Toán Tổng Hợp Cấp Bởi Trung Tâm Đào Đạo Kế Toán",
		After: "",
	},
	{
		Before: "Chứng Chỉ Kế Toán Trưởng Học Viện Kế Toán Taca",
		After: "",
	},
	{
		Before:
			"Chứng Chỉ Kỹ Năng Dành Cho Nhà Quản Lý Do  Đào Tạo Nghiệp Vụ Và Kỹ Thuật Mtc Cấp",
		After: "",
	},
	{
		Before: "Chứng Chỉ Scientific Data Analysiss- Đại Học Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before:
			"Chứng Chỉ Ứng Dụng Công Nghệ Thông Tin Đơn Vị Đào Tạo-Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Chứng Chỉ Ứng Dụng Tin Học Căn Bản Đơn Vị Đào Tạo-Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Chưa Tốt Nghiệp- Đại Học Kinh Tế Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Chương Trình Cử Nhân Quốc Tế Ibd  Đh Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Chương Trình Đào Tạo Hệ Đào Tạo Cử Nhân Chính Quy 4 Năm Của Khoa Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Cid:0)Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cid0Betrimex Ben Tre Import Export Joint Stock Corporation",
		After: "",
	},
	{
		Before: "Cid0Msc Strategic Management-Ucd Micheal Smurfit Business School",
		After: "",
	},
	{
		Before: "Chứng Chỉ-Kiểm Thử Phần Mềm Tại Trung Tâm Tester Hà Nội",
		After: "",
	},
	{
		Before: "CLB Nhà Ngân Hàng Tương Lai, CTV Ban Tổ chức",
		After: "",
	},
	{
		Before: "Clb Sách Nội Vụ Năm",
		After: "",
	},
	{
		Before: "CNTT và Ngoại ngữ",
		After: "",
	},
	{
		Before: "CNTT- Đại Học Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "CNTT-  Đại Học Điện Lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Clb Nghệ Thuật  Đại Học FPT Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Co Bachelo R Đại Họ C Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "CO LTD",
		After: "",
	},
	{
		Before: "Co Po Stgraduate T Rung T Âm Giáo Dục Pt I",
		After: "",
	},
	{
		Before: "CNTT-TT Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Code Gym, JAVA BOOTCAMP 2022",
		After: "",
	},
	{
		Before: "code in standard format of FPT Software",
		After: "",
	},
	{
		Before: "Codegym Da Nang programmer training center",
		After: "",
	},
	{
		Before: "Codestar Academy",
		After: "",
	},
	{
		Before: "Colle Ge--Cao đẳng Kinh Tế Kỹ Thuật T Hái Nguyê N",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật - ĐH Thái Nguyên",
	},
	{
		Before: "College Cao đẳng Miền Nam",
		After: "Cao Đẳng Miền Nam",
	},
	{
		Before: "COLLEGE FPT POLYTECHNIC",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "College Hotel",
		After: "",
	},
	{
		Before: "College Manila",
		After: "",
	},
	{
		Before: "COLLEGE OF COMMERCE",
		After: "",
	},
	{
		Before: "COLLEGE OF FOREIGN ECONOMIC RELATION",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "COLLEGE OF FOREIGN ECONOMIC RELATIONS",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "college of high technology",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: "college of information technology - nha trang city",
		After: "Đại Học Nha Trang",
	},
	{
		Before: "College South Taiwan University Of Technology",
		After: "Đại Học Khoa Học Kỹ Thuật Nam Đài",
	},
	{
		Before: "COLLEGE TAN BINH DISTRICT HCMC",
		After: "",
	},
	{
		Before: "Color Me- Trung Tâm Đào Tạo Thiết Kế Đồ Họa",
		After: "",
	},
	{
		Before: "Columbia Southern University Usa",
		After: "Đại Học Nam Columbia",
	},
	{
		Before: "Communication Technology",
		After: "",
	},
	{
		Before: "Coá Đẳng Công nghệ Bách Khoa Hà Nội",
		After: "Cao Đẳng Công Nghệ Bách Khoa Hà Nội",
	},
	{
		Before: "Completed 9 9 Foundation Paper Level",
		After: "",
	},
	{
		Before: "Computer Science Hcmc Open University",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Computer Science Using Basic Software",
		After: "",
	},
	{
		Before: "Computer Society Of Sri Lanka",
		After: "",
	},
	{
		Before: "Concord University",
		After: "Đại Học Concord",
	},
	{
		Before: "Concordia University Chicago Chicago United States Of America",
		After: "Đại Học Concordia Chicago",
	},
	{
		Before: "Cong Thuong College Hochiminh City",
		After: "Đại Học Công Thương TPHCM",
	},
	{
		Before: "Construction-Duytan University Of Science And Technology Vietnam",
		After: "Đại Học Duy Tân",
	},
	{
		Before:
			"Control Engineering And Automation-Hanoi University Science And Technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Course Hubspot Academy",
		After: "",
	},
	{
		Before: "Coursera Udemy Unica Edumall Và Brand Vietnam Trao Đổi Qua",
		After: "",
	},
	{
		Before: "Coventry University",
		After: "Đại Học Coventry",
	},
	{
		Before: "CỘNG HÒA Xã HỘI CHỦ NGHÍA VIỆT NAM",
		After: "",
	},
	{
		Before: "Công Nghệ Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Công Nghệ Giao Thông Vận Tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Công Nghệ Phần Mềm",
		After: "",
	},
	{
		Before: "Công Nghệ Phần Mềm- Đại Học Spkt Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Công nghệ TPHCM hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "công nghệ thông tin & truyền thông",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Công nghệ thông tin và truyền thông",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Công nghệ thông tin và truyền thông - ĐHBKHN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before:
			"Công Nghệ Thông Tin-|-10 2020- 09 2022 Đại Học Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Comple Tion Date-8 2012 Bache Lor- Đ Ại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Công nghiệp tp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "công ty bs",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Bkav",
		After: "",
	},
	{
		Before: "công ty cổ phần chảo đỏ",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Chuyển Đổi Số Vietants",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Dịch Vụ Đào Tạo Trực Tuyến Oes",
		After: "",
	},
	{
		Before: "Công ty cổ phần đào tạo AMES",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Đào Tạo Kỹ Năng Tài Chính Edubelife",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Giải Pháp Công Nghệ Cs Solution",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Giải Pháp Phần Mềm",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Iposvn",
		After: "",
	},
	{
		Before: "Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Công ty Cổ Phần Misa",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Phần Mềm Oos",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Smartosc",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Tổng Hợp Việt Nhật",
		After: "",
	},
	{
		Before: "Công Ty Cổ Phần Viễn Thông FPT",
		After: "",
	},
	{
		Before: "Công Ty Cp Bền Bencomputer",
		After: "",
	},
	{
		Before: "Công ty CP CÔNG NGHỆ VÀ GIÁO DỤC PCA",
		After: "",
	},
	{
		Before: "Công ty CP TMDV Thiếu nhi mới",
		After: "",
	},
	{
		Before:
			"công ty dành cho ứng viên kết nối doanh nghiệp các bạn trẻ quan tâm đến ngành sales và phát",
		After: "",
	},
	{
		Before: "Công Ty Dịch Vụ Appa Việt Nam",
		After: "",
	},
	{
		Before: "Công ty Cổ phần Kế Toán Hà Nội",
		After: "",
	},
	{
		Before: "Công ty đào tao kế toán ACVINA",
		After: "",
	},
	{
		Before: "Công ty đào tạo Thành Trí",
		After: "",
	},
	{
		Before: "Công Ty Đâu Tư Và Phát Triên Đông Nam Á",
		After: "",
	},
	{
		Before: "Công ty Hàn Quốc",
		After: "",
	},
	{
		Before: "Công ty Kế toán Thiên Ưng",
		After: "",
	},
	{
		Before: "Công Ty Nhằm Phát Triển Thương Hiệu Của Công Ty",
		After: "",
	},
	{
		Before: "Công Ty Tài Chính Lotte Finance",
		After: "",
	},
	{
		Before: "Công Ty Thhh Growgreen",
		After: "",
	},
	{
		Before: "Công ty TNHH AZTrend",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Bê Tông Và Xây Dựng Minh Đức",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Cong Nghệ Và Thương Mại Lifesup",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Dịch Vụ Hrdc",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Dược Phẩm Alanta",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Dv Giáo Dục Thành Nguyên",
		After: "",
	},
	{
		Before: "Công Ty Dịch Vụ Kế Toán Hà Nội",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Đỉnh Vàng",
		After: "",
	},
	{
		Before: "Công ty TNHH Hệ thống thông tin FPT",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Hóa Chất Công Nghiệp Việt Hoa",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Joyhub Việt Nam",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Đào Tạo Nhân Lực Xuất Nhập Khẩu Hà Nội",
		After: "",
	},
	{
		Before: "Công ty TNHH mặt trời đỏ Redsun",
		After: "",
	},
	{
		Before: "Công ty tnhh MM mega Market Thăng Long",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Nhà Máy Bia",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Th",
		After: "",
	},
	{
		Before: "Công ty TNHH Thăng Long Ceramics VN",
		After: "",
	},
	{
		Before: "CÔNG TY TNHH THIÊN VIỆT",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Thiết Bị",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Thương Mại Dịch Vụ Bds Jenny Homes",
		After: "",
	},
	{
		Before:
			"Công Ty Tnhh Kỹ Thuật Và Xây Dựng Việt Thiên Hà Nội Công Ty Cp Thiết Bị",
		After: "",
	},
	{
		Before: "Công ty TNHH TM DV Vũ Hoang Minh tai HN",
		After: "",
	},
	{
		Before: "Công ty TNHH TP Food Việt Nam",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Trí Thức Gia Sư Giỏi",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Tư Vấn Giải Pháp Kế Toán Việt Nam",
		After: "",
	},
	{
		Before: "Công Ty Tnhh Tư Vấn Nhân Lực X Hunter",
		After: "",
	},
	{
		Before: "Công Ty Từ",
		After: "",
	},
	{
		Before: "Công Ty Venus Marketing",
		After: "",
	},
	{
		Before: "Cơ khí",
		After: "",
	},
	{
		Before: "Creat Optimized Solutions",
		After: "",
	},
	{
		Before: "Creativity",
		After: "",
	},
	{
		Before: "Customer Service Alive Ionics Ems Inc Logistics Way Of Working",
		After: "",
	},
	{
		Before: "cử nhân   assumption university",
		After: "Đại Học Assumption",
	},
	{
		Before: "cử nhân   rmit university",
		After: "Đại Học RMIT",
	},
	{
		Before: "Cử nhân - Học Viện Tại Chinh",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân - Đại Học Kinh Tế",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Cử Nhân Báo Chí Học Viện Báo Chí Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before:
			"Cử Nhân Báo Chí- Cn Báo Truyền Hình Tại Học Viện Báo Chí Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Cử Nhân Can Tho University",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Cử Nhân Chính Quy Kế Toán Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Công Ty Tnhh Thương Mại Dịch Vụ Và Tư Vấn Al Hà Nội",
		After: "",
	},
	{
		Before: "Cử Nhân Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Cử Nhân Đại Học Kinh Tế Tphồ",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Cử Nhân Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Cư Nhân Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cử Nhân Đại Học Với Tấm Bằng Xuất Sắc Và Ứng",
		After: "",
	},
	{
		Before: "Cử Nhân Hanoi Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cử Nhân Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân Kế Toán Tại  Đại Học Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Cử Nhân Khoa Học Máy Tính",
		After: "",
	},
	{
		Before: "Cử Nhân Khoa Thương Mại Điện Tử  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cử Nhân Kinh Doanh Quốc Tế Đơn Vị Đào Tạo-Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Cử Nhân Kinh Tế Của  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cử Nhân Kinh Tế  Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân Kinh Tế- Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân Quản Trị Doanh Nghiệp  Đại Học Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Cử Nhân Rmit Vietnam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Cử Nhân Tài Chính-Kế Toán Của Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Cử Nhân Tại  Đại Học Ngoại Thương Hà Nội",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cử Nhân Tiếng Anh- Đại Học Ngoại Ngữ Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Cử Nhân  Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Cử Nhân  Học Viện Tài Chính Chuyên Ngành Kế Toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân Vietnam Trade Union University",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Cử Nhân- American Liberty University",
		After: "Đại Học American Liberty",
	},
	{
		Before: "Cử Nhân- Assumption University Thailand",
		After: "Đại Học Assumption",
	},
	{
		Before: "Cử Nhân- Chattisgarh Swami Vivekanand Technical University",
		After: "Đại Học Kỹ Thuật Chhattisgarh Swami Vivekanand",
	},
	{
		Before: "Cử Nhân Tốt Nghiệp Đại Học Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Cử Nhân- Đại Học Công Đoàn",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Cử Nhân- Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Công Nghệ Tphcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Dân Lập Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "Cử Nhân- Đại Học Công Nghệ Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Cử Nhân- Đại Học Greenwich Việt Nam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Cử Nhân- Đại Học FPT Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Cử Nhân- Đại Học Khoa Học Tự Nhiên Dhqghn",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Cử Nhân- Đại Học Khoa Học Tự Nhiên Tphcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Khoa Học Xã Hội Và Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Cử Nhân- Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Tế Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Tế Tài Chính",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Tế Tp Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Tế Tp Hồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Cử Nhân- Đại Học Luật Tp Hcm",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Cử Nhân- Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Cử Nhân- Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Mỹ Thuật Công Nghiệp",
		After: "Đại Học Mỹ Thuật Công Nghiệp",
	},
	{
		Before: "Cử Nhân- Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cử Nhân- Đại Học Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Cử Nhân- Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Sân Khấu Điện Ảnh",
		After: "Đại Học Sân Khấu - Điện Ảnh Hà Nội",
	},
	{
		Before: "Cử Nhân- Đại Học Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Cử Nhân- Đại Học Thái Nguyêm Khoa Ngoại Ngữ",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Cử Nhân- Đại Học Thành Đô",
		After: "Đại Học Thành Đô",
	},
	{
		Before: "Cử Nhân- Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cử Nhân- Ha Noi University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Cử Nhân- Hanoi Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân- Hanoi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Cử Nhân- Hanoi University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Cử Nhân- Hanoi University Of Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Cử Nhân- Hcm Open University",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Cử Nhân- Hcmc University Of Foreign Languages",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Cử Nhân- Ho Chi Minh City University Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Cử Nhân- Học Viện Báo Chí Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Cử Nhân- Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Cử Nhân- Học Viện Công Nghệ Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Cử Nhân- Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Cử Nhân- Học Viện Nông Nghiệp Việt Nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Cử Nhân- Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Cử Nhân- Đại Học Nội Vụ Hà Nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Cử Nhân- Khoa Ngoại Ngữ Đại Học Thái Nguyên",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Cử Nhân- Military Science Academy",
		After: "Học Viện Khoa Học Quân Sự",
	},
	{
		Before: "Cử Nhân- Phuong Dong University",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Cử Nhân- Training Center- National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Cử Nhân-  Đại Học Công Nghiệp Tp Hcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Cử Nhân-  Đại Học Kinh Tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Cử Nhân- Khoa Luật Đh Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Cử Nhân-  Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Cử Nhân-  Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Cử Nhân-  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cử Nhân- University Of Central Oklahoma",
		After: "Đại Học Central Oklahoma",
	},
	{
		Before: "Cử Nhân- University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Cử Nhân- University Of Technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Cử Nhân- University Of Transport",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Cử Nhân- Vietnam National University Hanoi",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Cử Nhân- Vietnam University Of Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Cửa Hàng Đồng Hồ Nhật",
		After: "",
	},
	{
		Before: "Cửa Hàng Fm Style Đăk Lăk",
		After: "",
	},
	{
		Before: "CV ỨNG TUYỂN",
		After: "",
	},
	{
		Before: "Cybersoft Academy",
		After: "",
	},
	{
		Before: "Cybersoft Academy Major Frontend",
		After: "",
	},
	{
		Before: "CYBERSOFT COMPANY",
		After: "",
	},
	{
		Before: "D10Kt03-Khoa Kế Toán",
		After: "",
	},
	{
		Before: "Da Nang University Economics",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Da Nang University Of Economic Vietnam",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Da Nang University Of Education",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "da nang university of foreign language studies",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Da Nang University Of Foreign Languages",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Da Nang University Technology",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "Dại Học Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Dai Nam University Major Finance And Banking",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "Daily Execution With 5 School",
		After: "",
	},
	{
		Before: "Daiviet Group",
		After: "",
	},
	{
		Before: "Danang University Of Economics",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Danang University Of Science And Technology",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: "Data Science Boosting Camp Swinburne University",
		After: "Đại Học Swinburne",
	},
	{
		Before: "Ddại Học Tài chính - Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Cử Nhân-  Đại Học Ngoại Ngữ Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "De Montfort University Leicester United Kingdom",
		After: "Đại Học De Montfor",
	},
	{
		Before: "Deakin University Melbourne Australia",
		After: "Đại Học Melbourne",
	},
	{
		Before: "Dec 2019--June 2020 FPT Software",
		After: "",
	},
	{
		Before: "December 2006 Member of Hanoi Youths English Club",
		After: "",
	},
	{
		Before:
			"Deep Learning Networking Database And Distributed Systems Theory Of  Computation Software",
		After: "",
	},
	{
		Before: "Degree Of Bachelor Academy Of Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Delivered By Sorbonne Business School",
		After: "Đại Học Paris 1 Pantheon-Sorbonne",
	},
	{
		Before: "Department Computer",
		After: "",
	},
	{
		Before: "Department Hanoi And Hcmc",
		After: "",
	},
	{
		Before: "Department Of Global It Business",
		After: "",
	},
	{
		Before: "Department The Total Gpa I",
		After: "",
	},
	{
		Before: "Depecaphangbol Đại Học Staffordshire - Học tại Đại",
		After: "Đại Học Staffordshire",
	},
	{
		Before: "Dh Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "DDH xây dựng Hà Nội",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "DH Công Nghiệp Thực Phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "DH Điện Lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "DH kinh tế kĩ thuật công nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "DH THƯƠNG MẠI",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "DHCN TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "DHV",
		After: "",
	},
	{
		Before: "Dickson College",
		After: "Cao Đẳng Dickson",
	},
	{
		Before: "Dien Luc University",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "DH Công nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before:
			"Digital Marketing The Wharton School University Of Pennsylvania Usa",
		After: "Đại Học Pennsylvania",
	},
	{
		Before: "Diplomatic Academy Of Vietnam",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Diplomatic Academy Vietnam",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Doanh nghiệp PTI",
		After: "",
	},
	{
		Before: "Doanh Nghiệp Thành Tích Nổi Bật",
		After: "",
	},
	{
		Before: "Dong A University",
		After: "Đại Học Đông Á",
	},
	{
		Before: "dongguk university",
		After: "Đại Học Dongguk",
	},
	{
		Before: "Dr-M S Sheshagiri College Of Engineering Technology Belagavi",
		After: "Đại Học Công Nghệ KLE",
	},
	{
		Before: "drew university",
		After: "Đại Học Drew",
	},
	{
		Before: "Du lịch Đại Học Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "Duong’S Restaurant",
		After: "",
	},
	{
		Before: "duy tan university",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Duy tân",
		After: "",
	},
	{
		Before: "Duy tân cầu giấy",
		After: "",
	},
	{
		Before: "Digital Marketing Tại Vinalink- Vương Thừa Vũ Hà Nội",
		After: "",
	},
	{
		Before: "Duy tân, cầu giấy , hà nội",
		After: "",
	},
	{
		Before: "Dự Án Đào Tạo Quốc Tế Học Viện Tài Chính Đh Toulon",
		After: "Đại Học Toulon",
	},
	{
		Before: "Dự Án Triển Khai Công Ty Tnhh Cơ Điện Máy Bách Khoa",
		After: "",
	},
	{
		Before: "Duy Tân, Cầu Giấy, Hà Nội",
		After: "",
	},
	{
		Before: "Đ Ại Học- Đ Ại Học T Hương Mại- Khoa Quản Trị T Hương Mại Điện Tử",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đạ Học Kinh tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đ Ại Học- Đ Ại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đa Học thương mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đa Phương Tiện Arena Multimedia",
		After: "",
	},
	{
		Before: "đa phương tiện Arena Multimedia",
		After: "",
	},
	{
		Before: "ĐÃ TỐT NGHIỆP - BẰNG XUẤT SẮC",
		After: "",
	},
	{
		Before: "Đã Tốt Nghiệp Đại Học Và Đang Chờ Nhận Bằng",
		After: "",
	},
	{
		Before:
			"Đã Từng Giành Học Bổng Tại  Học Viện Công Nghệ Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "đẠI",
		After: "",
	},
	{
		Before: "Đại  Học Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học",
		After: "",
	},
	{
		Before: "Đại Học | Tài Chính",
		After: "",
	},
	{
		Before: "Đại Học 2019 Hiện Tại Ngành Học : Trí Tuệ Nhân Tạo Và",
		After: "",
	},
	{
		Before: "Đại Học Aichi",
		After: "",
	},
	{
		Before: "Đại Học An Giang",
		After: "Đại Học An Giang - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Ba ch Khoa Ha Nôi",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bà Rịa-Vũng Tàu",
		After: "Đại Học Bà Rịa - Vũng Tàu",
	},
	{
		Before: "Đại Học Bạc Liêu",
		After: "Đại Học Bạc Liêu",
	},
	{
		Before: "Đại Học Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa - ĐHQG Tp. HCM",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại học Bách Khoa Đà Nẵng",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học bách khoa đà nẵng",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học BÁCH KHOA Đại Học ĐÀ NẴNG",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: "Đại học Bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đã Học Tại  Cao đẳng Kinh Tế Công Nghiệp Hà Nội Từ",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội - hệ 4 năm",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội - hệ 5 năm",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội (2018 - nay)",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành : Kỹ Thuật",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Công",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Điện Tử Viễn Thông",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Khoa Học Máy Tính",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Ô Tô",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Quản Trị Kinh",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Chuyên Ngành Toán Tin",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Công Nghệ Thông Tin Ict",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Công Nghệ Thông Tin Việt Nhật",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Kế Toán",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Khoa Học Máy Tính",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Kỹ Thuật Máy Tính",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Sinh Viên Năm",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before:
			"Đại Học Bách Khoa Hà Nội Tiếng Anh Chuyên Ngành Khoa Học Kỹ Thuật Và Công Nghệ",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội Viện Công Nghệ Thông Tin Và Truyền",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học BÁCH KHOA HN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Bách Khoa Hồ Chí Minh",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học bách khoa tp hồ chí minh",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Bách Khoa TPHCM",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Bất Động Sản Và Kinh Tế Tài Nguyên",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Bình Dương",
		After: "Đại Học Bình Dương",
	},
	{
		Before: "Đại Học Bách Khoa Hà Nội)",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Cao đẳng",
		After: "",
	},
	{
		Before: "Đại Học Cần",
		After: "",
	},
	{
		Before: "Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Chuyên Ngành Công Nghệ Sinh Học",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Chuyên Ngành Kinh Doanh Quốc",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Chuyên Ngành Ngôn Ngữ Anh",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Kinh Doanh Thương Mại",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Kinh Tế Học",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học CẦN THƠ KINH TẾ NÔNG NGHIỆP",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Kinh tế nông nghiệp Đại Học",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Kỹ Thuật Máy Tính",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Marketing",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học Cần Thơ Ngôn Ngữ Pháp",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đại Học bk Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Cd",
		After: "",
	},
	{
		Before: "Đại Học Chất Lượng Cao Và Pohe",
		After: "",
	},
	{
		Before: "Đại Học Chester thành phố Chester Anh Quốc",
		After: "Đại Học Chester",
	},
	{
		Before: "Đại Học chính quy",
		After: "",
	},
	{
		Before: "Đại Học Chuyên Ngành Công Nghệ Thông Tin",
		After: "",
	},
	{
		Before: "Đại Học Chuyên Ngành Kế Toán Doanh Nghiệp",
		After: "",
	},
	{
		Before: "Đại Học chuyên ngành kế toán kiểm toán",
		After: "",
	},
	{
		Before: "Đại Học Chuyên Ngành Kinh Tế Học",
		After: "",
	},
	{
		Before: "Đại Học chuyên ngành kinh tế tài nguyên",
		After: "",
	},
	{
		Before: "Đại Học Chuyên Ngành Ngôn Ngữ Anh",
		After: "",
	},
	{
		Before: "Đại Học chuyên ngành quản trị kinh doanh",
		After: "",
	},
	{
		Before: "Đại Học Chuyên Ngành Quản Trị Marketing",
		After: "",
	},
	{
		Before: "Đại Học Chứng Chỉ Tiếng Anh",
		After: "",
	},
	{
		Before: "Đại Học Cn Đồng Nai",
		After: "Đại Học Công Nghệ Đồng Nai",
	},
	{
		Before: "Đại Học CN Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Đại Học CN tp HCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học CNHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học CNTP",
		After: "",
	},
	{
		Before: "Đại Học CNTT Gia Định Kế Toán",
		After: "Đại Học Gia Định",
	},
	{
		Before: "Đại Học CBÔNG NGHIỆP HÀ NỘI (HỆ Cao đẳng)",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công",
		After: "",
	},
	{
		Before: "Đại Học CÔNG ĐOÀN",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn , Chuyên Ngành :",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Chuyên Ngành Kế Toán",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Chuyên Ngành Luật",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Chuyên Ngành Quản Trị Nhân Sự",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học côn nghệ - ĐH quốc gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Đoàn Quản Trị Kinh Doanh",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công Đoàn Việt Nam",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công nghệ",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công nghệ - DHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học CÔNG ĐOÀN HÀ NỘI",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đại Học Công nghệ - ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học CÔNG NGHỆ - Đại Học QUỐC GIA HÀ NỘI",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học công nghệ Đại Học quốc gia hà nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ ĐH QGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đh Quốc Gia Hn",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đại Học Quốc Gia Hà Nội Công Nghệ Thông Tin",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đhqg Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đhqg Hn",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đhqg Hn Công Nghệ Thông Tin",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đhqghn",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Đhqghn |",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học CÔNG NGHỆ ĐÔNG Á",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "Đại Học Công Nghệ Đông Á  Chuyễn ngành: Tài chính kế toán",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "Đại Học Công Nghệ Đông Á Chuyên Ngành Kế Toán",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "Đại Học công nghệ đồng nai",
		After: "Đại Học Công Nghệ Đồng Nai",
	},
	{
		Before: "Đại Học công nghệ giao thông",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Giao Thông Vận",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học CÔNG NGHỆ GIAO THÔNG VẬN TẢI",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Giao Thông Vận Tải Chuyên Ngành Kế Toán",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Đhqg Hà Nội Ngành Công Nghệ Thông Tin",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Giao Thông Vận Tải Utt",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học CÔNG NGHỆ GTVT",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before:
			"Đại Học Công Nghệ Gtvt Chuyên Ngành Logistics Và Vận Tải Đa Phương Thức",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Giao Thông Vận Tải Cơ Sở Hà Nội",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Gtvt Kĩ Sư Logistics",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công Nghệ Hcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Miền Đông",
		After: "Đại Học Quốc Tế Miền Đông",
	},
	{
		Before: "Đại Học công nghệ quế lâm",
		After: "Đại Học Công Nghiệp Điện Tử Quế Lâm",
	},
	{
		Before: "Đại Học Công nghệ Sài Gòn",
		After: "Đại Học Công Nghệ Sài Gòn",
	},
	{
		Before: "Đại Học Công Nghệ Thành Phố",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHỆ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ TPHCM Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Công nghệ Thông tin - VNU-HCM",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Công nghệ Thông tin & Truyền thông - Đh Thái Nguyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Đại Học Quốc Gia Hồ Chí Minh",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Đại Học Quốc Gia Tphcm",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Đhqgtphcm",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học công nghê thông tin và truyền thông",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Và Truyền Thông Đại Học Thái Nguyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before:
			"Đại Học Công Nghệ Thông Tin Và Truyền Thông Đại Học Thái Nguyên Chuyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Công Nghê Thông Tin Va Truyên Thông Tha I Nguyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Và Truyền Thông Thái Nguyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before:
			"Đại Học Công Nghệ Thông Tin Và Truyền Thông Thái Nguyên Công Nghệ Thông Tin",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Và Truyền Thông Việt Hàn",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before:
			"Đại Học Công Nghệ Thông Tin Và Truyền Thông Việt Hàn Đại Học Đà Nẵng",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Đại Học công nghệ thông tin và Truyền thông Việt Hàn-ĐHĐN",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: "Đại Học Công Nghệ Thông Tin Việt Nhật",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHỆ TP HCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học công nghệ tp hcm hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHỆ TP HỒ CHÍ MINH",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Tp Hồ Chí Minh Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Tp. Hcm , Quản Trị",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ TP. Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công nghệ TP.Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học công nghệ tphcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Tphcm Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Tphcm Viện Công Nghệ Việt Nhật",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Công Nghệ Tphồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học công nghệ UET",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học CÔNG NGHỆ VÀ QUẢN LÝ HỮU NGHỊ",
		After: "Đại Học Công Nghệ Và Quản Lý Hữu Nghị",
	},
	{
		Before: "Đại Học Công Nghệ Gtvt Hà Nội",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Công nghệ-ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ Và Quản Lý Hữu Nghị Hà Nội",
		After: "Đại Học Công Nghệ Và Quản Lý Hữu Nghị",
	},
	{
		Before: "Đại Học Công Nghệ, Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghệ(UET) - Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đại Học Công Nghiẹ P Tphcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp | Chuyên Ngành :",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công nghiệp dệp may Hà nội",
		After: "Đại Học Công Nghiệp Dệt May Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp H",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công nghiệp Hà\nNộ",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Dệt May Hà Nội",
		After: "Đại Học Công Nghiệp Dệt May Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Công Nghệ Thông Tin",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học công nghiệp hà nội chuyên ngành cơ khí",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Kế Toán Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Kỹ Thuật Phần Mềm",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Quản Trị Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Quản Trị Kinh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học công nghiệp hà nội chuyên ngành quản trị kinh doanh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Chuyên Nghành Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Công Nghệ Ô",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Công Nghệ Ô Tô",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Công Nghệ Thông Tin",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Điện Tử Truyền Thông",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Haui",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Hệ Cao đẳng",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Kế Toán Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Kỹ Thuật Phầm Mềm",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Ngành Quản Trị Văn Phòng",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Kinh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Kinh Doanh Chất Lượng Cao",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Kinh Doanh Du Lịch",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Nhân Lực",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Quản Trị Nhân Sự",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP HCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp HN",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học công nghiệp nà nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Nghiệp Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học công nghiệp quảng ninh",
		After: "Đại Học Công Nghiệp Quảng Ninh",
	},
	{
		Before: "Đại Học Công Nghiệp Quảng Ninh Công Nghệ",
		After: "Đại Học Công Nghiệp Quảng Ninh",
	},
	{
		Before: "Đại Học Công Nghiệp Thành",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thành Phố Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thành Phố Hồ",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thành Phố Hồ Chí",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM ,",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM , Chuyên Ngành",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM Chuyên Ngành Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM Chuyên Ngành Marketing",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM Công Nghệ May",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM Kế Toán Doanh Nghiệp",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp Thực phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học công nghiệp thực phẩm hcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Hồ Chí Minh | Quản Trị",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP THỰC PHẨM THÀNH",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Thành Phố",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP THỰC PHẨM THÀNH PHÔ CHÍ MINH",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Thành Phố Hồ Chí",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Thành Phố Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học công nghiệp thực phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm TPHCM Cử Nhân Ngành Ngôn Ngữ Anh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tp",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm TP HCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tp Hcm Kế Toán Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP THỰC PHẨM TP HỒ CHÍ MINH",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tp Hồ Chí Minh Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp Thực phẩm TP. HCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tp. Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp thực phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tphcm Chuyên Ngành Quản Trị Kinh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tphcm Kế Toán Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tphcm Quản Trị",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tphcm Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực Phẩm Tphồ Chí Minh Kế Toán",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before:
			"Đại Học Công Nghiệp Thực Phẩm Tphồ Chí Minh Khoa Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Thực PhẩmTPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học công nghiệp thực thẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học công nghiệp tp hcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiêp TP HÔ Ch",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học công nghiệp tp hồ chí minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tp Hồ Chí Minh Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tp Hồ Chí Minh Khoa Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công nghiệp TP. HCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp tp. Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tp.Hồ Chí Minh.",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TpHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp TPHCM (IUH)",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Chuyên Ngành Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Kế Toán Kiểm Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Kiểm Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Quản Trị Marketing",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphcm Trung Học Phổ Thông",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Tphồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học Công Nghiệp Việt - Hưng",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học công nghiệp việt hung",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học Công Nghiệp Việt Hung Chuyên Ngành Tài Chính Kế Toán",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học Công Nghiệp Việt Hung Quản Trị Doanh Nghiệp",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học Công Nghiệp Việt Hung Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học CÔNG NGHIỆP VIỆT TRÌ",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Đại Học Công Nghiệp Vinh",
		After: "Đại Học Công Nghiệp Vinh",
	},
	{
		Before: "Đại Học Công Nghiệp Hà Nội Tài Chính Ngân Hàng",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Thương TPHCM",
		After: "Đại Học Công Thương TPHCM",
	},
	{
		Before: "Đại Học Cử Nhân Khoa Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Đại Học Cử Nhân Văn Hóa Truyền",
		After: "",
	},
	{
		Before: "Đại Học Cửu Long",
		After: "Đại Học Cửu Long",
	},
	{
		Before: "Đại Học Dân Lập Hải Phòng",
		After: "Đại Học Hải Phòng",
	},
	{
		Before: "Đại Học Dân Lập Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Đại Học DÂN LẬP VĂN LANG",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học deakin tại úc",
		After: "Đại Học Deakin",
	},
	{
		Before: "Đại Học Dl Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "Đại Học Du Lịch Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "Đại Học du lịch-Đại Học Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "Đại Học Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân - Đà Nẵng",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân chuyên ngành Quản trị Marketing",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học DUY TÂN ĐÀ NẴNG",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân Hệ Cao đẳng",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân Quản Trị Du Lịchvà Khách Sạn",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân Quản Trị Kinh Doanh",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học Duy Tân Quản Trị Kinh Doanh Tổng",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học duy tânđà nẵng chuyên ngành quản trị kinh doanh tổng",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Đại Học đà lạt",
		After: "Đại Học Đà Lạt",
	},
	{
		Before: "Đại Học ĐÀ NẴNG",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "Đại Học Đà Nẵng Phân Hiệu Kon Tum",
		After: "Phân Hiệu Đại Học Đà Nẵng Tại Kon Tum - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Đại Học Bách Khoa TPHCM",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Đại Học Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Công Ngiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Đại Học greenwich việt nam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học Đại Học Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Đại Học Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "Đại Học Đại Học khoa Học tự nhiên Đại Học",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Đại Học Điện Lực Hà Nội",
		After: "Đại Học Điện Lực",
	},
	{
		Before:
			"Đại Học Đại Học Khoa Học Vã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before:
			"Đại Học Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Đại Học mở hà nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Đại Học nội vụ hà nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Đại Học Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Đại Học Tây",
		After: "",
	},
	{
		Before: "Đại Học Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Đại Học vinh",
		After: "Đại Học Vinh",
	},
	{
		Before: "Đại Học Đại Nam",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "Đại Học Đại Nam Chuyên Ngành Kế Toán",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "Đại Học Đến Nay",
		After: "",
	},
	{
		Before: "Đại Học Đh Công Nghiệp Tphcm Khoa Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đại Học điện lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học điện lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Chuyên Ngành Kế Toán Doanh Nghiệp",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Chuyên Ngành Kế Toán Kiểm Soát",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Electric Power University",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học Điện Lực Kế Toán Doanh Nghiệp",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Khoa Kế Toán",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Khoa Kinh",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Điện Lực Khoa Quản Trị Kinh Doanh",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học Đông",
		After: "",
	},
	{
		Before: "Đại Học ĐÔNG Á",
		After: "Đại Học Đông Á",
	},
	{
		Before: "Đại Học đông á chuyên ngành lưu trữ Học và quản",
		After: "Đại Học Đông Á",
	},
	{
		Before: "Đại Học Đông Á Đà Nẵng",
		After: "Đại Học Đông Á",
	},
	{
		Before: "Đại Học Đồng Bai Khoa Kế Toán Tổng Hợp",
		After: "Đại Học Đồng Nai",
	},
	{
		Before: "Đại Học Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "Đại Học Đông Đô Thương Mại Điện Tử",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "Đại Học Đồng Nai Khoa Kinh Tế Quản Trị Kinh Doanh",
		After: "Đại Học Đồng Nai",
	},
	{
		Before: "Đại Học Đồng Tháp",
		After: "Đại Học Đồng Tháp",
	},
	{
		Before: "Đại Học FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học ĐIỆN LỰC HÀ NỘI",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Đại Học FPT Cần Thơ",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Cần Thơ Ngôn Ngữ Anh",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Greenwich",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Aptech Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Greenwich Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Hòa Lạc",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Hồ Chí Minh",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học FPT Qtkd Chuyên Ngành Marketing",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học funix",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Gia Định",
		After: "Đại Học Gia Định",
	},
	{
		Before: "Đại Học giao thông",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Giao thông vận tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học FPT hà nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Hà Nội",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Hn",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học GIAO THÔNG VẬN TẢI KẾ TOÁN TỔNG HỢP",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Giao Thông Vân Tải Phân Hiệu Tại TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Phân Hiệu Tại Tp Hồ Chí Minh",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Phân Hiệu Tại Tp. Hcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học GIAO THÔNG VẬN TẢI PHÂN HIỆU TẠI TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Phân Hiệu Tại Tphcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Phân Hiệu Thành Phố Hồ Chí",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Thành Phố Hồ",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Tp Hcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Tphcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học Greenwich",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học greenwich vietnam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học Greenwich Việt Nam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học Giao Thông Vận Tải Hà Nội Kĩ Thuật Điều Khiển Và Tự Động",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học grenoble alpes",
		After: "Đại Học Grenoble-Alpes",
	},
	{
		Before: "Đại Học griffith các hoạt động dự án",
		After: "",
	},
	{
		Before: "Đại Học Gtvt",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Greenwich Việt Nam Hà Nội",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học GTVT TP HCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Đại Học HẠ LONG",
		After: "Đại Học Hạ Long",
	},
	{
		Before: "Đại Học GTVT Hà Nội",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Đại Học Hà Nội Cử Nhân Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Đại Học Hà Tĩnh",
		After: "Đại Học Hà Tĩnh",
	},
	{
		Before: "Đại Học hải dương",
		After: "Đại Học Hải Dương",
	},
	{
		Before: "Đại Học Hải Dương Quản Trị Kinh Doanh",
		After: "Đại Học Hải Dương",
	},
	{
		Before: "Đại Học Hải Phòng",
		After: "Đại Học Hải Phòng",
	},
	{
		Before: "Đại Học Hàng Hải",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Đại Học Hàng Hải Kinh Doanh Quốc Tế Và Logistic",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Đại Học HÀNG HẢI VIỆT NAM",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Đại Học Hành Chính Học",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Đại Học Hcm",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đại Học Hiện Tại",
		After: "",
	},
	{
		Before: "Đại Học Hiện Tại Chuyên Ngành Ngôn Ngữ Anh",
		After: "",
	},
	{
		Before: "Đại Học Hiện Tại Ngành Học",
		After: "",
	},
	{
		Before: "Đại Học hoà bình",
		After: "Đại Học Hòa Bình",
	},
	{
		Before: "Đại Học Hòa Bình Quản Trị Kinh Doanh",
		After: "Đại Học Hòa Bình",
	},
	{
		Before: "Đại Học hoa lư",
		After: "Đại Học Hoa Lư",
	},
	{
		Before: "Đại Học HOA SEN",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Hoa Sen Chuyên Ngành Kinh Doanh Quốc Tế",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Hoa Sen Chuyên Ngành Quản Trị",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Hoa Sen Kinh Doanh Quốc Tế",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Hoa Sen Ngành Kinh Doanh Quốc Tế",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học Hoa Sen Tp Hcm",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Đại Học hoàng gia cambodia",
		After: "Đại Học Hoàng Gia Phnôm Pênh",
	},
	{
		Before: "Đại Học Hà Nội Hanoi University Ngôn",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Đại Học Học viện Báo chí và Tuyên truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Đại Học Học Viện Chính Sách Và Phát Triển Kinh Tế Đầu Tư",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Đại Học Học VIỆN HÀNG KHÔNG VIỆT NAM",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "Đại Học Học Viện Hành Chính Quốc Gia",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Đại Học Học Viện Hành Chính Quốc Gia Chuyên Ngành Quản",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Đại Học Học Viện Kỹ Thuật Mật Mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Đại Học Học viện kỹ thuật quân sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Đại Học Học viện ngân hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Đại Học Học Viện Ngân Hàng Chính Quy Khoa Kế Toán Kiểm Toán",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Đại Học Học viện nông nghiệp việt nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Học viện tài chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Đại Học Học Viện Tài Chính Chuyên Ngành Kế Toán Doanh",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Đại Học Học Viện Tài Chính Khoa Kinh Tế",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Đại Học Học Viên Tài Chính Tài Chính Quốc Tế",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Đại Học Hồ Chí Minh",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đại Học hồng bàng",
		After: "Đại Học Quốc Tế Hồng Bàng",
	},
	{
		Before: "Đại Học Hồng Đức",
		After: "Đại Học Hồng Đức",
	},
	{
		Before: "Đại Học HUế",
		After: "Đại Học Huế",
	},
	{
		Before: "Đại Học Huế Khoa Du Lịch",
		After: "Đại Học Huế",
	},
	{
		Before: "Đại Học Hufi Ngôn Ngữ Anh",
		After: "Đại Học Công Thương TPHCM",
	},
	{
		Before: "Đại Học Hùng Vương",
		After: "Đại Học Hùng Vương TPHCM",
	},
	{
		Before: "Đại Học hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Hutech Kế Toán",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học ITMO",
		After: "Đại Học Tổng Hợp ITMO",
	},
	{
		Before: "Đại Học ITMO (Liên Bang Nga)",
		After: "Đại Học Tổng Hợp ITMO",
	},
	{
		Before: "Đại Học itplus",
		After: "",
	},
	{
		Before: "Đại Học James Cook Singapore",
		After: "Đại Học James Cook",
	},
	{
		Before: "Đại Học Jean Moulin Lyon",
		After: "Đại Học Jean Moulin Lyon 3",
	},
	{
		Before: "Đại Học hoàng quốc việt hà nội",
		After: "",
	},
	{
		Before: "Đại Học Keuka",
		After: "Cao Đẳng Keuka",
	},
	{
		Before: "Đại Học kế toán",
		After: "",
	},
	{
		Before: "Đại Học Kế Toán Doanh Nghiệp",
		After: "",
	},
	{
		Before: "Đại Học Kế Toán Kiểm Toán",
		After: "",
	},
	{
		Before: "Đại Học Khánh Hòa",
		After: "Đại Học Khánh Hòa",
	},
	{
		Before: "Đại Học Khoa Học",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "Đại Học Khoa Học Đại Học Huế",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "Đại Học Khoa Học Huế",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "Đại Học khoa Học huế chuyên ngành báo chí truyền thông",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "Đại Học khoa Học tự nhiên",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học KHOA Học TỰ NHIÊN - ĐHQGHN",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học K Inh Tế Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Dhqghn",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học KHOA Học TỰ NHIÊN (Đại Học QUỐC GIA HÀ NỘI)",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Đại Học Quốc Gia Tphcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên ĐH QGHN",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học khoa Học tự nhiên Đại Học quốc gia hà nội",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Đhqg Tphcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học khoa Học tự nhiên đhqghn",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Đhqg Hà Nội",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Tp Hcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học khoa Học tự nhiên tphcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học Tự Nhiên Hà Nội",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Đại Học khoa Học và công nghệ việt pháp",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Khoa Học Xã Học Và Nhân Văn Đhqghn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã hội Nhân văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học khoa Học xã hội và nhân văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Chuyên Ngành Chính Trị Học",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học khoa Học xã hội và nhân văn ĐHQG TPHCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học xã hội và Nhân Văn ĐHQG TPHCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học khoa Học xã hội và nhân văn đhqg tphcm",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Đhqghn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before:
			"Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội Báo Chí",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Hn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Tp Hồ Chí Minh",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học Xã Hội Và Nhân Văn Tphcm",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại học Khoa học Xã hội và Nhân văn- ĐHQG Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Khxh Nv Đhqg Tp Hcm",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khoa Học xã hội và Nhân văn Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học KHXH&NV TP. HCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Khxhnv Tphcm",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học KHXH NV Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại Học Kĩ Thuật Phần Mềm",
		After: "",
	},
	{
		Before: "Đại Học Kĩ thuật Công nghiệp Hà Nội",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kiểm  sát Hà Nội",
		After: "Đại Học Kiểm Sát Hà Nội",
	},
	{
		Before: "Đại Học KIẾN TRÚC ĐÀ NẴNG",
		After: "Đại Học Kiến Trúc Đà Nẵng",
	},
	{
		Before: "Đại Học kiểm sát hà nội",
		After: "Đại Học Kiểm Sát Hà Nội",
	},
	{
		Before: "Đại Học kiến trúc HN",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: "Đại Học Kinh",
		After: "",
	},
	{
		Before: "Đại Học KINH BẮC",
		After: "Đại Học Kinh Bắc",
	},
	{
		Before: "Đại Học Kinh Doanh",
		After: "",
	},
	{
		Before: "Đại Học Kinh Doanh Công Nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học kiến trúc hà nội",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Công Nghệ Hà Nội Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Công Nghệ Hn",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Quốc Tế",
		After: "",
	},
	{
		Before: "Đại Học kinh doanh và công",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học kinh doanh và công nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học kinh doanh và công nghê ha",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Công Nghệ Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội | Công Nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội Chuyên Ngành Kế Toán",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội Chuyên Ngành Kế Toán Doanh",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Cộng Nghệ Hà Nội Kế Toán Tổng Hợp",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội Khoa Kế Toán",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh Doanh Và Công Nghệ Hn | Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học Kinh tế",
		After: "",
	},
	{
		Before: "Đại Học Kinh tế - Đại Học Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học kinh tế - Đại Học Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before:
			"Đại Học Kinh Doanh Và Công Nghệ Hà Nội Quản Trị Kinh Doanh Kế Toán",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đại Học kinh tế - Đại Học Quốc gia HN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học kinh tế - ĐH Quốc gia",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế - ĐHQGHN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế - Kỹ Thuật - Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học Kinh Tế - Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế - Luật",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh tế - Luật TPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học kinh tế - luật, ĐHQG TPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh tế - Tài chính TP HCM",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh tế -Luật",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Đại Học Kinh tế công nghiệp Long An",
		After: "Đại Học Kinh Tế - Công Nghiệp Long An",
	},
	{
		Before: "Đại Học kinh tế đà",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học KINH TẾ ĐÀ NẴNG",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh Tế Đà Nẵng Kế Toán",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh Tế Đà Nẵng Kinh Tế Đầu Tư",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh Tế Đà Nẵng Vào Năm",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh Tế Đại",
		After: "",
	},
	{
		Before: "Đại Học Kinh tế Đại Học Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học kinh tế Đại Học đà nẵng chuyên ngành kế toán",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh tế Đại Học Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "Đại Học Kinh Tế Đại Học Huế Chuyên Ngành Kinh Doanh Nông Nghiệp",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "Đại Học Kinh Tế Đại Học Huế Kế Toán",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "Đại Học KINH TẾ Đại Học QUỐC",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học kinh tế Đại Học Quốc gia",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế - Kỹ thuật công nghiệp Hà Nội",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học Kinh tế Đại Học quốc gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học kinh tế ĐH Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kinh Tế ĐH QGHN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Đại Học Quốc Gia Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Đh Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế ĐHQGHN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Đhqghn Chuyên Ngành Quản Trị Kinh",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Đhqghn Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Đối Ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Đại Học Kinh Tế Đhqg Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Hồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học kinh tế huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "Đại Học kinh tế kharkov ukraine",
		After: "Đại Học Quốc Gia Kharkiv",
	},
	{
		Before: "Đại Học Kinh Tế Kĩ Thuật Bình Dương",
		After: "Đại Học Kinh Tế- Kỹ Thuật Bình Dương",
	},
	{
		Before: "Đại Học Kinh Tế Kĩ Thuật Công",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học kinh tế kĩ thuật công nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học Kinh tế Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học KINH TẾ KỸ THUẬT",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học kinh tế kỹ thuật bình dương",
		After: "Đại Học Kinh Tế- Kỹ Thuật Bình Dương",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Chuyên Ngành CNTT",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Chuyên Ngành Kế Toán",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Công Nghệ Thông Tin",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kĩ Thuật Công Nghiệp Hà Nội",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học KINH TẾ KỸ THUẬT CÔNG NGHIỆP HÀ NỘI",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Kế Toán",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Loại Giỏi Gpa",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Ngành Kế Toán",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Và Công Nghiệp",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học KINH TẾ LUẬT",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Luật Đại Học Quốc Gia Tp Hcm",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh tế Luật Đại Học Quốc Gia TPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Luât Đhqg Tphcm",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Plekhanov",
		After: "Đại Học Kinh Tế Quốc Dân Plekhanov",
	},
	{
		Before: "Đại Học Kinh Tế Plekhanov Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Quốc Dân Plekhanov",
	},
	{
		Before: "Đại Học Kinh Tế Quản Trị Kinh Doanh Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Quốc",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh tế quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân , Chuyên Ngành :",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân , Chuyên Ngành Pr",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân , Tài Chính",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Chuyên Ngành Kế Toán",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tê Quốc Dân Chuyên Ngành Kiểm Toán",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Chuyên Ngành Kinh Tế Phát Triển",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Đại Học Kinh Tế Quốc Dân Chuyên Ngành Quản Lý Công Và Chính Sách Học Bằng",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Chuyên Ngành Quản Trị Doanh Nghiệp",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học kinh tế quốc dân chuyên ngành toán tài chính",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Cử Nhân Kinh Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Cử Nhân Luật Kinh Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Gpa",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội Uneti",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Hệ Thống Thông Tin Quản Lý",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Kế Toán",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Kế Toán Doanh Nghiệp",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Đại Học Kinh Tế Quốc Dân Khoa Toán Ứng Dụng Trong Kinh Tế Xếp Loại",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Kinh Doanh Quốc Tế Tiên Tiến",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Kinh Tế Quốc Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Ngành Kinh Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Quản Trị Doanh Nghiệp",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Quản Trị Marketing",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học KINH TẾ QUỐC DÂN QUẢN TRỊ NHÂN LỰC",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Tài Chính Doanh Nghiệp",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Dân Thống Kê Kinh Tế Xã Hội",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Gia Nga Plekhanov",
		After: "Đại Học Kinh Tế Quốc Dân Plekhanov",
	},
	{
		Before: "Đại Học Kinh Tế Quốc Tế",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học kinh tế tài chính",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tài Chính Hồ Chí Minh",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tài Chính Tp HCM",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh tế Tài chính TPHCM",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tài Chính Tphcm",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tài Chính Uef",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tài Chính Uef Tphcm",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh Tê Tha Nh Phô",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Thành Phố Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TPHCM Chuyên Ngành Kinh Doanh Thương Mại",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TPHCM Kinh Tế Đầu Tư",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TPHCM Ngành Tài Chính Ngân Hàng",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TPHCM Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học kinh tế tp hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tp Hcm Chuyên Ngành Quản Trị",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tp Hcm Thông Kê Kinh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học KINH TẾ TP HỒ CHÍ MINH",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TP. HCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TP. Hồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế TpHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tphcm Chuyên",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tphcm Cử Nhân Kế Toán",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tphcm Hồ Chí Minh Việt Nam",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tphcm Quản Trị Nhà Hàng Khách Sạn",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Tphcm Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học KINH TẾ TPHỒ CHÍ MINH",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học Kinh Tế Và Qtkd Đại Học Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Và Qtkd Thái Nguyên | Kế Toán",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học kinh tế và quản trị kinh doanb thái nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học kinh tế và quản trị kinh doanh",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh Đh Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học kinh tế và quản trị kinh doanh thái",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh Thái Nguyên Kế Toán",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kinh Tế Và Tài Chính Tphcm",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Đại Học Kinh tế Quốc dân Hà Nội",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đại Học kinh tế-ĐHQGHN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Kinh Tế- Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học Ktktcnhn Kế Toán",
		After: "Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
	},
	{
		Before: "Đại Học kỹ thuật - Công nghệ Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Đại Học kỹ thuật công nghệ",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học Kỹ Thuật Công Nghệ Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Đại Học Kỹ Thuật Công Nghệ Tp Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học kỹ thuật công nghiệp thái nguyên",
		After: "Đại Học Kỹ Thuật Công Nghiệp - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Kỹ Thuật Điều Khiển Và Tự Động Hóa",
		After: "",
	},
	{
		Before: "Đại Học Kỹ Thuật Phần Mềm Công Nghệ Web",
		After: "",
	},
	{
		Before: "Đại Học Kỹ Thuật Quân Sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Đại Học Kỹ Thuật Sư Phạm Đà Nẵng",
		After: "Đại Học Sư Phạm Kỹ Thuật - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Kỹ Thuật Y Dược Đà Nẵng",
		After: "Đại Học Kỹ Thuật Y - Dược Đà Nẵng",
	},
	{
		Before: "Đại Học La Habana",
		After: "Đại Học La Habana",
	},
	{
		Before: "Đại Học Lạc Hồng",
		After: "Đại Học Lạc Hồng",
	},
	{
		Before: "Đại Học LAO ĐỘNG",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động - Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao động - Xã Hội ( CSII)",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động - Xã Hội (cơ sở 2)",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động - Xã hội TP HCM",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học LAO ĐỘNG VÀ XÃ HỘI",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Và Xã Hội , Chuyên Ngành : Quản Trị",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Và Xã Hội Chuyên",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Đông Và Xã Hội Csii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Kinh Tế, Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học LAO ĐỘNG VÀ XÃ HỘI HCM",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học LAO ĐỘNG XA HỘI",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội , Chuyên Ngành",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội , Khoa Quản Trị",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội , Ngành",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội (CS2)",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Chuyên Ngành Kế Toán",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Chuyên Ngành Quản Trị Nguồn",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Công Tác Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học lao động xã hội cơ sở",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Cơ Sở Ii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Cs",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội CS2",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Csii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Csii Tp Hồ Chí Minh",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Và Xã Hội Hà Nội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học lao động xã hội ii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Kế Toán",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Khoa Quản Trị Kinh Doanh",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Ngành Kế Toán",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Quản Trị Kinh Doanh",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Quản Trị Nhân Lực",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học lao động xã hội TPHCM",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học lao động xã hội tphcm",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Ulsa",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lao Động- Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Latrobe University",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Đại Học Lâm nghiệp",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Lao Động Xã Hội Hà Nội Quản Trị",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đại Học Lâm Nghiệp Quản Trị Kinh Doanh",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Lâm Nghiệp Việt Nam",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học luật",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Đại Học Luật - Đại Học Huế",
		After: "Đại Học Luật - ĐH Huế",
	},
	{
		Before: "Đại Học luật Đại Học huế",
		After: "Đại Học Luật - ĐH Huế",
	},
	{
		Before: "Đại Học LUẬT Đại Học HUẾ LUẬT KINH TẾ",
		After: "Đại Học Luật - ĐH Huế",
	},
	{
		Before: "Đại Học Luật Hà",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Đại Học Lâm Nghiệp Hà Nội",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học LUẬT HÀ NỘI",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Đại Học Luật Huế",
		After: "Đại Học Luật - ĐH Huế",
	},
	{
		Before: "Đại Học Luật Thành Phố Hồ Chí",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Đại Học Luật TPHCM",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Đại Học Luật Tp Hồ Chí Minh",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Đại Học Luật Tphcm",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Đại Học Lương Thế Vinh",
		After: "Đại Học Lương Thế Vinh",
	},
	{
		Before: "Đại Học M6 - ĐỊA CHẤT",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Marketing Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Mỏ - Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Luật Hà Nội Luật Học",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Địa Chất Chuyên Ngành Kế Toán",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Địa Chất Chuyên Ngành Quản Trị Doanh Nghiệp",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ - Địa Chất Hà Nội",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Địa Chất Kế Toán Doanh Nghiệp",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Địa Chất Kỹ Thuật Môi ",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Địa Chất Quản Trị Doanh Nghiệp",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học mỏ địa chấtchuyên ngành kế toán thương mại dịch vụ",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ Và Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ- Địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mỏ-Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học mỏ-đụa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mot địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mở",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở : Chuyên Ngành Quản Trị",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Hà",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học mỏ địa chất hà nội",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Hà Nội Chuyên Ngành",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Hà Nội Chuyên Ngành Công Nghệ Thông Tin",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Hà Nội Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Hà Nội Kế Toán",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Mở Thành phố Hồ Chí",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học mở TPHCM",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở TPHCM Kiểm Toán",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học mở tp hcm",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở Tp Hồ Chí Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở Tp Hồ Chí Minh Ngành Kế Toán",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở TP. HCM",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở TP.Hồ Chí Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở TPHCM",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mở Tphồ Chí Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mỹ Thuật Công Nghiệp",
		After: "Đại Học Mỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học Mở Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Đại Học Mỹ Thuật Việt Nam",
		After: "Đại Học Mỹ Thuật Việt Nam",
	},
	{
		Before: "Đại Học nagoya nhật bản",
		After: "Đại Học Nagoya",
	},
	{
		Before: "Đại Học NAM CẦN HƠ QUẢN TRỊ KINH DOANH",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "Đại Học Nam Cần Thơ",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "Đại Học Nam Cần Thơ Quản Lý Tài Nguyên Và Môi ",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "Đại Học Nam Cần Thơ Từ Năm",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "Đại Học Ngành Công Nghệ Kĩ Thuật Ô Tô",
		After: "",
	},
	{
		Before: "Đại Học Ngành Công Nghệ Thông Tin",
		After: "",
	},
	{
		Before: "Đại Học Ngành Học",
		After: "",
	},
	{
		Before: "Đại Học Ngành Học Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Đại Học Ngành Quản Trị",
		After: "",
	},
	{
		Before: "Đại Học Ngành Truyền Thông Đa Phương Tiện",
		After: "",
	},
	{
		Before: "Đại Học Ngân Hàng",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng Marketing",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học ngân hàng TPHCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng TPHCM , Chuyên Ngành :",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng TPHCM Cử Nhân Hệ Thống Thông Tin Quản Lý",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng Tp",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học ngân hàng tp hcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học ngân hàng tp hồ chí minh",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng Tp Hồ Chí Minh Chuyên Ngành Quản",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân Hàng TP. HCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân hàng Tp. Hồ Chí Minh",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Ngân hàng TPHCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học ngân hàng tphcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đại Học Nghệ Thuật Huế Đồ Hoạ",
		After: "Đại Học Nghệ Thuật - ĐH Huế",
	},
	{
		Before: "Đại Học ngoai ngư",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học ngoại ngữ  Huế",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before: "Đại Học Mỹ Thuật Công Nghiệp Hà Nội",
		After: "Đại Học Mỹ Thuật Công Nghiệp",
	},
	{
		Before: "Đại Học Ngoại Ngữ - ĐHĐN",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học ngoại ngữ - ĐHQGHN",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học ngoại ngữ - tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học NGOẠI NGỮ - TIN Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại ngữ - Tin HọcTPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại ngữ -Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Dhqghn",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học NGOẠI NGỮ ĐÀ NẴNG",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Ngoại Ngữ Đại Học Đà Nẵng",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Ngoại Ngữ Đại Học Đà Nẵng Đông Phương Học",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Ngoại ngữ Đại Học Đà Nẵng khoa Cử nhân tiếng Trung",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học ngoại ngữ Đại Học đà nẵng khoa quốc",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Ngoại Ngữ Đại Học Huế",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before: "Đại Học Ngoại Ngữ - Đại Học quốc gia Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học NGOẠI NGỮ Đại Học QUỐC GIA HÀ NỘI",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học Ngoại Ngữ Đhqghn",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học Ngoại Ngữ Huế Chuyên Ngành Tiếng Anh",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học Tp Hcm Huflit",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học Tp. Hcm Kinh Doanh Quốc Tế",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học Tphcm",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Tin Học Tphcm Khoa Kinh Tế Tài Chính",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại Ngữ Và Tin Học",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học NGOẠI NGỮ- TIN Học  TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Đại Học Ngoại thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương , Quản Trị Kinh Doanh",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học NGOẠI THƯƠNG | 10/2019 - NAY",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương | Chuyên Ngành",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before:
			"Đại Học Ngoại Thương Chuyên Ngành Kế Toán Kiểm Toán Theo Định Hướng Acca",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Chuyên Ngành Kinh Tế Đối Ngoại",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Chuyên Ngành Kinh Tế Quốc Tế",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Chuyên Ngành Luật Thương Mại Quốc",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại thương Cơ sở 2 TPHCM",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Cơ Sở Ii TPHCM",
		After: "Đại Học Ngoại Thương Cơ Sở 2, TPHCM",
	},
	{
		Before: "Đại Học Ngoại Thương Foreign Trade University",
		After: "Đại Học Ngoại Thương Cơ Sở 2, TPHCM",
	},
	{
		Before:
			"Đại Học Ngoại Ngữ Đại Học Quốc Gia Hà Nội Chuyên Ngành Biên Phiên Dịch",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Đại Học NGOẠI THƯƠNG HÀ NỘI",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Hà Nội Kinh Tế Đối Ngoại",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Kế Toán Kiểm Toán",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngoại Thương Kinh Tế Đối Ngoại",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Ngôn Ngữ Anh",
		After: "",
	},
	{
		Before: "Đại Học Nguyễn",
		After: "",
	},
	{
		Before: "Đại Học NGUYỄN TẤT THÀNH",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học NGUYỄN TẤT THÀNH 08/2017",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Nguyễn Tất Thành Bậc Cao Học",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Nguyễn Tất Thành Chuyên Ngành Kinh Doanh Quốc Tế",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Nguyễn Tất Thành Chuyên Ngành Quản Trị Kinh Doanh Quốc Tế",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Nguyễn Tất Thành Kĩ Sư Xây Dựng",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Nguyễn Trãi",
		After: "Đại Học Nguyễn Trãi",
	},
	{
		Before: "Đại Học Nguyễn Trãi Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Nguyễn Trãi",
	},
	{
		Before: "Đại Học Nguyên Trí",
		After: "",
	},
	{
		Before: "Đại Học Nha",
		After: "",
	},
	{
		Before: "Đại Học nha trang",
		After: "Đại Học Nha Trang",
	},
	{
		Before: "Đại Học Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Nhân Văn Quốc Gia Liên Bang Nga",
		After: "Đại Học Nhân Văn Quốc Gia Nga",
	},
	{
		Before: "Đại Học Normandy Pháp ",
		After: "Đại Học Tổng Hợp Rouen Normandie",
	},
	{
		Before: "Đại Học Northumbria Singapore",
		After: "Đại Học Northumbria",
	},
	{
		Before: "Đại Học nội vụ",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Ngoại Thương Hà Nội Quản Trị Kinh Doanh Quốc Tế",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội | Ngành Quản Lý Nhà Nước Khoa Hành Chính",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội Chuyên Ngành Văn Thư Lưu Trữ",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội Cơ Sở Miền Trung",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội CS Miền Trung",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội Luật",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội Phân Hiệu Quảng Nam",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nội Vụ TPHCM",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nông Lâm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Đại Học Nông Lâm Đại Học Huế",
		After: "Đại Học Nông Lâm - ĐH Huế",
	},
	{
		Before: "Đại Học nông lâm huế",
		After: "Đại Học Nông Lâm - ĐH Huế",
	},
	{
		Before: "Đại Học nông lâm TPHCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Đại Học nông lâm tp hcm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Đại Học nông lâm tp hồ chí minh",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Đại Học NÔNG LÂM TPHCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Đại Học nông nghiệp",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Nội Vụ Hà Nội Tốt Nghiệp Loại Khá",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Đại Học Nông Nghiệp Quản Lý Thông Tin",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Nttu",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Đại Học Panthéon Sorbonne Paris Pháp",
		After: "Đại Học Panthéon-Sorbonne",
	},
	{
		Before: "Đại Học Paris - Pháp",
		After: "Đại Học Paris",
	},
	{
		Before: "Đại Học Phạm Văn Đồng",
		After: "Đại Học Phạm Văn Đồng",
	},
	{
		Before: "Đại Học Phan Châu Trinh",
		After: "Đại Học Phan Châu Trinh",
	},
	{
		Before: "Đại Học phần thiết",
		After: "Đại Học Phan Thiết",
	},
	{
		Before: "Đại Học phenikaa",
		After: "Đại Học Phenikaa",
	},
	{
		Before: "Đại Học Phú Xuân",
		After: "Đại Học Phú Xuân",
	},
	{
		Before: "Đại Học Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Đại Học Phương Đông Cử Nhân Tiếng Anh",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Đại Học Phương Đông Ngôn Ngữ Anh",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Đại Học Quản Lý Quốc Gia Lb Nga",
		After: "Đại Học Quản Lý Quốc Gia Nga",
	},
	{
		Before: "Đại Học Quản Trị Dịch Vụ Du Lịch Và Lữ Hành",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Doanh Nghiệp",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Du Lịch Lữ Hành Và Khách Sạn",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Hệ Thống Thông Tin",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Kinh Doanh",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Kinh Doanh Quốc Tế",
		After: "",
	},
	{
		Before: "Đại Học Quản Trị Nhân Lực",
		After: "",
	},
	{
		Before: "Đại Học Quảng Bình",
		After: "Đại Học Quảng Bình",
	},
	{
		Before: "Đại Học Quang Trung",
		After: "Đại Học Quang Trung",
	},
	{
		Before: "Đại Học Queensland",
		After: "Đại Học Queensland",
	},
	{
		Before: "Đại Học Qui Nhơn",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "Đại Học quốc gia",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học Quốc Gia Đại Học Bách Khoa Tphcm Kỹ Sư Hàng Không",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Nông nghiệp Hà Nội",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học Quốc Gia Hà Nội , Chuyên Ngành",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học Quốc Gia Hà Nội | Chuyên Ngành :",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học quốc gia Hồ Chí Minh",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đại Học Quốc Tế Đại Học Quốc Gia",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học Quốc Tế Đại Học Quốc Gia Tp Hcm Chuyên Ngành Tài Chính",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "Đại Học Quốc tế Hồng Bàng",
		After: "Đại Học Quốc Tế Hồng Bàng",
	},
	{
		Before: "Đại Học Quốc Tế Rmit Việt Nam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Đại Học QUY NHƠN",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "Đại Học Quy Nhơn Quản Trị Kinh Doanh Thương Mại",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "Đại Học Rmit",
		After: "Đại Học RMIT",
	},
	{
		Before: "Đại Học SÀI GÒN",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "Đại Học Sài Gòn Khoa Tài Chính Kế Toán",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "Đại Học Sao Đỏ",
		After: "Đại Học Sao Đỏ",
	},
	{
		Before: "Đại Học Sao Đỏ Sdu",
		After: "Đại Học Sao Đỏ",
	},
	{
		Before: "Đại Học Quốc Gia Hà Nội Khoa Quốc Tế",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Đại Học SPKT Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học Spkt Hưng Yên Sinh Viên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học SPKT Nam Định",
		After: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
	},
	{
		Before: "Đại Học SƯ PHẠM",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học Sư phạm - Đại Học Đà Nẵng",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học sư phạm Đà Nẵng",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Sư Phạm Đà Nẵng Chuyên Ngành Cử Nhân Báo Chí",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Sư Phạm Đà Nẵng Ngành Sư",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học SƯ PHẠM Đại Học ĐÀ NẴNG",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Sư Phạm Đại Học Thái Nguyên",
		After: "Đại Học Sư Phạm - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Sư Phạm Đhđn Cử Nhân Báo Chí",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: "Đại Học Sân Khấu Điện Ảnh Hà Nội",
		After: "Đại Học Sân Khấu - Điện Ảnh Hà Nội",
	},
	{
		Before: "Đại Học sư phạm hà nội",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học Sư Phạm Hà Nội | Chuyên Ngành :",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học SƯ PHẠM HÀ NỘI 2",
		After: "Đại Học Sư Phạm Hà Nội 2",
	},
	{
		Before:
			"Đại Học Sư Phạm Hà Nội Chuyên Ngành Truyền Thông Báo Chí Khoa Việt",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học Sư Phạm Hà Nội Ii Xuân Hòa Phúc Yên Vĩnh Phúc Cử Nhân",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học Sư Phạm Hà Nội Khoa Lý Luận",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học sư phạm huế Đại Học huế",
		After: "Đại Học Sư Phạm - ĐH Huế",
	},
	{
		Before: "Đại Học Sư phạm Kĩ thuật Hưng yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học sư phạm kĩ thuật hưng yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học Sư Phạm Kĩ Thuật TPHCM Chuyên Ngành Quản Lí",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học Sư Phạm Kĩ Thuật Tphcm",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học sư phạm kỹ thuật Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên Chuyên Ngành",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên Công Nghệ Thông Tin",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Nam",
		After: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
		After: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học sư phạm Kỹ thuật TP HCM",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Tp. Hcm",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học Sư phạm Kỹ thuật TPHCM",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Vinh",
		After: "Đại Học Sư Phạm Kỹ Thuật Vinh",
	},
	{
		Before: "Đại Học Sư Phạm Kỹ Thuật Vĩnh Long",
		After: "Đại Học Sư Phạm Kỹ Thuật Vĩnh Long",
	},
	{
		Before: "Đại Học sư phạm nghệ thuật trung ương",
		After: "Đại Học Sư Phạm Nghệ Thuật Trung Ương",
	},
	{
		Before: "Đại Học Sư Phạm Thái Nguyên",
		After: "Đại Học Sư Phạm - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học sư phạm TPHCM",
		After: "Đại Học Sư Phạm - ĐH Thái Nguyên",
	},
	{
		Before: "Đại Học Sư Phạm TPHCM Chuyên Ngành Quốc Tế Học",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: "Đại Học Sư phạm Tp Đà Nẵng",
		After: "Đại Học Sư Phạm Đà Nẵng",
	},
	{
		Before: "Đại Học sư phạm tp HCM",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: "Đại Học sư phạm-Đại Học đà nẵng",
		After: "Đại Học Sư Phạm Đà Nẵng",
	},
	{
		Before: "Đại Học Swinburne",
		After: "Đại Học Swinburne",
	},
	{
		Before: "Đại Học TÀI CHÍNH",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính - Kế Toán",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài chính - Kế toán Quãng Ngãi",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài Chính - Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài chính - Ngân hàng",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học TÀI CHÍNH - QUẢN TRỊ KINH",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài chính - Quản trị kinh doanh",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài chính - Trị kinh doanh",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học tài chính kế toán",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài Chính Kế Toán Chuyên Ngành Kế Toán Doanh Nghiệp",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài Chính Kế Toán Kế Toán Doanh",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài Chính Kế Toán Quảng Ngãi",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "Đại Học Tài Chính Maketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học TÀI CHÍNH MARKETING",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing , Chuyên Ngành :",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Chuyên",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Chuyên Ngành Kế Toán",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài chính Marketing Hồ Chí Minh",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Khoa Công Nghệ Thông Tin",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Ngành Tài Chính Ngân Hàng",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Tp Hcm",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài chính Marketing TPHCM",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính Marketing Tphcm",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học TÀI CHÍNH NGÂN HÀNG",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Sư Phạm Hà Nội Sư Phạm Toán",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Ngân Hàng - Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học tài chính ngân hàng hà nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Ngân Hàng Hà Nội Chuyên Ngành Kế Toán",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before:
			"Đại Học tài chính ngân hàng hà nội chuyên ngành quản trị doanh nghiệp",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before:
			"Đại Học Tài Chính Ngân Hàng Hà Nội Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Ngân Hàng Hà Nội Kế Toán",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Ngân Hàng Nghành Học Kiểm Toán Nhà Nước",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học TÀI CHÍNH QUẢN TRỊ KINH DOANH",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Quản Trị Kinh Doanh Chuyên Ngành Kế",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Quản Trị Kinh Doanh Chuyên Ngành Kế Toán",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Quản Trị Kinh Doanh Kế Toán",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Quản Trị Kinh Doanh Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Trực Thuộc Chính Phủ Liên Bang Nga",
		After: "Đại Học Tài Chính Trực Thuộc Chính Phủ Liên Bang Nga",
	},
	{
		Before: "Đại Học Tài Chính Và",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Ngân Hàng Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Và Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "Đại Học Tài Chính Vân Nam",
		After: "Đại Học Tài Chính Và Kinh Tế Vân Nam",
	},
	{
		Before: "Đại Học Tài Chính_Marketing TPHCM",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học tài chính-Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tài Chính-Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đại Học Tại Chức",
		After: "",
	},
	{
		Before: "Đại Học Tài Nguyên",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài nguyên Môi",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học tài nguyên môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Chính Và Ngân Hàng Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học tài nguyên môi  hn",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên Và",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên và Môi",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học tài nguyên và môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học TÀI NGUYÊN VÀ MÔI  HÀ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học tài nguyên môi  hà nội - Học viên của VTC ACADEMY",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Hà Nội Chuyên Ngành Kế",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before:
			"Đại Học Tài Nguyên Và Môi  Hà Nội Kế Toán Kiểm Toán Và Phân Tích Tài Chính",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Hn",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Hn Kế Toán",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học tài nguyên và môi  thành phố hồ chí",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học TÀI NGUYÊN VÀ MÔI  TPHCM",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  TPHCM Quản Trị",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Tp Hồ Chí Minh",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên và Môi  TPHCM",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Tphcm",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Tphồ Chí Minh",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Đại Học Tài Nguyên Và Môi  Hà Nội Quản Lý Tài Nguyên Và Môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Taiyuan University Of Technology",
		After: "Đại Học Công Nghệ Thái Nguyên, Trung Quốc",
	},
	{
		Before: "Đại Học Tây Bắc",
		After: "Đại Học Tây Bắc",
	},
	{
		Before: "Đại Học Tây Bắc Kế Tóan",
		After: "Đại Học Tây Bắc",
	},
	{
		Before: "Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đại Học Tây Đô Quản Trị Kinh Doanh",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đại Học Tây Nguyên",
		After: "Đại Học Tây Nguyên",
	},
	{
		Before: "Đại Học Tây Nguyên Kế Toán",
		After: "Đại Học Tây Nguyên",
	},
	{
		Before: "Đại Học Thạc Sĩ Kinh Doanh Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thái Bình",
		After: "Đại Học Thái Bình",
	},
	{
		Before: "Đại Học Thái Bình Dương",
		After: "Đại Học Thái Bình Dương",
	},
	{
		Before: "Đại Học Thái Bình Dương Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Thái Bình Dương",
	},
	{
		Before: "Đại Học Thái Bình Ngành Công",
		After: "Đại Học Thái Bình",
	},
	{
		Before: "Đại Học THÁI NGUYÊN",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Đại Học Thành Đô",
		After: "Đại Học Thành Đô",
	},
	{
		Before: "Đại Học TPHCM",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đại Học Thành Tây",
		After: "Đại Học Thành Tây",
	},
	{
		Before: "Đại Học Thăng Long",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Đại Học Thăng Long Chuyên Ngành Kế Toán",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Đại Học Thăng Long Khoa Quản Trị Kinh Doanh",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Đại Học Thăng Long Tài Chính Ngân Hàng",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Đại Học Thể Dục Thể Thao Tphcm",
		After: "Đại Học Thể Dục Thể Thao TPHCM",
	},
	{
		Before: "Đại Học thông tin liên lạc",
		After: "Đại Học Thông Tin Liên Lạc",
	},
	{
		Before: "Đại Học Thủ Dầu Một",
		After: "Đại Học Thủ Dầu Một",
	},
	{
		Before: "Đại Học Thủ Đô",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "Đại Học Thủ Đô Hà Nộ",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "Đại Học Tại  Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đại Học Thuỷ Lợi",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thủy Lợi Chuyên Ngành Marketing",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thuỷ Lợi Cử Nhân Kế Toán",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học THỦ ĐÔ HÀ NỘI",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "Đại Học Thủy Lợi Đại Học Tài Nguyên Và Môi  Hà Nội",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thủy Lợi Kế Toán Doanh Nghiệp",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thủy Lợi Ngành Học Thủy Văn",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thủy Lợi Quản Trị Kinh Doanh Quốc Tế",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thương",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại -Viện Hợp Tác Quốc Tế",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại , Chuyên Ngành Kế Toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại , Liên Kết Quốc Tế Khoa Quản Trị",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại , Ngành Marketing Chuyên Ngành Quản Trị",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại , Quản Trị",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại | Chuyên Ngành :",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Kinh Tế Quốc Tế",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Dịch",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Doanh Nghiệp",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Du Lịch Và Dịch Vụ",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Quản Trị Thương Mại Điện Tử",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Chuyên Ngành Tài Chính Ngân Hàng",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học thương mại đh toulon",
		After: "Đại Học Toulon",
	},
	{
		Before: "Đại Học Thương Mại Hà",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thủy Lợi Hà Nội",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Đại Học Thương Mại Hiện Đang Là Sinh Viên Năm 3",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Kê Toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Kế Toán Doanh Nghiệp",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Kế Toán Kiểm Toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học thương mại khoa kế toán kiểm toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Kinh Tế",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại liên kết Đại Học Toulon (Pháp)",
		After: "Đại Học Toulon",
	},
	{
		Before: "Đại Học Thương Mại Liên Kết Đào Tạo Quốc Tế Tài Chính",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Quản Lý Kinh Tế",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Quản Trị Dịch Vụ Du Lịch",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Quản Trị Hệ Thống Thông Tin",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mai Quản Trị Kinh Doanh",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Quản Trị Nhân Lực",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Quản Trị Nhân Lực Doanh Nghiệp",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Tài Chính Ngân Hàng",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Tài Chính Ngân Hàng Bảo Hiểm",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Tháng",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Thời Gian",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Thương Mại Thương Mại Điện",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học Tiền Giang",
		After: "Đại Học Tiền Giang",
	},
	{
		Before: "Đại Học topcv",
		After: "",
	},
	{
		Before: "Đại Học Topcv Quản Trị Nhân Lực",
		After: "",
	},
	{
		Before: "Đại Học Topcv Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Đại Học toulon pháp",
		After: "Đại Học Toulon",
	},
	{
		Before: "Đại Học towson mỹ",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Đại Học tôn đức thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Đại Học Tôn Đức Thắng Ban Cao đẳng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Đại Học Tôn Đức Thắng Chuyên Ngành Kế",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Đại Học Tôn Đức Thắng Hồ Chí Minh",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Đại Học Tổng hợp ITMO",
		After: "Đại Học Tổng Hợp ITMO",
	},
	{
		Before: "Đại Học Tổng Hợp Kỹ Thuật Quốc Gia Volgograd Liên Bang Nga",
		After: "Đại Học Tổng Hợp Kỹ Thuật Quốc Gia Volgograd",
	},
	{
		Before: "Đại Học Tổng Hợp Volgograd Liên Bang Nga",
		After: "Đại Học Tổng Hợp Kỹ Thuật Quốc Gia Volgograd",
	},
	{
		Before: "Đại Học Tổng Hợp Xã Hôi Quốc Gia Nga",
		After: "Đại Học Tổng Hợp Xã Hội Quốc Gia Nga",
	},
	{
		Before: "Đại Học Tphcm",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đại Học Trà Vinh",
		After: "Đại Học Trà Vinh",
	},
	{
		Before: "Đại Học Trần Quốc Tuấn",
		After: "Đại Học Trần Quốc Tuấn",
	},
	{
		Before: "Đại Học Trung cấp",
		After: "",
	},
	{
		Before: "Đại Học  Đại Học Công Nghệ Thành Phố Hồ",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Đại Học  Đại Học Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đại Học  Đại Học Kinh Tế",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Đại Học  Đại Học Sư Phạm Kĩ Thuật",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đại Học thương mại hà nội",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đại Học  Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đại Học  Quản Trị Và Kinh Doanh",
		After: "Quản Trị Và Kinh Doanh - ĐH QGHN",
	},
	{
		Before: "Đại Học Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học UEH (ĐH Kinh tế TPHCM)",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đại Học University Of Finance And Banking",
		After: "Đại Học Tài Chính - Ngân Hàng",
	},
	{
		Before: "Đại Học university of greenwich",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Đại Học Văn Hiến",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "Đại Học VĂN HIẾN QUẢN TRỊ KHÁCH SẠN",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "Đại Học Văn Hiến TP HCM",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "Đại Học Văn Hóa",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học  Đại Học Tài Nguyên Và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Đại Học Văn hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học Văn Hóa Hà Nội , Chuyên Ngành",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học VĂN HÓA HÀ NỘI | 09/2013 -",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học Văn Hóa Hà Nội Chuyên Ngành Mỹ Thuật",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học văn hóa Hồ Chí Minh",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: "Đại Học Văn Hóa Nghệ Thuật Quân Đội",
		After: "Đại Học Văn Hóa Nghệ Thuật Quân Đội",
	},
	{
		Before: "Đại Học Văn Hóa TPHCM",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: "Đại Học Văn Hóa Tp Hồ Chí Minh",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: "Đại Học Văn hóa TPHCM",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: "Đại Học Văn Hóa Tphcm",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: "Đại Học văn lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học VĂN LANG | Chuyên ngành: Kinh doanh thương mai",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Khoa Kinh Doanh Thương Mại Chuyên Ngành",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Ngành Học Kế Toán",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Quản Trị Kinh Doanh",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Tốt Nghiệp Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Tp Hcm",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học Văn Lang Tphcm",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Đại Học viên đai hoc mơ ha nôi",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Đại Học Vinh",
		After: "Đại Học Vinh",
	},
	{
		Before: "Đại Học Vinh Chuyên Ngành Công Nghệ Thông Tin Tốt Nghiệp Loại Khá",
		After: "Đại Học Vinh",
	},
	{
		Before: "Đại Học Vinh Chuyên Ngành Kế Toán",
		After: "Đại Học Vinh",
	},
	{
		Before: "Đại Học Vnfu",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "Đại Học Võ  Toản",
		After: "Đại Học Võ  Toản",
	},
	{
		Before: "Đại Học Võ Toản",
		After: "Đại Học Võ  Toản",
	},
	{
		Before: "Đại Học Xây Dựng",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Đại Học Xây Dựng Công Nghệ Thông Tin",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Đại Học Văn Hoá Hà Nội Việt Nam Học Văn Hoá Du Lịch",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đại Học Xây Dựng Khoa Công Nghệ Thông Tin",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Đại Học Xây dựng Miền Tây",
		After: "Đại Học Xây Dựng Miền Tây",
	},
	{
		Before: "Đại Học Y Dược Tphcm",
		After: "Đại Học Y Dược TPHCM",
	},
	{
		Before: "Đại Học Y Tế Công Cộng",
		After: "Đại Học Y Tế Công Cộng",
	},
	{
		Before: "Đại Học Yersin Đà Lạt",
		After: "Đại Học Yersin Đà Lạt",
	},
	{
		Before: "Đại Học xây dựng hà nội",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Đại-Học-Bách-Khoa Hiện Chỉcòn Học Phần Thực Tập Tốt",
		After: "",
	},
	{
		Before: "Đại-Học-Khoa Học Xã Hội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Đại-Học-Nội-Vụ-Hà-Nội-Phân-Hiệu-Tại Quảng Nam",
		After: "Phân Hiệu Đại Học Nội Vụ Hà Nội Tại Quảng Nam",
	},
	{
		Before: "ĐạiHọc Kinh Tế - Luật",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "đai Học: Đại Học công nghiệp hà nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đang Học Tại Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Đang Học Tại Iuh-  Đại Học Công Nghiệp Tphcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đang Học Tại  Đại Học Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đang Học Thạc Sĩ Tại Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Đang Học Thạc Sĩ Tại  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Đang Học Đại Học Đại Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Đang Học  Đại Học Tài Nguyên Và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before:
			"Đang Theo Học Chương Trình Nghiên Cứu Sinh Tại  Đại Học Tài Chính Trực Thuộc Chính Phủ Liên",
		After: "Đại Học Tài Chính Trực Thuộc Chính Phủ Liên Bang Nga",
	},
	{
		Before: "Đạo Học Xã hội & Nhân văn TPHCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Đạt Được Danh Hiệu Học Viện Sinh Viên Xuất Sắc Học Kỳ I Năm",
		After: "",
	},
	{
		Before: "Đến Nay Cao đẳng Viễn Đông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before:
			"Đang Là Sinh Viên Năm Cuối  Đại Học Công Nghiệp Hà Nội Ngành Khoa Học Máy Tính",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "ĐH Bạc Liêu",
		After: "Đại Học Bạc Liêu",
	},
	{
		Before: "ĐH Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "ĐH Bách Khoa - ĐHQG TPHCM",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Đến Nay Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "ĐH Bách khoa HN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "ĐH Bình Dương",
		After: "Đại Học Bình Dương",
	},
	{
		Before: "ĐH Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "ĐH CN giao thông vận tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Công Đoàn",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Đh Công nghệ",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công nghệ - ĐHQG",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công Nghê - ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "ĐH Công Nghệ ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công Nghệ Đông Á - Bắc Ninh",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "ĐH Công Nghệ Giao Thông Vận Tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Công nghệ Giao thông vận tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Công nghệ GTVT",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Công nghệ - ĐH Quốc gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công nghệ Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công nghệ Hà Nội - ĐH QGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công Nghệ Hà Nội - ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công Nghệ HCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công Nghệ HCM - HUTECH",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công nghệ Sài Gòn",
		After: "Đại Học Công Nghệ Sài Gòn",
	},
	{
		Before: "ĐH Công nghệ Thông tin Gia Định",
		After: "Đại Học Gia Định",
	},
	{
		Before: "ĐH Công Nghệ TP HCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH công nghệ TP Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công nghệ TPHCMĐẠI",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công Nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Công nghệ- ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "ĐH Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "ĐH Công Nghệ Hà Nội - ĐHQGHN, ĐH Công nghiệp Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Đh Công Nghiệp Hn",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "ĐH Công nghiệp thực phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "ĐH CÔNG NGHIỆP THỰC PHẨM TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "ĐH Công nghiệp thực phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Đh Công Nghiệp Thực Phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "ĐH Công Nghiệp TP HCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "ĐH công nghiệp TP Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "ĐH Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "ĐH Công nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Đh Công Nghiệp Việt - Hung",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "ĐH Công Nghiệp Việt Trì",
		After: "Đại Học Công Nghiệp Việt Trì",
	},
	{
		Before: "ĐH Dân lập Lạc Hồng",
		After: "Đại Học Lạc Hồng",
	},
	{
		Before: "ĐH Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "ĐH Dân Lập Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "ĐH Deakin - Melboume",
		After: "Đại Học Deakin",
	},
	{
		Before: "ĐH Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "ĐH Dân Lập Phương Đông - Hà Nội",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "ĐH Đà Lạt",
		After: "Đại Học Đà Lạt",
	},
	{
		Before: "ĐH Dược Hà Nội",
		After: "Đại Học Dược Hà Nội",
	},
	{
		Before: "ĐH Điện Lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "ĐH Đại Nam - Hà Nội",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "ĐH Đông Á",
		After: "Đại Học Đông Á",
	},
	{
		Before: "ĐH Đông Á - Đà Nẵng",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "ĐH Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: "ĐH Đồng Nai",
		After: "Đại Học Đồng Nai",
	},
	{
		Before: "ĐH FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Đh Điện Lực Hà Nội",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "ĐH Giao Thông Vận Tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Giao Thông Vận Tải - TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "ĐH Giao thông vận tải HN",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "ĐH Giao thông vận tải TPHCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "ĐH GTVT",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Đh FPT Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "ĐH Hải Phòng",
		After: "Đại Học Hải Phòng",
	},
	{
		Before: "ĐH Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "ĐH Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "ĐH Huế- Đh Khoa Học",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "ĐH Hùng Vương (Phú Thọ)",
		After: "Đại Học Hùng Vương",
	},
	{
		Before: "ĐH Hùng Vương (TPHCM)",
		After: "Đại Học Hùng Vương TPHCM",
	},
	{
		Before: "ĐH Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Khánh Hòa",
		After: "Đại Học Khánh Hòa",
	},
	{
		Before: "ĐH Khoa Du Lịch - ĐH Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "ĐH Khoa Học tự nhiên",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "ĐH Khoa Học Tự nhiên - ĐH QGHN",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "ĐH Khoa Học tự nhiên - ĐHQGHN",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "ĐH Khoa Học Tự Nhiên - ĐHQGTPHCM",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Khoa Học Tự Nhiên TPHCM",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Đh Khoa Học Xã Hội Và Nhân Văn Đh Qg Hn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "ĐH Khoa Học Xã Hội Và Nhân Văn TPHCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Khoa Học XH & Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "ĐH KHXH&NV - Australia Studies",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "ĐH Kiên Giang",
		After: "Đại Học Kiên Giang",
	},
	{
		Before: "ĐH Kiến Trúc Đà Nẵng",
		After: "Đại Học Kiến Trúc Đà Nẵng",
	},
	{
		Before: "ĐH Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Đh kinh doanh cn hn",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "ĐH Kiến Trúc Hà Nội",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: "ĐH Kinh doanh công nghệ hà nộn",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "ĐH Kinh Doanh Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "ĐH Kinh tế",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "ĐH Kinh Tế - ĐH Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "ĐH Kinh Tế - ĐHQGHN",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "ĐH Kinh tế - Luật",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Kinh doanh và Công nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "ĐH Kinh Tế (Thuộc Đại Học Đà Nẵng)",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "ĐH Kinh tế Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "ĐH Kinh Tế Kỹ Thuật Bình Dương",
		After: "Đại Học Kinh Tế- Kỹ Thuật Bình Dương",
	},
	{
		Before: "ĐH Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "ĐH Kinh tế - ĐH Quốc gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "ĐH Kinh Tế Kỹ Thuật Công Nghiệp HN",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "ĐH Kinh tế luật",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Kinh Tế Luật - ĐHQGTPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "ĐH Kinh tế Quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "ĐH Kinh tế tài chính",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "ĐH Kinh Tế Tài Chính TPHCM",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "ĐH Kinh tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "ĐH Kinh Tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "ĐH Kinh tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "ĐH Kinh Tế và QTKD Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Đh Kinh Tế- ĐH Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "ĐH Kỹ Thuật Công Nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "ĐH Kỹ thuật Công nghiệp - ĐH Thái Nguyên",
		After: "Đại Học Kỹ Thuật Công Nghiệp - ĐH Thái Nguyên",
	},
	{
		Before: "ĐH Kỹ thuật Y Dược Đà Nẵng",
		After: "Đại Học Kỹ Thuật Y - Dược Đà Nẵng",
	},
	{
		Before: "ĐH Lạc Hồng",
		After: "Đại Học Lạc Hồng",
	},
	{
		Before: "ĐH Lao Động - Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "ĐH Lao động cở sở 2",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "ĐH Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đh Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "ĐH Lao Động Xã Hội - Cơ sở 2 - TPHCM",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "ĐH Lao động Xã hội CS2",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Đh Lao động-Xã hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "ĐH Lâm Nghiệp Cơ sở 2 - Đồng Nai",
		After: "Phân Hiệu Đại Học Lâm Nghiệp Việt Nam Tại Đồng Nai",
	},
	{
		Before: "ĐH Lâm Nghiệp HN",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: "ĐH Lao Động Xã Hội - Cơ sở 1 - Hà Nội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "ĐH Luật - ĐH Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "ĐH Luật TP. HCM",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "ĐH Luật TPHCM",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "ĐH Mê Kông",
		After: "Đại Học Cửu Long",
	},
	{
		Before: "ĐH Mỏ - Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "ĐH Mỏ địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "ĐH Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "ĐH Mỏ- Địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "ĐH Mở",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "ĐH Mỏ Địa Chất - Hà Nội",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "ĐH Mở TPHCM",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "ĐH Nam Cần Thơ",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "ĐH Ngân hàng",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Đh Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "ĐH Ngân hàng HCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "ĐH Ngân Hàng TPHCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "ĐH Ngoại Ngữ - ĐH Đà Nẵng",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: "ĐH Ngoại Ngữ - ĐH Huế",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before: "ĐH Ngân hàng Hà Nội",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "ĐH Ngoại ngữ tin Học",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "ĐH Ngoại Ngữ Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "đh ngoại thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "ĐH Ngoại ngữ - ĐH Quốc gia Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "ĐH Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "ĐH Ngoại Thương - Cơ sở 1 - Hà Nội",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "ĐH Nha Trang",
		After: "Đại Học Nha Trang",
	},
	{
		Before: "ĐH Nông Lâm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "ĐH Nông Lâm Hồ Chí Minh",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "ĐH Nông Lâm TPHCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "ĐH Nông Lâm TPHCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "ĐH Phan Thiết",
		After: "Đại Học Phan Thiết",
	},
	{
		Before: "ĐH Phòng Cháy Chữa Cháy - Hệ Công An - Phía Bắc",
		After: "Đại Học Phòng Cháy Chữa Cháy",
	},
	{
		Before: "ĐH Phú Xuân",
		After: "Đại Học Phú Xuân",
	},
	{
		Before: "ĐH Phương Đông",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "ĐH Nguyễn Trãi - Hà Nội",
		After: "Đại Học Nguyễn Trãi",
	},
	{
		Before: "ĐH Quảng Bình",
		After: "Đại Học Quảng Bình",
	},
	{
		Before: "ĐH Quảng Nam",
		After: "Đại Học Quảng Nam",
	},
	{
		Before: "ĐH Quốc Gia TPHCM",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "ĐH Quốc Gia TPHCM - ĐH An Giang",
		After: "Đại Học An Giang - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Quốc Tế - ĐH Quốc Gia TPHCM",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "ĐH Quốc tế Hồng Bàng",
		After: "Đại Học Quốc Tế Hồng Bàng",
	},
	{
		Before: "ĐH Quốc Tế Rmit Việt Nam",
		After: "Đại Học RMIT",
	},
	{
		Before: "ĐH Quốc Tế Sài Gòn",
		After: "Đại Học Quốc Tế Sài Gòn",
	},
	{
		Before: "ĐH Quy Nhơn",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "ĐH RMIT TPHCM",
		After: "Đại Học RMIT",
	},
	{
		Before: "ĐH Sài Gòn",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "ĐH Quản trị và Kinh doanh - ĐH Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "ĐH sp Hà Nội",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "ĐH Sư Phạm Kỹ Thuật",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "ĐH Sư Phạm Kỹ Thuật TPHCM",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Đh Sư phạm thể dục thể thao tp Hồ Chí Minh",
		After: "Đại Học Sư Phạm Thể Dục Thể Thao TPHCM",
	},
	{
		Before: "ĐH Sư Phạm TPHCM",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: "ĐH Tài Chính - Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "ĐH Sư phạm Hà Nội",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "ĐH Tài chính kế toán",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "ĐH Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đh Tài Chính Ngân Hàng",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "ĐH Tài chính - Ngân hàng Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "ĐH Tài chính Quản trị kinh doanh",
		After: "Đại Học Tài Chính Quản Trị Kinh Doanh",
	},
	{
		Before: "ĐH Tài chính ngân hàng Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "ĐH Tài Nguyên Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "ĐH Tài nguyên và môi  TPHCM",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "ĐH Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "ĐH Tây Nguyên",
		After: "Đại Học Tây Nguyên",
	},
	{
		Before: "ĐH Thành Đô - HCM",
		After: "Đại Học Thành Đô",
	},
	{
		Before: "ĐH Thăng Long",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "ĐH Thủy lợi",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "ĐH Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "ĐH Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "ĐH Văn Hiến",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "ĐH Tài nguyên và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "ĐH Văn hóa Nghệ thuật Quân đội - phía Nam",
		After: "Đại Học Văn Hóa - Nghệ Thuật Quân Đội",
	},
	{
		Before: "Đh Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "ĐH Xây Dựng",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "ĐH Văn Hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "ĐH. Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "ĐH Xây Dựng Hà Nội",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "ĐHBKHN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Đhcnhn)Đhcnhn",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Đhqg Tphcm- Đại Học Kinh Tế Luật",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "Đhqghn- Đại Học Kinh Tế",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "ĐHBK Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Địa Học tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Địa Học Tài Nguyên Và Môi  Tpchm",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Địa Chỉ Ngõ 40 Tạ Quang Bửu Hai Bà Trưng Hà Nội",
		After: "",
	},
	{
		Before: "Điện tử - Viễn thông",
		After: "",
	},
	{
		Before: "Điện Tử Khoa Phát Thanh",
		After: "",
	},
	{
		Before: "Địa Học Văn Hoá Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Đoàn Quận 3 Công Ty Tnhh Mtv Kho Vận Sài Gòn Co",
		After: "",
	},
	{
		Before: "ĐOI Học CÔNG NGHỆ GIAO THÔNG VẤN",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Đỗ Quang Huy",
		After: "",
	},
	{
		Before: "Đình Hà Nội",
		After: "",
	},
	{
		Before: "Đơn Vị Đào Tạo Cao đẳng Văn Hoá Nghệ Thuật Và Du Lịch",
		After: "Cao Đẳng Văn Hóa Nghệ Thuật Và Du Lịch Sài Gòn",
	},
	{
		Before: "Đơn Vị Đào Tạo  Đại Học Kỹ Thuật Công Nghệ Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo-Cao đẳng Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đại Học Kinh Tế Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đại Học Kinh Tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đại Học Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đơn Vị Đào Tạo-Đh Võ  Toản",
		After: "Đại Học Võ  Toản",
	},
	{
		Before: "Đơn Vị Đào Tạo-Khoa Kinh Tế Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo-Trung Tâm Công Nghệ Phần Mền  Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo-Trung Tâm Dịch Vụ Việc Làm Thanh Niên",
		After: "",
	},
	{
		Before: "Đơn Vị Đào Tạo- Cao đẳng Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo- Cao đẳng Kinh Tế Kỹ Thuật Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo- Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo- Đại Học Kỹ Thuật Công Nghệ Cần Thơ",
		After: "Đại Học Kỹ Thuật - Công Nghệ Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo- Đại Học Nam Cần Thơ",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: "Đơn Vị Đào Tạo- Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đơn Vị Đào Tạo- Đh Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: "Đơn Vị Đào Tạo- Quân Sự Quân Khu",
		After: "",
	},
	{
		Before: "E Tek Technology Media And Services Solution Joint Stock Company",
		After: "",
	},
	{
		Before: "Each Project",
		After: "",
	},
	{
		Before: "East Asia University Technology",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: "EASTERN INTERNATIONAL UNIVERSITY",
		After: "Đại Học Quốc Tế Miền Đông",
	},
	{
		Before: "Economics",
		After: "",
	},
	{
		Before: "Economics 2017 2021 National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Economics Law Hanoi Law University",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Economics University",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Economics University Ho Chi Minh City Viet Nam",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "education college hue",
		After: "Cao Đẳng Sư Phạm Thừa Thiên Huế",
	},
	{
		Before: "Education Jsc",
		After: "",
	},
	{
		Before: "EDUCATION LEVEL",
		After: "",
	},
	{
		Before:
			"Education------------------2007 2011 Hanoi Open University Faculty",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "electric power university",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Electric Power University Ddl",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Electric Power University Major",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Electric Power University(EPU)",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Email Btthunguyetulawgmailcom",
		After: "",
	},
	{
		Before:
			"Engineer Degree Of Computer Science Ha Noi University Science And Technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before:
			"Engineer Degree- Electronics And Telecommunication Engineer - Hanoi University Of Science",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Engineering Degree Of Computer Science, Ha Noi",
		After: "",
	},
	{
		Before: "English Department",
		After: "",
	},
	{
		Before: "English Funny Club FPT University",
		After: "Đại Học FPT",
	},
	{
		Before:
			"English Language Learning Program Which Is An International Joint Program Between The University",
		After: "",
	},
	{
		Before: "English Language Studies University Languages",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before:
			"English Language Translation And Interpretation, 2019- University Language",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "EPU",
		After: "",
	},
	{
		Before: "Erc International University",
		After: "Đại Học Quốc tế - ĐHQG HN",
	},
	{
		Before: "Esociote PPDD Vu Ngoc Thanh rechor of Ho Chi Minh City Acodemy",
		After: "",
	},
	{
		Before: "Excellent Certificate Of International Payment",
		After: "",
	},
	{
		Before: "F8 Edu Hanoi City Vietnam",
		After: "",
	},
	{
		Before: "Faculty Information Technology",
		After: "",
	},
	{
		Before: "Faculty Of Computer Networks And Communications",
		After: "",
	},
	{
		Before: "Faculty of Information Technology",
		After: "",
	},
	{
		Before:
			"Faculty Of Information Technology-Posts And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Falculty Of Business English",
		After: "",
	},
	{
		Before: "Familiar With Ms Office Hrm Software Sap System",
		After: "",
	},
	{
		Before: "Fast Software Company",
		After: "",
	},
	{
		Before: "Fdc103 Database Management System",
		After: "",
	},
	{
		Before: "Feb 2021   Mar 2021 Tester Ha Noi Center",
		After: "",
	},
	{
		Before: "Final Year Student- Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Finance",
		After: "",
	},
	{
		Before: "Finance Academy",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Finance And Marketing University",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "Finance Issued By National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Finance National Economic University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Finance Of Luong The Vinh University",
		After: "Đại Học Lương Thế Vinh",
	},
	{
		Before:
			"First Prize Of International Communication Master Contest Held By Dav",
		After: "",
	},
	{
		Before:
			"Floor Sales Training Course- Pg Company Certificate Of Key Account Management",
		After: "",
	},
	{
		Before: "Forcign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Fore I G N- T Rade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before:
			"Foreigin Trade University 2 University of Bedfordshire | Hanoi, Viet Nam",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Center - Bank HCM City University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University And Rennes",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Aug",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Bachelor Degree External Economics",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Hanoi Vietnam",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University International Economics",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Major",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Major Business English",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Major International",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University Major International Business",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University To Jun",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University University Of Bedfordshire",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University--Ha Noi Viet Nam",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University, Hanoi",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University, Hanoi (2022 - 2023)",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Foreign Trade University, Hanoi, Viet Nam",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before:
			"Foundation International Standard Knowledge About Customer Experience Project Management Base On",
		After: "",
	},
	{
		Before: "Foundation of Logistics Operations",
		After: "",
	},
	{
		Before: "FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT  Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "FPT Academy",
		After: "",
	},
	{
		Before: "FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "FPT Arena Multilmedia",
		After: "",
	},
	{
		Before: "FPT Arena Multimedia",
		After: "",
	},
	{
		Before: "FPT Greenwich FPT University",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "FPT Greenwich University",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "FPT Greenwich Viet Nam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "FPT Jetking",
		After: "Cao Đẳng FPT Jetking",
	},
	{
		Before: "FPT Multimedia",
		After: "",
	},
	{
		Before: "FPT POLYTECHNIC",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "FPT Polytechnic Cần Thơ",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "FPT Polytechnic Colleges, Information Technology",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Đơn Vị Đào Tạo Cao Đằng Kinh Tế Công Nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "FPT Software",
		After: "",
	},
	{
		Before: "FPT Software Academy",
		After: "",
	},
	{
		Before: "FPT Software Academy Java Web Developer",
		After: "",
	},
	{
		Before: "FPT University",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University Graduated",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University Ha",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT Polytechnic Hà Nội",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "FPT University Hanoi",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University Hanoi Software Engineer",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University Major Multimedia",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University, Hanoi - Vietnam",
		After: "Đại Học FPT",
	},
	{
		Before: "FPT University, Major: FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "FPT- FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "FPT-Aptech",
		After: "",
	},
	{
		Before: "French Vietnamese Center For Management Education",
		After: "Trường Quản lý Pháp Việt (CFVG)",
	},
	{
		Before: "French Vietnamese Centre For Management Education",
		After: "Trường Quản lý Pháp Việt (CFVG)",
	},
	{
		Before: "Fresh Asian Food Mart",
		After: "",
	},
	{
		Before: "fresher academy",
		After: "",
	},
	{
		Before: "Fresher Academy Fsoft",
		After: "",
	},
	{
		Before: "Fresher Academy, FPT Software",
		After: "",
	},
	{
		Before: "Friedrich Schiller University Jena",
		After: "",
	},
	{
		Before: "From - to: HANOI COLLECGE OF COMMERCE AND TOURISM.",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "From 2011 To 2014 Hanoi University Of Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Fsoft Academy",
		After: "",
	},
	{
		Before: "Fsoft Academy After That I",
		After: "",
	},
	{
		Before: "Fsoft Academy Dec",
		After: "",
	},
	{
		Before: "FTU",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Full Stack Web Developer With Microsoft Technology",
		After: "",
	},
	{
		Before: "Funix Center",
		After: "",
	},
	{
		Before: "Funix Online University Information Technology",
		After: "",
	},
	{
		Before: "Galaxy Store",
		After: "",
	},
	{
		Before: "Garment Technology",
		After: "",
	},
	{
		Before: "FPT University Hà Nội",
		After: "Đại Học FPT",
	},
	{
		Before: "Gia Dinh University",
		After: "Đại Học Gia Định",
	},
	{
		Before: "giangptt299gmailcom",
		After: "",
	},
	{
		Before: "Giao thông vận tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Giấy-Chứng-Nhận-Đoàn Viên Xuất Sắc",
		After: "",
	},
	{
		Before: "Gifted Vinh Nghe An",
		After: "",
	},
	{
		Before: "Gk Corporation",
		After: "",
	},
	{
		Before: "GOBIZ JSC",
		After: "",
	},
	{
		Before: "GPA Trung bình: 3,23",
		After: "",
	},
	{
		Before: "Graduated From Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Graduated From Diplomatic Academy Vietnam",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Graduated From Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Graduated from Italian Department of Hanoi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before:
			"Graduated From Trade Union University Ha Noi Tester Training Center",
		After: "Đại Học Công Đoàn",
	},
	{
		Before:
			"Graduated From Tran Quang Khai High School, Khoai Chau District, Hung Yen",
		After: "",
	},
	{
		Before: "Graduated From University West Of England",
		After: "Đại Học England",
	},
	{
		Before: "Graduation Dong Nai College Art",
		After: "Cao Đẳng Mỹ Thuật Trang Trí Đồng Nai",
	},
	{
		Before: "Greenwich University",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Greenwich University Software Engineering",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "greenwich vietnam university",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Gregg International College Shinjuku Campus",
		After: "",
	},
	{
		Before: "Hà đông",
		After: "",
	},
	{
		Before: "ha long university",
		After: "Đại Học Hạ Long",
	},
	{
		Before: "Ha Noi Architectural University",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: "Ha Noi College Of Commerce And Tourism",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "Ha Noi Law University",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Ha Noi National University",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "HA NOI OPEN UNIVERSITY",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Ha Noi Polytechnic College Technology",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Ha Noi Tester Center",
		After: "",
	},
	{
		Before: "Ha Noi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Ha Noi University Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Ha Noi",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Ha Noi University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Ha Noi University Mining And Geology",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Ha Noi University Of Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Ha Noi University Of Natural Resources And Environment",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "ha noi university of science and technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Of Science And Technology Major : Computer",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before:
			"Ha Noi University Of Science And Technology School Of Electronics And Telecomunications",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Of Science Technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Quoc Hoc High School For The Gifted",
		After: "",
	},
	{
		Before: "Ha Noi University Science",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Science And Technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Science And Tecnology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Sciences",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Ha Noi University Vietnam",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Ha Noi Vietnam",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Ha Noi-University Of Business And",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Genetic- Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "hà nội",
		After: "",
	},
	{
		Before: "Hải Phòng",
		After: "",
	},
	{
		Before: "Hai Phong University",
		After: "Đại Học Hải Phòng",
	},
	{
		Before: "Hai Trieu Watches Co., Ltd",
		After: "",
	},
	{
		Before: "Hamburg University Of Applied Sciences Ba Medien And",
		After: "Đại Học Hamburg",
	},
	{
		Before: "Hamline University St Paul Mn Usa Bba December",
		After: "Đại Học Hamburg",
	},
	{
		Before:
			"Hàng Năm Tham Gia Các Khóa Đào Tạo Offline Của Công Ty Để Cập Nhật Và",
		After: "",
	},
	{
		Before: "Hangpt2205Gmailcom",
		After: "",
	},
	{
		Before: "Hanoi",
		After: "",
	},
	{
		Before: "HANOI APTECH",
		After: "",
	},
	{
		Before: "HANOI ARCHITECTURE UNIVERSITY",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: "Hanoi College Education",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: "HANOI COLLEGE OF TECHNOLOGY AND COMMERCE",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: "Hanoi Financial and Banking University",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "hanoi foreign trade university",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "HANOI INDUSTRIAL TEXTILE GARMENT UNIVERSITY (HICT)",
		After: "Đại Học Công Nghiệp Dệt May Hà Nội",
	},
	{
		Before: "Hanoi Law University",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Hanoi Law University Major Economic Law",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Hanoi Major",
		After: "",
	},
	{
		Before: "Hanoi Metropolitan University",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: "Hanoi National University",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi National University Education",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi National University Of Education",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi National University, Internationai School",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi Open University",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Hanoi Open University Aug",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Hanoi Open University, Faculty Of Tourism, Vietnam",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Hanoi Polytechnic College Of Technology Information Technology",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Hanoi Polytechnic College Technology",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: "Hanoi Tester Center",
		After: "",
	},
	{
		Before: "Hanoi Tester Training Center",
		After: "",
	},
	{
		Before: "Hanoi Tester Training Centre",
		After: "",
	},
	{
		Before: "HANOI UNIVERSITY",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Hanoi University",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Hanoi University Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Hanoi University Business Administration Cum English Bachelor",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi University Business And Technology Ha Noi",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Hanoi University English Department",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi University Hanoi Vietnam",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Hanoi University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hanoi University Major",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Hanoi University Major Bachelor Of Accounting",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Hanoi University Mining",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Hanoi University Myning And Geolory",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Hanoi University Of",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi University Of Business And Technology",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Hanoi University Of Business And Technology , Chuyên Ngành",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Hanoi University Of Civil Engineer",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Hanoi University Of Civil Engineering",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Hanoi University Of Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Hanoi University Of Culture",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Hanoi University Of Home Affairs",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Hanoi university of industrial fine arts",
		After: "Đại Học Mỹ Thuật Công Nghiệp",
	},
	{
		Before: "HaNoi University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hanoi University Of Industry Haui",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hanoi University of Ming and Geology",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "HANOI UNIVERSITY OF MINING AND GEOLOGY",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "hanoi university of natural resources and",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Hanoi University Of Natural Resources And Environment",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Hanoi University Of Natural Resources And Environment Hanoi ,",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Hanoi University Of Pharmacy",
		After: "Đại Học Dược Hà Nội",
	},
	{
		Before: "Hanoi University Of Public Health",
		After: "Đại Học Y Tế Công Cộng",
	},
	{
		Before: "Hanoi University Of Science",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science And",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "hanoi university of science and technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science And Technology Hust",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science And Technology Information",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science Andtechnology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science Technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Of Science Viet Nam National University Hanoi",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi University Of Sciencetechnology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Science",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Science And Technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi University Sep",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Hanoi Vietnam",
		After: "",
	},
	{
		Before: "Hanoi Vocational College Of Technology",
		After: "Cao Đẳng Nghề Bách Khoa Hà Nội",
	},
	{
		Before: "Hanoi, Vietnam",
		After: "",
	},
	{
		Before: "Hanze University Of Applied Science",
		After: "Đại Học Groningen",
	},
	{
		Before: "Hanze University Of Applied Sciences",
		After: "Đại Học Groningen",
	},
	{
		Before: "Hào Nam Group, TTS Tuyển Dung",
		After: "",
	},
	{
		Before: "HAU",
		After: "",
	},
	{
		Before: "Haui- Hanoi University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Haui- Hanoi University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Havina Language Academy, Hanoi Vietnam",
		After: "",
	},
	{
		Before: "Hc Home Center",
		After: "",
	},
	{
		Before: "Hcm City",
		After: "",
	},
	{
		Before: "HCM city University of Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "HCM City Vocational College",
		After: "Cao Đẳng Nghề TPHCM",
	},
	{
		Before: "Hcm University Of Economics",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Hcm University Of Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Hcm University Of Technology And Education",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Hcm University Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "hcm- khoa luật thương mại",
		After: "",
	},
	{
		Before: "HCM)",
		After: "",
	},
	{
		Before: "HCMC Foreign Language and Technology University",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "HCMC Industry and Trade college",
		After: "",
	},
	{
		Before: "Hcmc Open University, Vietnam",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Hcmc University Of Banking",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Hcmc University Of Economics Ho Chi Minh City",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "HCMC University of Foreign Languages & Information Technology",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Hcmc University Of Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "HCMc University Of Technology And Education",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Hcmc University Of Technology Education",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Hcmc University Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Hcmc University Technology And Education",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "HEAD OF COMMUNICATION",
		After: "",
	},
	{
		Before: "Hà Nội-University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hệ Cao đẳng Đại Học Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "hệ thống đào tạo aprotrain aptech",
		After: "",
	},
	{
		Before: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
		After: "",
	},
	{
		Before: "Hệ Thống Đào Tạo CNTT Quốc Tế Bachkhoa -",
		After: "",
	},
	{
		Before: "hệ thống đào tạo CNTT quốc tế bachkhoa aptech",
		After: "",
	},
	{
		Before: "hệ thống đào tạo CNTT quốc tế softech",
		After: "",
	},
	{
		Before: "Hệ thống đào tạo CNTT T3H",
		After: "",
	},
	{
		Before: "Hệ Cao đẳng Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hệ Thống Đào Tạo Kỹ Sư An Ninh Mạng Quốc Tế FPT Jetking",
		After: "Cao Đẳng FPT Jetking",
	},
	{
		Before: "Hệ thống đào tao lập trình viên aptech",
		After: "",
	},
	{
		Before: "Hệ Thống Đào Tạo Lập Trình Viên Quốc Tế Aptech",
		After: "",
	},
	{
		Before:
			"Hệ Thống Đào Tạo Lập Trình Viên Quốc Tế Aptech - Aprotrain, Chuyên Ngành:",
		After: "",
	},
	{
		Before: "Hệ Thống Đào Tạo Lập Trình Viên Quốc Tế FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "Hệ Thống Đào Tạo CNTT T3H- Đh Kh Tự Nhiên Tp Hcm Cơ Sở Hà Nội",
		After: "",
	},
	{
		Before: "Hệ Thống Điện",
		After: "",
	},
	{
		Before: "Hệ Thống Thông Tin",
		After: "",
	},
	{
		Before: "Hệ Thống Thông Tin Kế Toán",
		After: "",
	},
	{
		Before: "Hệ Thống Thông Tin Quản Lý",
		After: "",
	},
	{
		Before: "Hệ Thống Thông Tin Quản Lý- Viện Công Nghệ Thông Tin Và",
		After: "",
	},
	{
		Before: "HỆ THỐNG:",
		After: "",
	},
	{
		Before: "hientranhientran103@gmail.com",
		After: "",
	},
	{
		Before: "Hiện Nay Đại Học Đông Á",
		After: "Đại Học Đông Á",
	},
	{
		Before: "Hệ Thống Đào Tạo T3H Hà Nội",
		After: "",
	},
	{
		Before: "Hiện Tại Đại Học Hufi",
		After: "",
	},
	{
		Before: "Hiện Tại Đại Học Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before:
			"Hiện Tại Đang Là Sinh Viên Năm Cuối Của  Đại Học Công Nghiệp Thực Phẩm Tp Hồ Chí",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Hiện Tại Đã Tốt Nghiệp Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Hiện Tại Em Đang Là Sinh Viên Năm 4  Đại Học Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "HIGH SCHOOL FOR GIFTED STUDENTS OF VINH UNIVERSITY",
		After: "",
	},
	{
		Before:
			"High School Year 2008 To 2012 | Fahan School, Hobart, Tasmania, Australia",
		After: "",
	},
	{
		Before: "Hn-Aptechhn Aptech",
		After: "",
	},
	{
		Before: "Ho Chi City University Transport",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Ho Chi Minh",
		After: "",
	},
	{
		Before: "Ho Chi Minh City",
		After: "",
	},
	{
		Before: "Ho Chi Minh City College Of Industry And Trade",
		After: "",
	},
	{
		Before: "Ho Chi Minh City Industrial University",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Ho Chi Minh City Industry and Trade College",
		After: "",
	},
	{
		Before: "Ho Chi Minh City Industry And Trade College Major",
		After: "",
	},
	{
		Before: "Ho Chi Minh city institute of applied science and technology",
		After: "",
	},
	{
		Before: "Ho Chi Minh City Open University",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Ho Chi Minh City Open University Major Master Of Business",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Ho Chi Minh City Technical and Economic College",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Agriculture And Forestry",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Food And Industry",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of",
		After: "",
	},
	{
		Before: "Ho Chi Minh City University Of Economics And Finance Uef",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Ho Chi Minh City University of Food Industry",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of Foreign",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of Foreign Languages",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before:
			"HO CHI MINH CITY UNIVERSITY OF FOREIGN LANGUAGES ANDINFORMATION TECHNOLOGY",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before:
			"Ho Chi Minh City University Of Foreign Languages Informationtechnology",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of Science Ho Chi Minh City Vietnam",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Ho Chi Minh City University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Of Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before:
			"Ho Chi Minh City University Of Technology And Education University",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Ho Chi Minh City University of Transport",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh City University Technology And Education",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before:
			"Ho Chi Minh City Universityof Foreign Languages andInformation Technology",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Ho Chi Minh college of economic",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: "Ho Chi Minh Open University",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Ho Chi Minh Open-University",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Ho Chi Minh University Foreign",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Education",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Food Industry",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before:
			"Ho Chi Minh University Of Foreign Languages And Information Technology",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Law",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh University Of Transport",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Ho Chi Minh University Science",
		After: "",
	},
	{
		Before: "Ho Chi Minh University Technology",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: "Ho Chi Minh University Transport",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Ho Chi Minh University Vietnam",
		After: "",
	},
	{
		Before: "Ho Chi Minh Unversity of Food Industry",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Ho Chi Minh- Open University",
		After: "",
	},
	{
		Before: "Ho Chi Minh, Viet Nam",
		After: "",
	},
	{
		Before: "Ho Chi Minh, Vietnam",
		After: "",
	},
	{
		Before: "Hoa Sen University",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Hoa Sen University And Business School",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Hoa Sen University Hcmc",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Hoa Sen University Human",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Hoa Sen University Mba",
		After: "Đại Học Hoa Sen",
	},
	{
		Before:
			"Hoa-Sen-University I Also Learned Some Marketing Subjects Such As Customer",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Hoàn Thành Khóa Học Acca F3F7 Tại Sapp Academy",
		After: "",
	},
	{
		Before:
			"Hoàn Thành Khoá Học Tester Nâng Cao Tại Trung Tâm Đào Codestar Academy",
		After: "",
	},
	{
		Before: "Hoàng Tuấn Phi",
		After: "",
	},
	{
		Before: "Hobbies Watching Comedy- Reading- Invest Stock",
		After: "",
	},
	{
		Before: "Học Cấp -  Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Hiện Tại Em Đang Là Sinh Viên Năm Cuối Của  Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Học Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Học Đại Học mở hà nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Học Học Viện Tài Chính Năm",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Khoa Học Xã Hội Và Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Học Đh Kinh Tế Kỹ Thuật Công Nghiệp Hà Nội",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Học Khóa Kiểm Thử Phần Mềm Cơ Bản Tại Trung Tâm Tester Hà Nội",
		After: "",
	},
	{
		Before: "Học Lập Trình Tại FPT Aptech",
		After: "Cao Đẳng FPT Aptech",
	},
	{
		Before: "Học Khóa Kiểm Thử Phần Mềm Tại Trung Tâm Tester Hà Nội",
		After: "",
	},
	{
		Before: "Học Lập Trình Website Tại Trung Tâm Vn Ở Hà Nội",
		After: "",
	},
	{
		Before: "Học Sinh  Thpt Lê Hồng Phong Tpvũng Tàu",
		After: "",
	},
	{
		Before: "Học Lập Trình Wedsite Tại Trung Tâm Unitopvn Ở Hà Nội",
		After: "",
	},
	{
		Before: "Học Tại Đại Học Kinh Tế TPHCM Khoa Quản Trị Kinh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Học tại Đại Học công nghiệp hà nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Học tại Đại Học Mở Hà Nội.",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Học Tại Học Viện Nông Nghiệp Việt Nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Tại  Đại Học Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Học Tại  Đh Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Học Tại  Học Viện Kỹ Thuật Quân Sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Tập Tại Học Viện Tài Chính , Khoa Kế Toán ,",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Tập Tại Khoa Tài Chính Doanh Nghiệp Học Viện Tài",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Tập Tại  Đại Học Cần Thơ Chuyên Ngành Kinh Doanh Quốc Tế",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Học Tập Tại  Đại Học Công Đoàn Khoa Kế Toán Tài Chính",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Học Tập Tại  Đại Học Kinh Tế Quốc Dân Khoa Kế Toán Chuyên",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Học Tập Tại  Đại Học Thăng Long",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Học Tập Tại  Đại Học Thương Mại Khoa Kế Toán Chuyên",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Học Tiếng Nhật Tại  Văn Hóa Giáo Dục Tokyo",
		After: "",
	},
	{
		Before: "Học việc công nghệ Bưu chính Viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học viện",
		After: "",
	},
	{
		Before: "Học viện",
		After: "",
	},
	{
		Before: "Học viện  Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện An Ninh Nhân Dân",
		After: "Học Viện An Ninh Nhân Dân",
	},
	{
		Before: "Học Viện An Ninh Nhân Dân Đh Chính Quy Hệ Dân Sự Khóa",
		After: "Học Viện An Ninh Nhân Dân",
	},
	{
		Before: "Học Viện Aptech Computereducation",
		After: "",
	},
	{
		Before: "Học viên âm nhạc Huế",
		After: "Học Viện Âm Nhạc Huế",
	},
	{
		Before: "Học Viện Báo Chí",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học viện Báo chí & Tuyên truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học VIỆN BÁO CHÍ 2 TUYÊN TRUYỀN",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học viện Báo chí và Tuyên truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền | Cử Nhân Biên Tập",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Chuyên Ngành Báo Truyền Hình",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Chuyên Ngành Truyền Hình",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Tại Đại Học Nội Vụ Hà Nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Khoa Phát Thanh Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Khoa Phát Thanh Truyền Hình",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Khoa Quan Hệ Quốc Tế",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Truyền Thông Đa Phương Tiện",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học viện Cảnh sát Nhân dân",
		After: "Học Viện Công Nghệ Bkacad",
	},
	{
		Before: "Học viện Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Cán Bộ TPHCM",
		After: "Học Viện Cán Bộ TPHCM",
	},
	{
		Before: "Học Viện Cán Bộ Tphcm",
		After: "Học Viện Cán Bộ TPHCM",
	},
	{
		Before: "Học VIỆN CẢNH SÁT NHÂN DÂN",
		After: "Học Viện Cảnh Sát Nhân Dân",
	},
	{
		Before: "Học Viện Ceo Việt Nam Chuyên Ngành Marketing",
		After: "",
	},
	{
		Before: "Học Viện Chỉ Huy Tham Mưu Kỹ Thuật Tên Lửa C",
		After: "",
	},
	{
		Before: "Học Viện Chính Sách",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học Viện Chính Sách Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học viện Chính Sách và Phát",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học viện chính sách và phát triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học viện Chính sách và Phát triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học VIỆN CHÍNH SÁCH VÀ PHÁT TRIỂN - APD",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học Viện Chính Sách Và Phát Triển Kinh Tế Đối Ngoại",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Học Viện Báo Chí Và Tuyên Truyền Hà Nội",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Học viện cn bưu chính viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện CNTT Bách Khoa Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Học Viện CNTT Bách Khoa Bkacad",
		After: "Học Viện Công Nghệ Bkacad",
	},
	{
		Before: "Học Viện Codestar |",
		After: "",
	},
	{
		Before: "Học Viện Công Nghệ Bkacad",
		After: "",
	},
	{
		Before: "Học Viện Chùa Bộc Hà Nội",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học viện Công nghệ Bưu chính và viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học viện công nghệ bưu chính viễn",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học viện Công nghệ Bưu chính viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông  Cở Sở HCM",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học viên Công nghệ Bưu chính Viễn Thông (PTIT)",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông | Chuyên Ngành",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông An Toàn Thông Tin",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before:
			"Học Viện Công Nghệ Bưu Chính Viễn Thông Chuyên Ngành Công Nghệ Phần Mềm",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học viện công nghệ bưu chính viễn thông chuyên ngành kế toán",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Chuyên Nghành Hệ Thống",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Công Nghệ",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở Hồ Chí Minh",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở TPHCM",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở Tp Hồ Chí Minh",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở Tp. Hồ Chí Minh",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở Tphồ Chí Minh",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học viện Công nghệ Bưu chính Viễn Thông Hồ Chí Minh",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Năm Học",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Ngành",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Ptit",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ Bưu Chính Viễn Thông Tphcm",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông Cơ Sở 2, TPHCM",
	},
	{
		Before: "Học Viện Công Nghệ FPT",
		After: "",
	},
	{
		Before: "Học Viện Công Nghệ Bkacad- Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Học Viện Công Nghệ Thông Tin Bách Khoa Bkacad",
		After: "",
	},
	{
		Before: "Học Viện Công Nghệ Thông Tin Bkacad",
		After: "",
	},
	{
		Before: "Học Viện Công Nghệ Thông Tin Và Thiết Kế Vtc",
		After: "",
	},
	{
		Before: "Học Viện Công Nghiệ Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Học Viên Của Học Viện Fresher Academy Fsoft",
		After: "",
	},
	{
		Before: "Học Viện Đào Tạo Devmaster",
		After: "",
	},
	{
		Before: "Học VIỆN ĐÀO TẠO QUẢN TRỊ MẠNG CAO CẤP PNH",
		After: "",
	},
	{
		Before: "Học viện điện lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "Học viện FPT jetking",
		After: "Cao Đẳng FPT Jetking",
	},
	{
		Before: "Học Viện Hàng Không",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "Học viện Hàng Không Việt Nam",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "Học viện hành chính",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Học viện hành chính quốc gia",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Học Viện Hành Chính Quốc Gia , Quản Lý Nhà Nước Về",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Học Viện Hành Chính Quốc Gia Việt Nam",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "Học VIỆN HẬU CẦN",
		After: "Học Viện Hậu Cần",
	},
	{
		Before: "Học Viện Ipmac",
		After: "",
	},
	{
		Before: "Học Viện It",
		After: "",
	},
	{
		Before: "Học Viện Kế Toán Kiểm Toán",
		After: "",
	},
	{
		Before: "Học Viện Kế Toán Tổng Hợp",
		After: "",
	},
	{
		Before: "Học viện khoa Học quân sự",
		After: "Học Viện Khoa Học Quân Sự",
	},
	{
		Before: "Học viện khoa Học quân sự (Hệ Dân sự)",
		After: "Học Viện Khoa Học Quân Sự",
	},
	{
		Before: "Học Viện Kĩ Thuật Mật Mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Học Viện Kĩ Thuật Mật Mã Công Nghệ Thông Tin",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Học VIỆN KĨ THUẬT QUÂN SỰ",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kĩ Thuật Quân Sự Hệ Dân Sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Mật",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "học viện kỹ thuật mật mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Học viện Kỹ thuật mật mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Học Viện Kỹ Thuật Mật Mã , Chuyên Ngành",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự (Hệ Dân Sự)",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự Chuyên Ngành",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự Công Nghệ Phần Mềm",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự Cử Nhân Công Nghệ Mạng",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự Điện Điện Tử Điện Tử Viễn Thông",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viên Công Nghệ Niit- Aptech Hà Nội",
		After: "",
	},
	{
		Before: "Học Viện Mạng Phần Cứng FPT Jetking",
		After: "",
	},
	{
		Before: "Học Viện Múa Việt Nam",
		After: "Học Viện Múa Việt Nam",
	},
	{
		Before: "Học Viện Ngành Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Học viện ngân hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Kỹ Thuật Quân Sự Tester Hà Nội",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Học Viện Ngân Hàng Banking Academy",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Chuyên Ngành Hệ Thống Thông Tin Quản Lý",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Chuyên Ngành Tài Chính Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học viện Ngân hàng (Đống Đa - Hà Nội)",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Hệ Thống Thông Tin Quản Lý",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Kế Toán",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Kế Toán Kiểm Toán",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Khoa Tài Chính Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Luật Kinh Tế",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Quản Trị Kinh Doanh",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Tài Chính Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học viện Ngân hang Tốt nghiệp Giỏi",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Ngân Hàng Hà Nội",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before:
			"Học Viện Ngân Hàng- Khoa Liên Kết Đại Học Cityuniversity Of Seattle Quản Trị",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học viện ngoại giao",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Học Viện Ngoại Giao Diplomatic Academy Of Vietnam",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Học Viện Ngoại Giao Kinh Tế Quốc Tế",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Học viện Ngoại giao Việt Nam",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Học Viện Ngọai Giao Việt Nam Chuyên Ngành Quan Hệ Quốc Tế",
		After: "Học Viện Ngoại Giao Việt Nam",
	},
	{
		Before: "Học viện nông nghiệp",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam ,",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam Chuyên Ngành Công Nghệ Thông",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam Chuyên Ngành Kế Toán",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam Chuyên Ngành Nông Nghiệp Pohe",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học VIỆN NÔNG NGHIỆP VIỆT NAM CÔNG NGHỆ SINH Học",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Việt Nam Cử Nhân Nông Nghiệp",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Nông Nghiệp Vn",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Học Viện Phần Cứng Và Mạng FPT Jetking",
		After: "",
	},
	{
		Before: "Học Viện Phụ Nữ Việt Nam",
		After: "Học Viện Phụ Nữ Việt Nam",
	},
	{
		Before: "Học Viện Phụ Nữ Việt Nam, Quản trị Kinh Doanh",
		After: "Học Viện Phụ Nữ Việt Nam",
	},
	{
		Before: "Học Viện Quản Lí Giáo Dục",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học Viện Quản Lý",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học Viện Quản Lý Giáo Dục",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học viện quản lý Giáo dục",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học VIỆN QUẢN LÝ GIÁO DỤC | 2015 -",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học viện Quản lý giáo dục.",
		After: "Học Viện Quản Lý Giáo Dục",
	},
	{
		Before: "Học Viện Quản Lý Và Tổ Chức Nhân Sự",
		After: "",
	},
	{
		Before: "Học Viện Quân Y",
		After: "Học Viện Quân Y",
	},
	{
		Before: "Học Viện Quốc Tế",
		After: "",
	},
	{
		Before: "Học VIỆN QUỐC TẾ HANA - NHẬT BẢN",
		After: "",
	},
	{
		Before: "Học Viện Sage",
		After: "",
	},
	{
		Before: "Học Viện Sapp",
		After: "",
	},
	{
		Before: "Học Viện Sư Phạm Hành Dương Hồ Nam Trung Quốc",
		After: "Đại Học Sư Phạm Hồ Nam",
	},
	{
		Before: "Học Viện Tài Chín",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học viện tài chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính , Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"Học Viện Tài Chính Chuyên Ngành Hải Quan Và Nghiệp Vụ Ngoại Thương",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Hệ Thống Thông Tin Quản Lý",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Kế Toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Kế Toán Kiểm Toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Kiểm Toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"Học Viện Tài Chính Chuyên Ngành Marketing Khoa Quản Trị Kinh Doanh",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Tài Chính Bảo Hiểm",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Chuyên Ngành Tiếng Anh Thương Mại",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Đầu Tư Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Đh Toulon",
		After: "Đại Học Toulon",
	},
	{
		Before: "Học Viên Ngân Hàng- 12 Chùa Bộc Đống Đa Hà Nội",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Học Viện Tài Chính Hà Nội",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Hệ Thống Thông Tin Kinh Tế",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Hệ Thống Thông Tin Quản Lý",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Kế Toán Công",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Kế Toán Doanh",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Khoa Ngân Hàng Bảo Hiểm",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Khoa Quản Trị Kinh Doanh",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Kinh Tế Luật",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Marketing",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Ngành Hệ Thống Thông Tin",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Ngành Học Kinh Tế",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Ngành Tài Chính Ngân Hàng",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Ngân Hàng",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Ngân Hàng Bảo Hiểm",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học viện tài chính hà nội chuyên ngành kế toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Thuế",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Thuế Hải Quan",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Tiếng Anh Tài Chính Kế Toán",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính Từ Năm",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học viện Tài Chính và Đại Học Macquarie",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chính- Greenwich University",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "Học Viện Tài Chính- Liên Kết Đại Học Toulon",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Tài Chínhyendung.topcv.vn",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Học Viện Thạc Sĩ Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Học viện thanh thiếu niên",
		After: "Học Viện Thanh Thiếu Niên Việt Nam",
	},
	{
		Before: "Học viện thanh thiếu niên Việt Nam",
		After: "Học Viện Thanh Thiếu Niên Việt Nam",
	},
	{
		Before: "Học Viện Thương Hiệu",
		After: "",
	},
	{
		Before: "Học Viện Thương Hiệu Plato",
		After: "",
	},
	{
		Before: "Học Viện Toà Án",
		After: "Học Viện Tòa Án",
	},
	{
		Before: "Học Viện Tòa Án Chuyên Ngành Luật Học",
		After: "Học Viện Tòa Án",
	},
	{
		Before: "Học Viên Trung Tâm Đào Tạo Kế Toán Thực Tế Ces",
		After: "",
	},
	{
		Before: "Học Viện Tư Pháp Lớp Đào Tạo Luật Sư Khóa",
		After: "Học Viện Tư Pháp",
	},
	{
		Before: "Học viện vtc",
		After: "",
	},
	{
		Before: "Học Viện Vti",
		After: "",
	},
	{
		Before: "Học Viện Vti Academy",
		After: "",
	},
	{
		Before: "Học Viện Y Học Cổ Truyền Việt Nam",
		After: "Học Viện Y Học Cổ Truyền Việt Nam",
	},
	{
		Before: "Học Wordpress Tại Fgv Studio",
		After: "",
	},
	{
		Before: "Hochiminh City University Of Foreign",
		After: "",
	},
	{
		Before: "Hochiminh City University Of Technology",
		After: "",
	},
	{
		Before: "Hong Bang International University",
		After: "Đại Học Quốc Tế Hồng Bàng",
	},
	{
		Before: "Hong Ha University Tp Mông Tự Tỉnh Vân Nam Trung Quốc",
		After: "Học Viện Hồng Hà, Trung Quốc",
	},
	{
		Before: "Hồ Chí Minh City University Of Technical Education",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: "Hội Sinh Viên Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Hội Trưởng Hội Lưu Học Sinh Tại Đại Học Dân Tộc Quảng Tây",
		After: "",
	},
	{
		Before: "Hsb-  Đại Học Qghn Hanoi School Of Business And Management",
		After: "",
	},
	{
		Before: "Https-Quaythungancom",
		After: "",
	},
	{
		Before: "Hubspot Academy",
		After: "",
	},
	{
		Before: "Hubt Hanoi",
		After: "",
	},
	{
		Before: "Hue Science University",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: "Hue University Of Foreign Languages Fulltime",
		After: "",
	},
	{
		Before: "Huflit University",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "HUFUT - NGOAI NGU TIN HOC UNIVERSITY",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "hug yen university of technology and education",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Hung Yen Province",
		After: "",
	},
	{
		Before: "Hung Yen University Of Technology And",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Hung Yen University Of Technology And Education",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "HUST",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Hust University",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "HUTECH",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech University",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech University Of Technology",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech University Technology",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech- Đại Học Công Nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Hutech-Đại Học Công Nghệ Tp Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "HV Báo Chí Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "HV Công nghệ Bưu chính viễn thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "HV Công nghệ Bưu chính Viễn thông (cơ sở phía Bắc)",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "HV Hàng Không Việt Nam",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "HV Kĩ Thuật Mật Mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "HV Kỹ Thuật Mật Mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "HV Kỹ thuật Quân sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "HV Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "hv nông nghiệp việt nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "HV Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"I N T E R N A T I O N A L- E N G L I S H- L A N G U A G E- Te S T I N G- S Y S T E M",
		After: "",
	},
	{
		Before: "I| Đại Học Ngoại thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Iccc- Foreign Trade University Hcmc Nov",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Ictu University",
		After: "",
	},
	{
		Before: "Iig Vietnam",
		After: "",
	},
	{
		Before: "ILA   OVERSEA STUDY CENTER",
		After: "",
	},
	{
		Before: "Ila English Center",
		After: "",
	},
	{
		Before: "Imc University Of Applied Sciences Krems Austria",
		After: "Đại Học Khoa Học Ứng Dụng IMC Krems",
	},
	{
		Before: "Industrial Technical University",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Industrial University Hcmc",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Industrial University Ho Chi Minh City",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Industrial University Of Ho Chi Minh City",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Industrial University Of Ho Chi Minh Citysoftware Engineer",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Industrial-University",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Information And Communication Technology",
		After: "",
	},
	{
		Before: "Information Of Technology- Ho Chi Minh City Viet Nam",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "Information Science And Technology",
		After: "",
	},
	{
		Before: "Information Technology",
		After: "",
	},
	{
		Before: "Information Technology And Communication Thai Nguyen University",
		After: "#N/A",
	},
	{
		Before: "Information technology College",
		After: "",
	},
	{
		Before: "Information Technology Graduation Project",
		After: "",
	},
	{
		Before: "Information Technology Hanoi Vocational College Technology",
		After: "Cao Đẳng Nghề Bách Khoa Hà Nội",
	},
	{
		Before: "INHINI IDIAL AD AAD AAn Tonk Congolingo",
		After: "",
	},
	{
		Before: "Institute of Technology",
		After: "",
	},
	{
		Before: "Institute Of Technology FPT Software Academy",
		After: "",
	},
	{
		Before: "Institute University Nantes University France",
		After: "Đại Học Nantes",
	},
	{
		Before: "Integrated Circuit Design Research And Education Center",
		After: "",
	},
	{
		Before: "intermediate - Nhất Nghệ",
		After: "",
	},
	{
		Before: "Intern Net FPT Software",
		After: "",
	},
	{
		Before: "International Business",
		After: "",
	},
	{
		Before: "International Business Competition Coordinator Tedx Events",
		After: "",
	},
	{
		Before: "International Business Management",
		After: "",
	},
	{
		Before: "International Bussiness Administration",
		After: "",
	},
	{
		Before: "International Economics",
		After: "",
	},
	{
		Before: "International Economics And Business Distinction",
		After: "",
	},
	{
		Before: "International Economics Foreign Trade University",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "International Economy",
		After: "",
	},
	{
		Before: "International Finance",
		After: "",
	},
	{
		Before: "international human resource",
		After: "",
	},
	{
		Before: "International Human Resource",
		After: "",
	},
	{
		Before: "International Labour Organization",
		After: "",
	},
	{
		Before: "International Management",
		After: "",
	},
	{
		Before: "International Pacific University Japan",
		After: "",
	},
	{
		Before: "International Relations",
		After: "",
	},
	{
		Before: "International School",
		After: "",
	},
	{
		Before: "international school  vietnam national university",
		After: "",
	},
	{
		Before: "International School - Hanoi National University Vietnam",
		After: "",
	},
	{
		Before: "International School Of Business Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "International School Vietnam National University",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "International School Vnu",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "International Standard Program",
		After: "",
	},
	{
		Before: "International Stem Association Center",
		After: "",
	},
	{
		Before: "International Trade And Business Management",
		After: "",
	},
	{
		Before: "International Trade And Finance",
		After: "",
	},
	{
		Before: "International Trade Policy",
		After: "",
	},
	{
		Before: "International Transport",
		After: "",
	},
	{
		Before: "International University",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "International University Vietnam National University",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: "International University Vnu Hcmc",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before:
			"Iso-Iatf Staff Of Production Department And Production Engineering Department",
		After: "",
	},
	{
		Before: "Issued in 02 07 2016 by IIG Viet Nam",
		After: "",
	},
	{
		Before: "Istqb Foundation Certification",
		After: "",
	},
	{
		Before: "It Plus Academy",
		After: "",
	},
	{
		Before: "Học viện Tài chính ngân hàng Hà Nội",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "It T3H Center",
		After: "",
	},
	{
		Before: "Itmax Center",
		After: "",
	},
	{
		Before: "Itms Coaching Academy",
		After: "",
	},
	{
		Before: "ITPLUS ACADEMY",
		After: "",
	},
	{
		Before: "Iuh- Đại Học Công Nghiệp Tphcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "James Cook University Of Singapore , Business And",
		After: "Đại Học James Cook",
	},
	{
		Before: "James Cook University Singapore",
		After: "Đại Học James Cook",
	},
	{
		Before: "Jamsab Computer, Ahmedaba",
		After: "",
	},
	{
		Before: "Job Fair at University of Industry",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Join The Foundation Techmaster",
		After: "",
	},
	{
		Before: "June 2014-- Graduated From University With Good Degree",
		After: "",
	},
	{
		Before: "Junior- College Of Foreign",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Jutimi Group",
		After: "",
	},
	{
		Before: "Kdu Penang University College",
		After: "Cao Đẳng Đại Học Uow Malaysia Kdu Penang",
	},
	{
		Before: "Keuka College New York Major International Business",
		After: "Cao Đẳng Keuka",
	},
	{
		Before:
			"Kế Lộ Trình Đào Tạo Phù Hợp Nhất Với Định Hướng Phát Triển Của Công Ty Tôi",
		After: "",
	},
	{
		Before: "Kế Toán Danh Nghiệp- Cao đẳng Kinh Tế Đối Ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "Kế Toán Doanh Nghiệp Đại Học Gia Định",
		After: "Đại Học Gia Định",
	},
	{
		Before: "Kế Toán Doanh Nghiệp Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Kế Toán Doanh Nghiệp Và Khai Báo Thuế",
		After: "",
	},
	{
		Before: "Kế Toán Đại Học Kinh Tế Huế Kế Toán",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: "It Plus Ecademy- Đhqg Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Kế Toán Phần Mềm Misa Của Trung Tâm Kế Toán Hợp Nhất",
		After: "",
	},
	{
		Before:
			"Kế Toán Tổng Hợp-Chương Trình Đào Tạo Kế Toán-Kiểm Toán Của Viện Đào Tạo Nhân Lực Ngân Hàng",
		After: "",
	},
	{
		Before: "Kế Toán Trưởng- Cấp Bởi Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Kế Toán- Học Viện Hậu Cần",
		After: "Học Viện Hậu Cần",
	},
	{
		Before: "Khác",
		After: "",
	},
	{
		Before: "Khác   Language Link Vietnam",
		After: "",
	},
	{
		Before: "Khác - Đại Học Carnegie Mellon University tại Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Khác - Đại Học Kinh Tế TP HCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Khác - Học Viện Tư Pháp",
		After: "Học Viện Tư Pháp",
	},
	{
		Before: "Khác Hrc Academy",
		After: "",
	},
	{
		Before: "Khác National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Khác- Cục An Toàn Lao Động Việt Nam",
		After: "",
	},
	{
		Before: "Khác- Đại Học Gtvt Phân Hiệu Tại Tp Hồ Chí Minh",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Khác- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Khác- Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Khác- Đại Học Xây Dựng",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Khác- Ho Chi Minh University Economics",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Khác- Học Viện Đào Tạo Mvv Coaching",
		After: "",
	},
	{
		Before: "Khác- Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Khác- Học Viện Tư Pháp",
		After: "Học Viện Tư Pháp",
	},
	{
		Before: "Khác- Industrial University Hcmc",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: "Khác- International Human Resource",
		After: "",
	},
	{
		Before: "Khác- Khoa Hoc Thưc Hanh Nghiêp Vu Nhân Sư",
		After: "",
	},
	{
		Before: "Khác- Merism-The Training Center",
		After: "",
	},
	{
		Before: "Khác-  Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Khách Sạn Bằng Cách Gọi Điện Thoại, Gửi Mail…",
		After: "",
	},
	{
		Before: "Khách Sạn Grand Tourane-252 Võ Nguyên Giáp-Đà Nẵng",
		After: "",
	},
	{
		Before: "khoa cnattt",
		After: "",
	},
	{
		Before: "Kế Toán Hà Nội",
		After: "",
	},
	{
		Before: "khoa công nghệ thông tin",
		After: "",
	},
	{
		Before: "KHOA CÔNG NGHỆ THỰC PHẨM",
		After: "",
	},
	{
		Before: "Khoa Du Lịch - Đại Học Huế",
		After: "Đại Học Huế",
	},
	{
		Before: "Khoa Đạo diễn",
		After: "",
	},
	{
		Before: "Khoa Điện Tử Công Nghiệp",
		After: "",
	},
	{
		Before: "khoa ha nôi",
		After: "",
	},
	{
		Before: "khoa hệ thống thông tin quản lý mis",
		After: "",
	},
	{
		Before: "Khoá Học Bồi Dưỡng Hướng Dẫn Viên Tại Đà Nẵng",
		After: "",
	},
	{
		Before: "Khóa Học Kế Toán Thuế Chuyên Sâu Tại Công Ty Tnhh Sahada",
		After: "",
	},
	{
		Before: "Khóa Học Kế Toán Trưởng-  Đh Kinh Tế Tphcm",
		After: "",
	},
	{
		Before:
			"Khóa Học Kỹ Năng Mềm Được Cấp Chứng Nhận Của  Đại Học Kinh Tế Tphcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "KHOA Học MÁY TÍNH",
		After: "",
	},
	{
		Before: "Khoa Học Quản Lý",
		After: "",
	},
	{
		Before: "Khoa Học tự nhiên hồ chí minh",
		After: "",
	},
	{
		Before: "Khoa Kế Toán",
		After: "",
	},
	{
		Before: "Khoa Kế Toán KIểm Toán",
		After: "",
	},
	{
		Before: "Khoa Kế Toán Tài Chính",
		After: "",
	},
	{
		Before: "Khoa Kế Toán Tiếng Anh",
		After: "",
	},
	{
		Before: "Khoa kế toán  Đại Học Công Đoàn",
		After: "",
	},
	{
		Before: "Khoa Kế Toán  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Khoa Kế Toán--Đại Học Lao Động Và Xã Hội",
		After: "",
	},
	{
		Before: "Khoa Kế Toán- Đại Học Kinh Tế Kỹ",
		After: "",
	},
	{
		Before: "Khoa Khoa Học xã hội và Nhân văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Khoa Khoa Kinh Tế",
		After: "",
	},
	{
		Before: "Khoa Khoa Kinh Tế Và Quản Lý",
		After: "",
	},
	{
		Before: "Khoa Kinh doanh thương mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "khoa kinh tế",
		After: "",
	},
	{
		Before: "Khoa Kinh Tế Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Khoa Kinh Tế Luật- ĐH quốc gia TPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Khoa Kinh tế phát triển",
		After: "",
	},
	{
		Before: "Khoa Kinh Tế Và Quản Lý Nguồn Nhân Lực",
		After: "",
	},
	{
		Before: "Khóa Luận Chuyên Ngành Kế Toán Tại  Đại",
		After: "",
	},
	{
		Before: "Khoa CNTT- Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Khoa Luật - Đại Học Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before:
			"Khoa Luật - Đại Học Quốc gia Hà Nội Thac si Luật Dân sự và tổ tung",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật - ĐH Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật Đại Học Quốc Gia Hà Nội Chuyên Ngành Luật Kinh Doanh",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật Đhqghn",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật Đhqg Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật- Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Khoa Luật- Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật- Đại Học Quốc Gia Hà Nội Chuyên Ngành Luật Học",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật- Đại Học Quốc Gia Hà Nội Luật Học",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật- Đại Học Quốc Gia Hà Nội Luật Kinh Doanh",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Luật-Đại Học Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Lữ Hành Hướng Dẫn",
		After: "",
	},
	{
		Before: "Khoa Ngôn Ngữ Anh Ngành kép kinh tế",
		After: "",
	},
	{
		Before: "Khoa Ngôn ngữ và",
		After: "",
	},
	{
		Before: "Khoa Phát Thanh Truyền Hình",
		After: "",
	},
	{
		Before: "Khoa Phát Thanh Truyền Hình Chuyên Ngành Báo Mạng Điện Tử",
		After: "",
	},
	{
		Before: "Khoa Quản Lý Nguồn Nhân Lực",
		After: "",
	},
	{
		Before: "KHOA QUẢN TRỊ KINH DOANH",
		After: "",
	},
	{
		Before: "Khoa Quản Trị Nhân Lực",
		After: "",
	},
	{
		Before: "Khoa Quốc Tế",
		After: "",
	},
	{
		Before: "Khoa Quốc Tế - Đại Học Thái Nguyên",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Khoa Luật, Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Khoa Quốc Tế Đại Học Quốc Gia Hà Nội",
		After: "",
	},
	{
		Before: "Khoa Quốc Tế-  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Khoa Tài Chính",
		After: "",
	},
	{
		Before: "Khoa Tài Chính Kế Toán",
		After: "",
	},
	{
		Before: "Khoa Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Khoá Tester Vti Academy",
		After: "",
	},
	{
		Before: "Khoa Thiết Kế Đồ Hoạ",
		After: "",
	},
	{
		Before: "Khoa Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "KHOA THƯƠNG MẠI QUỐC TẾ",
		After: "",
	},
	{
		Before: "Khoa Quốc Tế- Đại Học Quốc Gia Hà Nội",
		After: "",
	},
	{
		Before: "Khoa Tiếng Anh Thương Mại",
		After: "",
	},
	{
		Before: "Khoa Tiếng Anh Đh Ngoại Ngữ Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Khoa Tin Học kế toán",
		After: "",
	},
	{
		Before: "Khoa Tin Học Kinh Tế",
		After: "",
	},
	{
		Before: "Khoa Truyền Thông Phát Triển",
		After: "",
	},
	{
		Before: "Khoa Văn Hóa Học",
		After: "",
	},
	{
		Before: "Khoa Viết Văn Báo Chí",
		After: "",
	},
	{
		Before: "Khoang thời gian làm thiết kế và chup anh d công ty",
		After: "",
	},
	{
		Before: "Không có",
		After: "",
	},
	{
		Before: "Khoa Tiếng Anh  Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "KINGSTON INTERNATIONAL SCHOOL",
		After: "",
	},
	{
		Before: "Kingston University",
		After: "Đại Học Kingston ",
	},
	{
		Before: "Kĩ Sư Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Kinh doanh công nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Kinh tế kỹ thuật công nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Kinh tế quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Kinh Tế Quốc Tế-|-10 2016- 08 2020 Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Kinh Tế Xây Dựng Công Trình Giao Thông- Đại Học Giao Thông Vận Tải",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Kinh Tế- Đại Học Quốc Gia Hà",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "KMA",
		After: "",
	},
	{
		Before: "Kma Học Viện Kĩ Thuật Mật Mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Kobe University Major Master Program Of Economics",
		After: "Đại Học Kobe",
	},
	{
		Before: "Kobe University Of Foreign Language March",
		After: "Đại Học Kobe",
	},
	{
		Before: "Korea Institute Of Science And Technology",
		After: "Viện Khoa Học Và Công Nghệ Hàn Quốc",
	},
	{
		Before: "Kumasi Technical University",
		After: "Đại Học Kỹ Thuật Kumasi",
	},
	{
		Before:
			"Kỹ Sư Công Nghệ Thông Tin Ngành Hệ Thống Thông Tin- Chương Trình Chính Quy 5 Năm Đại Học Bách Khoa Hà",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Kỹ Thuật Máy Tính-|-2018- 2023 Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "La Trobe University",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Là Sinh Viên  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "La Trobe University Hanu Campus",
		After: "",
	},
	{
		Before: "labor and social university II",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Lac Hong University",
		After: "Đại Học Lạc Hồng",
	},
	{
		Before: "Làm Việc Kế Toán Tổng Hợp Và Kế Toán Thuế Tại Công Ty Cổ",
		After: "",
	},
	{
		Before: "Languages And Information Technology",
		After: "",
	},
	{
		Before: "latrobe university",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Latrobe University Australia",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Lập Trình Viên Quốc Tế Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: "Lấy Chứng Chỉ Kế Toán Trưởng Của Đại Học Kinh Tế",
		After: "",
	},
	{
		Before: "Le Quy Don Ha Dong High School",
		After: "",
	},
	{
		Before: "Le Quy Don Highschool",
		After: "",
	},
	{
		Before: "Le Quy Don University",
		After: "",
	},
	{
		Before: "Leader Team Media",
		After: "",
	},
	{
		Before: "LEADMAN",
		After: "",
	},
	{
		Before: "LEGAL CONSULTING CENTER OF HANOI LAW UNIVERSITY, Hanoi, Vietnam",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Leibniz University Hannover",
		After: "Đại Học Hanover",
	},
	{
		Before: "Les Roches International School Of",
		After: "",
	},
	{
		Before: "Lê Thế Cần",
		After: "",
	},
	{
		Before: "Lên Plan Content Và Phát Triển Content Fanpage Halo Đà Nẵng",
		After: "",
	},
	{
		Before: "Lightning Management System",
		After: "",
	},
	{
		Before: "Lincoln University",
		After: "Đại Học Lincoln",
	},
	{
		Before: "Logistics Được Cấp Bởi Đại Học Rutgers",
		After: "",
	},
	{
		Before: "London Metropolitant University",
		After: "Đại Học Thủ Đô Luân Đôn",
	},
	{
		Before: "Lotus Academy",
		After: "",
	},
	{
		Before: "Loughborough University London United Of Kingdom",
		After: "Đại Học Loughborough Luân Đôn",
	},
	{
		Before: "Lviv Polytechnic National University Ukraine",
		After: "Đại Học Quốc Gia Bách Khoa Lviv",
	},
	{
		Before: "Machine Learning Online Course Of Stanford University",
		After: "",
	},
	{
		Before: "Macquarie University",
		After: "Đại Học Macquarie",
	},
	{
		Before: "Magestore",
		After: "",
	},
	{
		Before:
			"Major Accounting And Financial Management- La Trobe University Melbourne Australia",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Major Computer Networks And Data Communications",
		After: "",
	},
	{
		Before: "major information software",
		After: "",
	},
	{
		Before: "Major Information System",
		After: "",
	},
	{
		Before: "major information technology",
		After: "",
	},
	{
		Before: "Major International Business",
		After: "",
	},
	{
		Before: "Major International Business Marketing Specialization",
		After: "",
	},
	{
		Before: "Major International Trade Law",
		After: "",
	},
	{
		Before: "Major Management Information System",
		After: "",
	},
	{
		Before: "major software technology",
		After: "",
	},
	{
		Before: "Major Vietnam Academy Of Cryptography Techniques",
		After: "",
	},
	{
		Before: "Major: Business Administration, FPT University",
		After: "",
	},
	{
		Before: "Major: Computer Engineering Technology",
		After: "",
	},
	{
		Before: "Major: Control And Automation Technology",
		After: "",
	},
	{
		Before: "Major: Engineer Of Information Technology",
		After: "",
	},
	{
		Before: "Major: Imformation Technology",
		After: "",
	},
	{
		Before: "Major: Information System",
		After: "",
	},
	{
		Before: "Major: Information Technology",
		After: "",
	},
	{
		Before:
			"Major: Information Technology | Oct 2019 May 2023 Hanoi University",
		After: "",
	},
	{
		Before: "Major: International Finance",
		After: "",
	},
	{
		Before: "Majors: International Business",
		After: "",
	},
	{
		Before: "Management Accounting And Accounting Of Banking Academy",
		After: "",
	},
	{
		Before: "Managerment Organization And Human Rerources",
		After: "",
	},
	{
		Before: "Manoa",
		After: "",
	},
	{
		Before: "March 2021 Study Chinese at BUS Center",
		After: "",
	},
	{
		Before: "Marie Curie Hanoi School",
		After: "",
	},
	{
		Before: "Market Ing T Ại S Age-Academy",
		After: "",
	},
	{
		Before: "MARKET RESEARCH PROJECT",
		After: "",
	},
	{
		Before: "Marketing 2019-City University Of Seattle",
		After: "Đại Học Thành Phố Seattle",
	},
	{
		Before: "Marketing Analytics University Southampton",
		After: "Đại Học Southampton",
	},
	{
		Before: "Massey University Auckland Nz",
		After: "Đại Học Massey",
	},
	{
		Before:
			"Master Ai And Data Science, Hanoi University Of Science And Technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Master Of International Business",
		After: "",
	},
	{
		Before:
			"Master Of Science Information And Communication Engineering, University Of Trento",
		After: "Đại Học Trento",
	},
	{
		Before: "Master- Hochiminh University Of Technology",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "Master-01 2018-University Of Lincoln Uk",
		After: "Đại Học Lincoln",
	},
	{
		Before: "Master-Of-Business-Administration,-University Of Business And",
		After: "",
	},
	{
		Before: "Master, Ha Noi University Science And Technology",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Master, Hanoi University Mining And Geology",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Masters National Economic University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Masters- Latrobe University Australia",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Mba General Management Southeast Missouri State University",
		After: "Đại Học Bang Đông Nam Missouri",
	},
	{
		Before: "Md Nail Studio",
		After: "",
	},
	{
		Before: "Member Of Association Of Chartered Certified Accountants Acca",
		After: "",
	},
	{
		Before: "Merit-Jan 2019-University Of Hull",
		After: "Đại Học Hull",
	},
	{
		Before: "Mersin University Turkey",
		After: "Đại Học Mersin ",
	},
	{
		Before: "Methodologies Backup And Recovery Software",
		After: "",
	},
	{
		Before: "Mềm-Khoa Công Nghệ Thông Tin",
		After: "",
	},
	{
		Before: "Military Technical Academy",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Military Technology Academy, Hanoi, Vietnam",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Mindx Technology School",
		After: "",
	},
	{
		Before: "Mindx- Technology-Startup School",
		After: "",
	},
	{
		Before: "Ming Chuan University",
		After: "Đại Học Minh Truyền",
	},
	{
		Before: "Minh Truyền - Đài Loan",
		After: "Đại Học Minh Truyền",
	},
	{
		Before: "Minh Vietnam",
		After: "",
	},
	{
		Before: "minhanhng105gmailcom",
		After: "",
	},
	{
		Before: "Minhjamesmartingmailcom",
		After: "",
	},
	{
		Before: "Ministry Academy Of Finance May",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Mirr Design Center",
		After: "",
	},
	{
		Before: "Misa Joint Stock Company",
		After: "",
	},
	{
		Before: "Misa Jscmisa Jsc",
		After: "",
	},
	{
		Before: "MMG) - Thực tập sinh tuyển dụng",
		After: "",
	},
	{
		Before: "Mỏ địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Mock Project Of Fresher Academy",
		After: "",
	},
	{
		Before: "Model European Union New",
		After: "",
	},
	{
		Before: "Monron Monroe La",
		After: "",
	},
	{
		Before: "Moscow Pedagogical State University",
		After: "Đại Học Sư phạm Quốc gia Moskva",
	},
	{
		Before: "La Trobe University |  Đại Học La Trobe tại Hà Nội",
		After: "Đại Học La Trobe",
	},
	{
		Before: "Msc In International Hospitality Business",
		After: "",
	},
	{
		Before: "Msc International Marketing",
		After: "",
	},
	{
		Before: "MTA MILITARY TECHNICAL ACADEMY",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "Mta University",
		After: "Đại Học Mount Allison",
	},
	{
		Before: "Multimedia",
		After: "",
	},
	{
		Before: "Mvv Academy",
		After: "",
	},
	{
		Before: "Myoung Ji University Seoul Korea",
		After: "Đại Học Myongji",
	},
	{
		Before: "Name Of School Center",
		After: "",
	},
	{
		Before: "Name Of School Or University",
		After: "",
	},
	{
		Before: "Namviet Land Co Ltd",
		After: "",
	},
	{
		Before: "Nanoi University Of Home Affairs",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "Nantes University",
		After: "Đại Học Nantes",
	},
	{
		Before: "Natiomal Ecomomics University, Major: Business Law",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Natiomal University of Singapore (NUS), Singapore",
		After: "Đại Học Quốc gia Singapore",
	},
	{
		Before: "Nation Economic University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Academy Of Public Administration",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "National Academy Of Public Administration University",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "National Academy Of Public Administrattion",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: "National American University",
		After: "Đại Học Quốc Gia Hoa Kỳ",
	},
	{
		Before: "National Cheng Kung University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economic University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economic University Bachelor Of Marketing",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economic University Hanoi",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economic University Major Economic Statistics",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "NATIONAL ECONOMICS UNIVERSITY",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University (2015 - 2019)",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University (2018 - 2022)",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Advanced Education Program",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Bachelor",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Bachelor Of Marketing Management",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Major Mathematical",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University Vietnam",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Economics University, Ha Noi",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "National Kaohsiung First University Of Sci Tech Taiwan",
		After: "Đại Học Khoa Học Và Công Nghệ Quốc Gia Cao Hùng",
	},
	{
		Before:
			"National Round The International Collegiate Programming Contest Known As The Icpc Is An",
		After: "",
	},
	{
		Before: "National Sun Yat Sen University",
		After: "Đại Học Quốc Gia Tôn Trung Sơn",
	},
	{
		Before: "National Taipei University Ntpu",
		After: "Đại Học Quốc gia Đài Bắc",
	},
	{
		Before:
			"National Taiwan University Of Science And Technology Department Of Electrical Engineering",
		After: "Đại Học Khoa Học Và Công Nghệ Quốc Gia Đài Loan",
	},
	{
		Before: "National University",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "National University of Art Education",
		After: "Đại Học Sư Phạm Nghệ Thuật Trung Ương",
	},
	{
		Before: "national university of civil engineering",
		After: "Đại Học Xây Dựng",
	},
	{
		Before:
			"Năm 2016 Tốt Nghiệp Loại Xuất Sắc Chuyên Ngành Kiểm Toán Khoa Kế Toán Của Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Nắm Rõ Những Quy Định Nhà Nước Về Quản Lý Các Tổ Chức Tín Dụng",
		After: "",
	},
	{
		Before:
			"Năm-2016-Tốt-Nghiệp-Cử-Nhân-Ngành-Quản-Trị-Tài-Chính-Khoa Quản Trị Kinh",
		After: "",
	},
	{
		Before: "neu",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Neu- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Neu- National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Ng Đại Học Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Năm 2020  Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Ngành Báo Chí Đại Học Văn Hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: "Ngành Công Nghệ Thông Tin- Đh Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Ngành Kế Toán-  Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Ngành Quản Trị Kinh Doanh- Đại Học Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "Ngành Tài Chính Ngân Hàng Chuyên Ngành Thuế",
		After: "",
	},
	{
		Before: "Ngành Truyền Thông Quốc Tế Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Ngân Hàng Quốc Tế VIB",
		After: "",
	},
	{
		Before: "Ngân Hàng Tài Chính Ngân Hàng",
		After: "",
	},
	{
		Before: "Ngân Hàng Thương Mại Cổ Phần Á Châu",
		After: "",
	},
	{
		Before: "Ngân hàng Thương mại hội nhập",
		After: "",
	},
	{
		Before: "Ngân hàng TMCP Công thương Việt Nam | 8/2022 - nay",
		After: "",
	},
	{
		Before: "Ngân Hàng Tmcp Quân Đội",
		After: "",
	},
	{
		Before: "Ngân Hàng Tmcp Xuất Nhập Khẩu Việt Nam Eximbank",
		After: "",
	},
	{
		Before: "Nghề",
		After: "",
	},
	{
		Before: "Ngành Học Kinh Tế Công Nghiệp- Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Nghề Luật Sư - Học Viện Tư Pháp",
		After: "Học Viện Tư Pháp",
	},
	{
		Before: "Nghiên Cứu Và Học Tập Tại Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Ngôn Ngữ Anh Đại Học Sài Gòn",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "Ngôn Ngữ Anh- Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Ngôn Ngữ Tự Nhiên Khoa Học Dữ Liệu",
		After: "",
	},
	{
		Before: "Nguyen Du Primary School",
		After: "",
	},
	{
		Before: "NGUYEN KHUYEN PRIVATE HIGH SCHOOl",
		After: "",
	},
	{
		Before: "Nguyen Tat Thanh University",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Nguyen Thuong Hien High School- Hcmc",
		After: "",
	},
	{
		Before: "Nguyen Trai University Major",
		After: "Đại Học Nguyễn Trãi",
	},
	{
		Before: "NGUYEN VAN QUYET (NGUYỄN VĂN QUYẾT)",
		After: "",
	},
	{
		Before: "Nguyentrunghieu1595Gmailcom",
		After: "",
	},
	{
		Before: "Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Nguyễn Tất Thành University Ho Chi Minh City Vietnam",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "Nguyên và Môi",
		After: "",
	},
	{
		Before: "Nguyên.",
		After: "",
	},
	{
		Before: "nhà hàng - cà phê",
		After: "",
	},
	{
		Before: "Nha Trang University",
		After: "Đại Học Nha Trang",
	},
	{
		Before: "Nhan Hoa, My Hao, Hung Yen",
		After: "",
	},
	{
		Before: "Nhat Quang Co., Ltd",
		After: "",
	},
	{
		Before: "Nhân Quản Trị Kinh Doanh Đại Học Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Nhân Viên Kinh Doanh Phát Triển Thị -Vne Group",
		After: "",
	},
	{
		Before: "Nhân Viên Kinh Doanh Tnhh Nihon Self Medical Việt Nam",
		After: "",
	},
	{
		Before: "Nhân Viên Nhân Sự Tuyển Dụng Tại Tập Đoàn Tân Á Đại Thành",
		After: "",
	},
	{
		Before: "Niagara University",
		After: "Đại Học Niagara",
	},
	{
		Before: "NON TANG TUYEN DUNG THUN SƯ HANG DAU MIET NAM",
		After: "",
	},
	{
		Before: "nong lam university",
		After: "",
	},
	{
		Before: "northumbria university",
		After: "Đại Học Northumbria",
	},
	{
		Before: "Northwest College Art",
		After: "",
	},
	{
		Before: "nottingham trent university",
		After: "Đại Học Nottingham Trent",
	},
	{
		Before: "Nottingham Trent University Nottingham Business School",
		After: "Đại Học Nottingham Trent",
	},
	{
		Before: "Nông Nghiệp Kinh Tế Và Tự Nhiên Của Đại Học Tây Úc",
		After: "",
	},
	{
		Before: "Nơi Cấp Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Nghệ Hà Nội",
		After: "",
	},
	{
		Before: "Nơi- Đào Tạo",
		After: "",
	},
	{
		Before: "Obox Group",
		After: "",
	},
	{
		Before: "on Vietnam Dairy Products JSC",
		After: "",
	},
	{
		Before: "Open University",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Open University Of Malaysia",
		After: "Đại Học Mở Malaysia",
	},
	{
		Before: "Open University School Of Advanced Study",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Organization Academy Of Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Orient Commercial Bank",
		After: "",
	},
	{
		Before: "Others- Pti Education And Training Group",
		After: "",
	},
	{
		Before: "Oulu University of Applied Sciences",
		After: "Đại Học Khoa Học Ứng Dụng Oulu",
	},
	{
		Before:
			"Paris-Nanterre Univ Ersit Y Paris I Bachelor O F App Lied Sc Ie Nc E",
		After: "Đại Học Paris Nanterre",
	},
	{
		Before: "Peak Dmc Vietnam",
		After: "",
	},
	{
		Before: "Pedagogical Of University Thai Nguyen",
		After: "Đại Học Sư Phạm - ĐH Thái Nguyên",
	},
	{
		Before: "People'S Security Academy",
		After: "Học Viện An Ninh Nhân Dân",
	},
	{
		Before: "Perform Small Adjustments On An Image With Tools Such Photoshop",
		After: "",
	},
	{
		Before: "Personal Project",
		After: "",
	},
	{
		Before: "Perth Australia",
		After: "",
	},
	{
		Before: "Peter The Great Stpetersburg Polytechnic University",
		After: "Đại Học Bách Khoa Saint Petersburg",
	},
	{
		Before: "Petrovietnam University",
		After: "Đại Học Dầu Khí Việt Nam",
	},
	{
		Before: "Phạm Hương Giang",
		After: "",
	},
	{
		Before: "Phạm Ngọc Thạch University Of Medicine",
		After: "Đại Học Y Khoa Phạm Ngọc Thạch",
	},
	{
		Before: "Phan Boi Chau High School For The Gifted, Nghe An",
		After: "",
	},
	{
		Before: "Phát Triển Website Thi Online Cho  Đại Học Ngoại Ngữ",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: "Phân Hiệu Đại Học Đà Nẵng",
		After: "Phân Hiệu Đại Học Đà Nẵng Tại Kon Tum - ĐH Đà Nẵng",
	},
	{
		Before: "Phân Hiệu Đại Học Thủy Lợi",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Phân Hiệu  Đại Học Thủy",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Phd Student, Electronics Engineering, University Of Siegen",
		After: "Đại Học Siegen",
	},
	{
		Before: "PhotoShop",
		After: "",
	},
	{
		Before: "Phuong Dong University",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Phuonganhphan0411Gmailcom",
		After: "",
	},
	{
		Before: "Phương Đông University",
		After: "Đại Học Phương Đông",
	},
	{
		Before: "Plusplus Academy",
		After: "",
	},
	{
		Before: "Position Bank Teller",
		After: "",
	},
	{
		Before: "Position International Sales Executive",
		After: "",
	},
	{
		Before: "Post And Telecommunication Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Post and Telecommunications Institute of",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Post And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Post And Telecomunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Post Graduate Certificate",
		After: "",
	},
	{
		Before: "Post Telecommunication Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "posts  telecoms institute of technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Posts And Telecommunication Instittute Oftechnology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Posts And Telecommunication Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Posts And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before:
			"Posts And Telecommunications Institute Of Technology - College Degree",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Posts And Telecommunications Institute Of Technology Hanoi",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Posts And Telecommunications Institute Of Technology, Ha Noi",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "POSTS AND TELECOMUNICATIONS INSTITUE OF TECHNOLOGY",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Pr-Communications-Van Lang University",
		After: "Đại Học Văn Lang",
	},
	{
		Before:
			"Practice Tax Declaration And Tax Finalization On The Htkk Software",
		After: "",
	},
	{
		Before: "Prepared by: LAM THU HUONG",
		After: "",
	},
	{
		Before: "Procuder, Canva, Photoshop",
		After: "",
	},
	{
		Before: "Profm Company",
		After: "",
	},
	{
		Before:
			"Progress Of Business Administration Saint Marys College Of California Moraga",
		After: "",
	},
	{
		Before: "Project Https-Telegramorg Apps Linux C Project Git C Project",
		After: "",
	},
	{
		Before: "Project Management , Coventry University London",
		After: "",
	},
	{
		Before: "Psb College Vietnam",
		After: "",
	},
	{
		Before: "PTIT",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "PTIT HCM",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Ptit Post And Telecommunication Institute Of",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Python Data Structures- University Michigan",
		After: "",
	},
	{
		Before: "Python For Everybody- University Michigan",
		After: "",
	},
	{
		Before: "Quality Resources And Solution",
		After: "",
	},
	{
		Before: "Quality Resources And Solutions",
		After: "",
	},
	{
		Before: "Quản Trị Các Group Của Gia Đình",
		After: "Đại Học Gia Định",
	},
	{
		Before: "Quản Trị Doanh Nghiệp Đại Học Mở Tp Hồ Chí Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "Quản Trị Khách Sạn Việt Úc",
		After: "",
	},
	{
		Before: "Quản trị kinh doanh",
		After: "",
	},
	{
		Before: "Quản Trị Kinh Doanh  Cao đẳng Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: "Quản Trị Kinh Doanh- Đại Học Kinh Tế Tp Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Quản Trị Kinh Doanh-|-9 2016- 05 2021 Đại Học Ngân Hàng Tphcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before:
			"Quản Trị Nguồn Nhân Lực-|-8 2019- Hiện Tại Đại Học Kinh Tế Đại Học Đà Nẵng",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "Quản Trị Nhân Lực- Đại Học Lao",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Nơi Đào Tạo  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Quang Nam University Major English",
		After: "Đại Học Quảng Nam",
	},
	{
		Before: "Queensland University Technology",
		After: "Đại Học Queensland",
	},
	{
		Before: "Quản Trị Nhân Lực, Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Quy Nhon University",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "Quỹ tiền mặt lập báo cáo quỹ gửi giám đốc",
		After: "",
	},
	{
		Before:
			"Rangsit University Exchange Program Information System Project Management",
		After: "",
	},
	{
		Before: "Red Star University",
		After: "Đại Học Sao Đỏ",
	},
	{
		Before: "Representative Of Foreign Trade University Hcmc Campus",
		After: "Đại Học Ngoại Thương Cơ Sở 2, TPHCM",
	},
	{
		Before: "Researcher Vnuk Data Science , University Of Danang",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "Researcher- Korea University",
		After: "Đại Học Hàn Quốc",
	},
	{
		Before: "Rio Agency",
		After: "",
	},
	{
		Before: "Ritsumeikan Asia Pacific University,",
		After: "Đại Học Châu Á Thái Bình Dương Ritsumeikan",
	},
	{
		Before: "Ritsumeikan University",
		After: "Đại Học Châu Á Thái Bình Dương Ritsumeikan",
	},
	{
		Before: "Rmit International University",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit International University , Ha Noi , Vn  Chu Van An High",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit University",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit University Oct",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit University Vietnam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit University, Hanoi",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit Vietnam University",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rmit-University Hanoi",
		After: "Đại Học RMIT",
	},
	{
		Before: "Rotterdam School Of Management Erasmus University",
		After: "Đại Học Erasmus",
	},
	{
		Before: "Russian State University Humanities",
		After: "Đại Học Nhân Văn Quốc Gia Nga",
	},
	{
		Before: "SAGE ACADEMY",
		After: "",
	},
	{
		Before: "Sage- Học Viện Quản Trị Kinh Doanh Marketing",
		After: "",
	},
	{
		Before: "Sai Gon ACT College",
		After: "",
	},
	{
		Before: "Sai Gon Technology Univesity",
		After: "Đại Học Công Nghệ Sài Gòn",
	},
	{
		Before: "Sai Gon University",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "Saigon Institute Of Technology, Vietnam",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: "Saigon University",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: "Saigontech",
		After: "",
	},
	{
		Before: "Saimaa University Of Applied Sciences Finland",
		After: "Đại Học Khoa Học Ứng Dụng Saimaa",
	},
	{
		Before: "San Antonio",
		After: "",
	},
	{
		Before: "Sapp Academy",
		After: "",
	},
	{
		Before: "Satakunta University Of Applied Sciences",
		After: "Đại Học Khoa Học Ứng Dụng Satakunta",
	},
	{
		Before: "Savitribai Phule Pune University",
		After: "",
	},
	{
		Before: "SCHMALKALDEN UNIVERSITY OF APPLIED SCIENCES (HS SCHMALKALDEN)",
		After: "Đại Học Khoa Học Ứng dụng FH Schmalkalden",
	},
	{
		Before: "School",
		After: "",
	},
	{
		Before: "School   Training School Thuong Mai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "School Name College Of Foreign Economic Relation",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "School National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "SCHOOL OF FPT UNIVERSITY",
		After: "Đại Học FPT",
	},
	{
		Before: "School Of Law Vietnam National University",
		After: "Đại Học Luật - Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "School Of Law- Hanoi National University",
		After: "Đại Học Luật - Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "School Of Law- Vietnam National University Hanoi",
		After: "Đại Học Luật - Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "School- Training School",
		After: "",
	},
	{
		Before: "School: Hanoi University of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "School: Posts And Telecommunications Institute Of Technology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Sciences and Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Screen Writing Workshop",
		After: "",
	},
	{
		Before: "SEASONAL STORE STAFF",
		After: "",
	},
	{
		Before: "Seattle University Seattle Wa Usa",
		After: "Đại Học Thành Phố Seattle",
	},
	{
		Before: "Seinajoki University Of Applied Sciences",
		After: "Đại Học Khoa Học Ứng Dụng Seinäjoki - SeAMK",
	},
	{
		Before: "Self taught Brands Vietnam",
		After: "",
	},
	{
		Before: "Sep 2006 Jun 2006 Phuong Dong University",
		After: "Đại Học Phương Đông",
	},
	{
		Before:
			"Sep 2006--Jan 2009-Royal Melbourne Institution Of Technology Vietnam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Sep 2012--July 2017 Banking Academy",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "sep 2017  current foreign trade university",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Sep 2020 to Dec 2020  Hanoi Vietnam",
		After: "",
	},
	{
		Before: "September 2016- August 2020 Academy Finance",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "SEPTRICH CART IN.CODSOPT",
		After: "",
	},
	{
		Before: "Setember- 2015- May- 2020 Hanoi University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Shanghai Jiao Tong University",
		After: "Đại Học Giao thông Thượng Hải",
	},
	{
		Before: "Shoesstore Website",
		After: "",
	},
	{
		Before: "Shop Giày Dép",
		After: "",
	},
	{
		Before: "Shop quần áo",
		After: "",
	},
	{
		Before: "Shopping Tv.",
		After: "",
	},
	{
		Before: "Shou University",
		After: "Đại Học Nghĩa Thủ",
	},
	{
		Before: "Siêu Thị Thành Đô",
		After: "",
	},
	{
		Before: "Simbatech",
		After: "",
	},
	{
		Before: "Singapore Management University",
		After: "Đại Học Quản Lý Singapore",
	},
	{
		Before: "Singapore University College Dublin",
		After: "Đại Học Cao Đẳng Dublin",
	},
	{
		Before: "Sinh Viên Đại Học Ngân Hàng Tp Hcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: "Sinh Viên Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "quý cho công ty mẹ trụ sở ở hà nội và các chi nhánh phụ thuộc",
		After: "",
	},
	{
		Before: "Sinh Viên Năm 04  Đại Học Luật Hà",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Sinh Viên Khoa CNTT Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Sinh Viên Năm 3 Chuyên Ngành Quản Trị Kinh Doanh  Đh",
		After: "",
	},
	{
		Before: "Sinh Viên Năm 3 Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Sinh Viên Năm 4  Đại Học Công Nghệ Giao Thông Vận Tải |",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Sinh Viên Năm 4  Đh Công Nghệ Giao Thông Vận Tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Sinh Viên Năm 4-  Đại Học Thủy Lợi , Chuyên Ngành Hệ Thống",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Sinh Viên Năm Cuối Học Viện Công Nghệ Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before:
			"Sinh Viên Năm Cuối Khoa Tài Chính Doanh Nghiệp  Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Sinh Viên Năm Cuối  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Sinh Viên Tài Chính- Ngân Hàng Gpa",
		After: "",
	},
	{
		Before: "Sinh Viên Tại-Arena Multimedia",
		After: "",
	},
	{
		Before: "Sinh Viên  Đại Học Vinh Từ Năm",
		After: "Đại Học Vinh",
	},
	{
		Before: "Slippery Rock University Pennsylvania Slippery Rock Pa Usa",
		After: "Đại Học Slippery Rock",
	},
	{
		Before: "Social Activities Of Ftu Guitar Club",
		After: "",
	},
	{
		Before: "Social Sciences",
		After: "",
	},
	{
		Before: "Softbank Group",
		After: "",
	},
	{
		Before: "Softech Aptech Academy",
		After: "",
	},
	{
		Before: "Software Testing Cerificate  FPT Software",
		After: "",
	},
	{
		Before: "Software Testing Training, Tester Hanoi Center",
		After: "",
	},
	{
		Before: "SOICT - HUST",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "solvay brussels",
		After: "",
	},
	{
		Before: "Southern Cross University Mdis Singapore",
		After: "Đại Học Nam Cross",
	},
	{
		Before: "southern institute of technology in new zealand",
		After: "Viện Công Nghệ Miền Nam",
	},
	{
		Before:
			"Southern Taiwan University Of Science And Technology Tainan Taiwan",
		After: "Đại Học Khoa Học Và Công Nghệ Nam Đài Loan",
	},
	{
		Before: "Southern University Bangladesh",
		After: "Đại Học Nam Bangladesh",
	},
	{
		Before: "Sinh Viên Năm 04  Đại Học Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Specialized: Software Technology",
		After: "",
	},
	{
		Before: "Staffordshire University Uk",
		After: "Đại Học Staffordshire",
	},
	{
		Before: "Standard It Ba Course, Business Analysis Academy",
		After: "",
	},
	{
		Before: "Stqb Foundation Certification Toeic",
		After: "",
	},
	{
		Before: "Student Of University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Su Pham Ky Thuat University",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Suffolk University Master Of Science",
		After: "Đại Học Suffolk",
	},
	{
		Before: "Summer University Bayreuth",
		After: "Đại Học Bayreuth",
	},
	{
		Before:
			"Sử Dụng Các Công Cụ Sql Server Jira Jmeter-Hoạt Động Thử Nghiệm Trên Website",
		After: "",
	},
	{
		Before: "Sử Dụng Cơ Bản Photoshop",
		After: "",
	},
	{
		Before: "sư phạm kỹ thuật",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Sư Phạm Kỹ Thuật Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "Số 315  Chinh Thanh Xuân Hà Nội",
		After: "",
	},
	{
		Before: "T Ốt Nghiệp 8 2016 Đ Ại Học- Học Viện T",
		After: "",
	},
	{
		Before:
			"T06 2020- T09 2020-Đại Học Kinh Tế Quốc Dân Chứng Chỉ Bồi Dưỡng Kế Toán Trưởng",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "t3h",
		After: "",
	},
	{
		Before: "T3H Information Technology Center Major Multimedia",
		After: "",
	},
	{
		Before: "Sv Năm 2 Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "T9 2009 - T7 2014 Cử Nhân Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "tài chính ngân hàng HN",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Tài Chính Ngân Hàng-Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "Tài chính- Ngân hàng",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Tài Chính- Ngân Hàng Hướng Chuyên Sâu Thuế",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "tài chính ngân hàng hà nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Tại Đại Học Kinh Doanh Và Công Nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Tại Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"Tại Một Công Ty Luật Ở Đây Tôi Học Hỏi Và Rèn Luyện Thêm Nhiều Kỹ Năng",
		After: "",
	},
	{
		Before: "Tài Nguyên và môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Tại Đại Học Kinh Doanh Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "Tại  Đại Học Kinh Tế Và Quản Trị Kinh Doanh Đại Học Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Tại  Đại Học Sư phạm Kỹ thuật Hưng yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: "tại  ĐH Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Tan Chong Group",
		After: "",
	},
	{
		Before: "Tài Nguyên Và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Taras Shevchenko National University Kyiv",
		After: "Đại Học Quốc Gia Kiev",
	},
	{
		Before: "Taxation-- Washington-University School Of Law",
		After: "Trường Luật Đại Học Washington",
	},
	{
		Before: "Tặng Quần Áo Và Quà Cho Trẻ Em Vùng Cao Hà Giang",
		After: "",
	},
	{
		Before: "Tập đoàn CEO Việt Nam",
		After: "",
	},
	{
		Before: "Tập Đoàn FPT",
		After: "",
	},
	{
		Before: "Tập Đoàn Hà Đô",
		After: "",
	},
	{
		Before: "TẬP ĐOÀN PANASONIC VIỆT NAM",
		After: "",
	},
	{
		Before: "Tập Đoàn Vingroup Vinfast Vinsmart Grandprix",
		After: "",
	},
	{
		Before: "TC Kinh tế kỹ thuật Công Đoàn Tiền Giang",
		After: "",
	},
	{
		Before: "Teaching Assistant For English Center",
		After: "",
	},
	{
		Before: "Techcombank",
		After: "",
	},
	{
		Before: "Techcombank Make New Website For Techcombank",
		After: "",
	},
	{
		Before: "Techmaster Vietnam",
		After: "",
	},
	{
		Before: "TECHNOLOGY",
		After: "",
	},
	{
		Before: "Telecommunication Instittute Oftechnology",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Telecommunications",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Temple University",
		After: "",
	},
	{
		Before: "Tester And Software Testing Tại Itplus Academy",
		After: "",
	},
	{
		Before: "Tester Ha Noi Center",
		After: "",
	},
	{
		Before: "Tạo Kiểm Thử Phần Mềm Hà Nội",
		After: "",
	},
	{
		Before: "Tester Hanoi Center",
		After: "",
	},
	{
		Before: "Tester Hanoi Center Academy Of Finance",
		After: "",
	},
	{
		Before: "Testerhanoi Center",
		After: "",
	},
	{
		Before: "Testerprovn Center",
		After: "",
	},
	{
		Before: "TesterTop Training Center",
		After: "",
	},
	{
		Before: "Tế Đại Học Thái Nguyên Nhiệm Kỳ",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Tế- Đại Học Kinh Tế Quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Tester Hà Nội",
		After: "",
	},
	{
		Before: "Thạc Sĩ Chuyên Ngành Kế Toán  Đại Học Tôn Đức Thắng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Thạc Sĩ Luật Học- Khoa Luật Đại",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Thạc Sĩ National Cheng Kung University",
		After: "Đại Học Quốc Gia Thành Công",
	},
	{
		Before: "Thạc Sĩ National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Thạc Sĩ Pune University",
		After: "Đại Học Savitribai Phule Pune",
	},
	{
		Before: "Thạc Sĩ Quản Trị Kinh Doanh Quốc Tế | Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Thạc Sĩ Quy Nhon University",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: "Thạc Sĩ- Đại Học Andrews Hoa Kỳ",
		After: "Đại Học Andrews",
	},
	{
		Before: "Tên  Cao đẳng Kinh Tế Công Nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: "Thạc Sĩ- Đại Học Kinh Tế Đại Học Quốc Gia",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Thạc Sĩ- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Thạc Sĩ- Đại Học Quốc Gia",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Thạc Sĩ- Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Thạc Sĩ- Đại Học Tài Chính Trực Thuộc Chính Phủ Liên",
		After: "Đại Học Tài Chính Trực Thuộc Chính Phủ Liên Bang Nga",
	},
	{
		Before: "Thạc Sĩ- Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Thạc Sĩ- Học Viện Tài Chính Chuyên Ngành Tài Chính Ngân Hàng",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Thạc Sĩ- Rmit University Vietnam",
		After: "Đại Học RMIT",
	},
	{
		Before: "Thạc Sĩ- University College Dublin",
		After: "Đại Học Dublin, Ireland",
	},
	{
		Before: "Thạc Sỹ 2018-2021  Higher School Of Economics",
		After: "",
	},
	{
		Before: "Thạc Sỹ Kế Toán-Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Thạc Sỹ Quản Trị Nhân Lực-Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Thạc Sỹ- Đại Học Việt Nhật",
		After: "Đại Học Việt - Nhật - ĐH QGHN",
	},
	{
		Before: "Thai Nguyen University",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Thai Nguyen University Economics",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Thai Nguyen University of Economics & Business Administration",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Thai Nguyen University Of Economics And Business Administration",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Thai Nguyen University Of Technology",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Thai Nguyen University University Of Science",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: "Tham Gia Clb Aaf Một Clb Về Kinh Tế Và Quản Lý Của ",
	},
	{
		Before:
			"Tham Gia Khóa Đào Tạo Chuyên Sâu Tại Công Ty Cổ Phần Thương Mại Và Đầu Tư Giáo Dục Acvina",
		After: "",
	},
	{
		Before: "Tham Gia Khoá Học Ngắn Hạn Tại Cục Sở Hữu Trí Tuệ",
		After: "",
	},
	{
		Before: "Tham Gia Nghiên Cứu Cấp Học Viện Đề Tài Các Nhân Tố Ảnh Hưởng Đến",
		After: "",
	},
	{
		Before: "Tham Gia Xây Dựng Đường Cho Bà Con Ở Quảng Ngãi",
		After: "",
	},
	{
		Before: "Thammasat University",
		After: "Đại Học Thammasat",
	},
	{
		Before:
			"Tháng 06 2011 Cử Nhân Chuyên Ngành Kế Toán Tài Chính Tại  Đại Học Nông Lâm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "tháng 08 2016   tháng 01 2021  electric power university",
		After: "Đại Học Điện Lực",
	},
	{
		Before:
			"Tháng 10 2015 Nhận Bằng Cử Nhân Kinh Tế Chuyên Ngành Kế Toán  Đại Học Lao Động",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Tháng 3 2021- Tháng 9 2021 Công Ty Bảo Hiểm Bưu Điện",
		After: "",
	},
	{
		Before: "Tháng 9 2018 Đến Nay Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Thang Long University",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Thang Long University Graduate",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Thang Long University Hanoi",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Thang Long University Major English Language",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Thanglong University",
		After: "Đại Học Thăng Long",
	},
	{
		Before: "Thanh Hóa",
		After: "",
	},
	{
		Before: "Thạc Sĩ- Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Thành Viên Ban Marketing Mc",
		After: "",
	},
	{
		Before: "Thành Viên Câu Lạc Bộ Hướng Dẫn Viên Sài Gòn",
		After: "",
	},
	{
		Before: "Thành Viên Của Hội Sinh Viên Yại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "Thành Viên-Đội Svtn C Ủa Khoa Qtkd",
		After: "",
	},
	{
		Before: "that I have a passion in the field of information technology",
		After: "",
	},
	{
		Before: "Thăng Long Kcn Hưng Yên",
		After: "",
	},
	{
		Before: "Thăng Long University, English Department",
		After: "Đại Học Thăng Long",
	},
	{
		Before:
			"The 7Th Vietnam Student Union Congress Of The Academy Of Finance For The",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "The Academy Of",
		After: "",
	},
	{
		Before:
			"The Academy Of Cryptography Techniques Engineer Information Security",
		After: "",
	},
	{
		Before: "The Association Of Chartered Certified Accountants",
		After: "",
	},
	{
		Before: "The College NIIT Quang Trung - HCMC",
		After: "",
	},
	{
		Before: "The College Of Foreign Economic Relation",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "The Digital Era-Vnws Exclusive Employer Workshop Hanoi",
		After: "",
	},
	{
		Before: "The Finance Marketing University",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "THE FUADAMEATALS OF DIAITAL MARKETING",
		After: "",
	},
	{
		Before: "The Ielts Workshop",
		After: "",
	},
	{
		Before: "The International Pacific College Palmerston",
		After: "",
	},
	{
		Before: "The national economics university",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "The Project",
		After: "",
	},
	{
		Before: "The Sai Gon International University Major Foreign Trade",
		After: "Đại Học Quốc Tế Sài Gòn",
	},
	{
		Before: "The University Economics",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "The University Of Danang University Of Economics",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "The University Of Danang University Of Technology And Education",
		After: "Đại Học Sư Phạm Kỹ Thuật Đà Nẵng",
	},
	{
		Before: "the university of economics ho chi minh city",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "THE UNIVERSITY OF FINANCE - MARKETING",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "The University Of Finance And Accountancy",
		After: "Đại Học Tài Chính Kế Toán",
	},
	{
		Before: "The University Of Melbourne Australia",
		After: "Đại Học Melbourne",
	},
	{
		Before: "The University Of North Carolina At Chapel Hill",
		After: "Đại Học North Carolina",
	},
	{
		Before: "The University Of Sunderland",
		After: "Đại Học Sunderland",
	},
	{
		Before: "The University West Of England",
		After: "Đại Học England",
	},
	{
		Before: "The-Association Of Chartered Certified Accountants",
		After: "",
	},
	{
		Before:
			"This Project Our Team Is Responsible To Build Up A Website And Shipment Planning Module For This Company",
		After: "",
	},
	{
		Before: "Thông Đại Học Bách Khoa Hà Nôi",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Thời Gian- Tên -Trung Tâm Ngành",
		After: "",
	},
	{
		Before: "THPT",
		After: "",
	},
	{
		Before: "Thpt Ân Thi",
		After: "",
	},
	{
		Before: "THPT CHUYÊN HÀ TĨNH",
		After: "",
	},
	{
		Before: "Thpt Chuyên Hưng Yên",
		After: "",
	},
	{
		Before: "THPT CHUYÊN HƯNG YÊN Chuyên ngành TOÁN",
		After: "",
	},
	{
		Before: "Thpt Chuyên Vị Thanh",
		After: "",
	},
	{
		Before: "Thpt Chuyên Vĩnh Phúc",
		After: "",
	},
	{
		Before: "THPT Đoàn Kết Hai Bà",
		After: "",
	},
	{
		Before: "Thpt Eahleo",
		After: "",
	},
	{
		Before: "Thpt Lê Hồng Phong",
		After: "",
	},
	{
		Before: "Thpt Lê Thánh Tôn",
		After: "",
	},
	{
		Before: "thpt ngô quyền",
		After: "",
	},
	{
		Before: "THPT Nguyễn Tất Thành",
		After: "",
	},
	{
		Before: "THPT Phan Huy Chú Đống Đa",
		After: "",
	},
	{
		Before: "Thpt Phú Tân",
		After: "",
	},
	{
		Before: "Thpt Tam Phú",
		After: "",
	},
	{
		Before: "THPT Thái Phiên",
		After: "",
	},
	{
		Before: "Thpt Thọ Xuân",
		After: "",
	},
	{
		Before: "Thpt Thủ Khoa Huân",
		After: "",
	},
	{
		Before: "Thpt Thuận Hưng Tốt Nghiệp Thpt",
		After: "",
	},
	{
		Before: "Thpt Tiên Lữ",
		After: "",
	},
	{
		Before: "Thpt Tô Hiệu Sơn La",
		After: "",
	},
	{
		Before: "THPT Trần KHAI NGUYÊN",
		After: "",
	},
	{
		Before: "Thpt Võ Minh Đức",
		After: "",
	},
	{
		Before: "THPT Xuân Đỉnh",
		After: "",
	},
	{
		Before: "Thu Dau Mot University",
		After: "Đại Học Thủ Dầu Một",
	},
	{
		Before: "Thu Duc College Of Technology",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Thu Duc College Of Technology Faculty Of Information Technology",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Thu Duc Technical and Professional",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Thu Duc Technology College, Major : Information Technology",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Thủ Khoa Đầu Ra Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Thucduc College Technology",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "thuong mai university",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Thuong Mai University Tmu",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Thuongmai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Thuy Loi University",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Thuy Loi University, Major: Information Technology",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Thuyloi University",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Thực Hiện Code Các Website App Seo Từ Khóa Website",
		After: "",
	},
	{
		Before: "Thực Nghiệm High School",
		After: "",
	},
	{
		Before: "Thực Phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "Thương mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Thương Mại Điện Tử, Đại Học Kinh Tế Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: "TIẾNG ANH THƯƠNG MẠI",
		After: "",
	},
	{
		Before: "Tỉnh Quảng Trị",
		After: "",
	},
	{
		Before: "Tms Group Tms Education",
		After: "",
	},
	{
		Before: "Tmt Solutions",
		After: "",
	},
	{
		Before: "TNHH SPLASH INTERACTIVE",
		After: "",
	},
	{
		Before: "Tnhh Tư Vấn Giải Pháp Kế Toán Việt Nam",
		After: "",
	},
	{
		Before: "Tnhh Zoomlion Việt Nam",
		After: "",
	},
	{
		Before: "Thành Phố: Hà Nội",
		After: "",
	},
	{
		Before:
			"Tòa nhà Công Đoàn Ngân hàng Việt Nam, Số 6, ngõ 82, Dịch Vọng Hậu, Cầu Giấy, Hà Nội",
		After: "",
	},
	{
		Before: "Toà nhà Technosoft ngõ 15 Duy Tân, Cầu Giấy, Hà Nội",
		After: "",
	},
	{
		Before: "Tokyo International University",
		After: "Đại Học Quốc Tế Tokyo",
	},
	{
		Before: "Tomorrow Marketer Academy",
		After: "",
	},
	{
		Before: "TOMORROW MARKETERS CENTRE",
		After: "",
	},
	{
		Before: "Tomsk Polytechnic University Russia",
		After: "Đại Học Bách Khoa Nghiên Cứu Quốc Gia Tomsk, Nga",
	},
	{
		Before: "Ton Duc Thang University",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Ton Duc Thang University Vilas",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Ton Duc Thang-University",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Ton DucThang University",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Tool Log Bug Jira Gitlab",
		After: "",
	},
	{
		Before: "tOpCM",
		After: "",
	},
	{
		Before: "Topcv University Major",
		After: "",
	},
	{
		Before: "Toulon University",
		After: "Đại Học Toulon",
	},
	{
		Before: "Toán Ứng Dụng Và Tin Học  Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Tổ--Chức--Toạ--Đàm--Báo--Chí--Hội Nhà Báo Việt Nam",
		After: "",
	},
	{
		Before:
			"Tô quantân đến việc nghiện cáu và công nghê nội Tho pothiho hoi lài thi thi chnghi hhi hhi hà nhi hà nội",
		After: "",
	},
	{
		Before: "Tôi Tốt Nghiệp Cao đẳng Nghề Bằng Trung Bình Khá",
		After: "",
	},
	{
		Before: "Tôn Đức Thắng University",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: "Tổng Công Ty Ceo Group Như Đại Hội Cổ Đông Mở Bán",
		After: "",
	},
	{
		Before:
			"Tôi Theo Học Chuyên Ngành Đạo Diễn Truyền Hình- Đại Học Sân Khấu Điện Ảnh Hà Nội",
		After: "Đại Học Sân Khấu - Điện Ảnh Hà Nội",
	},
	{
		Before: "Tốt Nghiệp 7 2015 Đại Học Đại Học Hồng Đức",
		After: "Đại Học Hồng Đức",
	},
	{
		Before: "Tốt Nghiệp Cao đẳng Kinh Tế Kỹ Thuật Thương Mại",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Thương Mại",
	},
	{
		Before: "Tốt Nghiệp Cao đẳng Qtkd  Đại Học Kinh Tế Tài Chính",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Tốt Nghiệp Chuyên Ngành Báo Chí- Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Tốt Nghiệp Chuyên Ngành Kế Toán Tài Chính-Tại  Đại Học Hùng",
		After: "Đại Học Hùng Vương",
	},
	{
		Before:
			"Tốt Nghiệp Chuyên Ngành Kế Toán- Đại Học Kinh Tế Kỹ Thuật Và Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Tốt Nghiệp Cử Nhân Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Tổng Hợp  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Cử Nhân Tiếng Anh-  Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Cử Nhân  Đại Học Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Cử Nhân Triết Học Tại Đại Học Tổng Hợp Hà Nội",
		After: "Đại Học Tổng Hợp Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Đại Học Chuyên Ngành Quan Hệ Lao Động",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Đại Học Đại Nam",
		After: "Đại Học Đại Nam",
	},
	{
		Before: "Tốt Nghiệp Đại Học FPT Hệ Chính Quy",
		After: "Đại Học FPT",
	},
	{
		Before: "Tốt Nghiệp Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Tốt Nghiệp Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Tốt Nghiệp Đại Học Kinh Tế Quốc Dân Chuyên Ngành Quản Trị Marketing",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Tốt Nghiệp Đại Học Kinh Tế Quốc Dân Kinh Tế Đầu Tư",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Tốt Nghiệp Đại Học Kinh Tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before:
			"Tốt Nghiệp Đại Học Kinh Tế Và Quản Trị Kinh Doanh Chuyên Ngành Quản",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: "Tốt Nghiệp Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Tốt Nghiệp Đại Học Mỏ Địa Chất Hà Nội",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Tốt Nghiệp Đại Học Sư Phạm Thái Nguyên",
		After: "Đại Học Sư Phạm - ĐH Thái Nguyên",
	},
	{
		Before: "Tốt Nghiệp Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Tốt Nghiệp Hệ Cao đẳng  Đại Học Lao Đông Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "Tốt Nghiệp Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Tốt Nghiệp Học Viện Chính Sách Và Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: "Tốt Nghiệp Học Viện Công Nghệ Bưu Chính Viễn",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Tốt Nghiệp Học Viện Ngân Hàng Ngành Ngôn Ngữ Anh",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: "Tốt Nghiệp Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before:
			"Tốt Nghiệp Khóa Học-Thực Hành Kế Toán Tổng Hợp Thực Tế Tại Trung Tâm Kế Toán Thiên Ưng",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Khoa Kinh Tế",
		After: "",
	},
	{
		Before:
			"Tốt Nghiệp Khoa Xuất Bản Kỹ Năng Viết Báo Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Tốt Nghiệp Khối Xã Hội Loại Khá Điểm Trung Bình",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Loại Giỏi Đại Học Khoa Học Xã Hội Nhân",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Tốt Nghiệp Loại Khá Khoa Tài Chính Ngân Hàng Chuyên Ngành",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Loại Khá Ngành Kế Toán-  Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Tốt Nghiệp Loại Khá  Cao đẳng Công Thương",
		After: "Cao Đẳng Công Thương Việt Nam",
	},
	{
		Before: "Tốt Nghiệp Loại Khá  Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Tốt Nghiệp Đại Học Mỹ Thuật Công Nghiệp Hà Nội",
		After: "Đại Học Mỹ Thuật Công Nghiệp",
	},
	{
		Before: "Tốt Nghiệp Thpt Chương Mỹ A",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Trung Học Phổ Thông Thanh Oai B Loại Giỏi",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Ngành Luật Đại Học Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Cao đẳng Phát Thanh Và Truyền",
		After: "Cao Đẳng Phát Thanh - Truyền Hình II",
	},
	{
		Before: "Tốt Nghiệp  Cao đẳng Du Lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Đại Học FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Tốt Nghiệp  Đại Học FPT Đà Nẵng",
		After: "Đại Học FPT",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Ngành Tài Chính Ngân Hàng",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Nông Lâm Tphcmquận Thủ Đứctphcm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Khoa Học Tự Nhiên Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Tài Nguyên Và Môi  Tp Hcm",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Xây Dựng",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "Tốt Nghiệp  Đh Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "Tốt Nghiệp  Đại Học Tài Nguyên Và Môi  Hà Nội Khóa",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "Tốt Nghiệp  Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: "Tốt Nghiệp  Trung Cấp Bách Khoa Chuyên Ngành Kế",
		After: "Trung Cấp Bách Khoa TPHCM",
	},
	{
		Before: "Tốt Nghiệp  Đh Ngoại Ngữ Hà Nội Tốt Nghiệp  Đh Thương Mại Hà Nội",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Tốt Nghiệp- Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Tp Hồ Chí Minh",
		After: "",
	},
	{
		Before: "Trade Union University",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Trade Union University Accounting",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Trade University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Trade University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Training Center",
		After: "",
	},
	{
		Before: "Training On Auditing- State Audit Of Vietnam",
		After: "",
	},
	{
		Before: "Training system University",
		After: "",
	},
	{
		Before: "Tran Hung Dao Highschool",
		After: "",
	},
	{
		Before: "TRAN LE HA ANH MBA Graduate",
		After: "",
	},
	{
		Before: "Tran Thi Lien Huong",
		After: "",
	},
	{
		Before: "Transachdongk48Gmailcom",
		After: "",
	},
	{
		Before: "Transportation Ho Chi Minh City Campus Vietnam",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: "Trình Độ Cao đẳng Chính Quy",
		After: "",
	},
	{
		Before: "Trình Học Nước Ngoài Của Bộ Gdđt",
		After: "",
	},
	{
		Before: "Trình Website",
		After: "",
	},
	{
		Before: "Trinhminhquang250988Gmailcom",
		After: "",
	},
	{
		Before: "Trong Môi  Đào Tạo Tại Học Viện Công Nghệ Bưu Chính Viễn",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before:
			"Trong Quá Trình Công Tác Tại Ngân Hàng Tmcp Tiên Phong Tôi Đã Có Cơ",
		After: "",
	},
	{
		Before: "Troy University",
		After: "Đại Học Troy, Alabama",
	},
	{
		Before: "Troy University- Hanoi University Science",
		After: "Đại Học Troy, Alabama",
	},
	{
		Before: "TRUE SKILL CENTER",
		After: "",
	},
	{
		Before: "Trung cấp",
		After: "",
	},
	{
		Before: "Trung Cấp Bách Khoa Sài Gòn",
		After: "Trung Cấp Bách Khoa Sài Gòn",
	},
	{
		Before: "Trung Cấp Chuyên Ngành Dược Sỹ",
		After: "",
	},
	{
		Before: "Trung Cấp CNTT",
		After: "",
	},
	{
		Before: "Tốt Nghiệp Viện Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "trung cấp công nghệ Ý Việt",
		After: "Trung Cấp Chuyên Nghiệp Ý Việt",
	},
	{
		Before: "trung cấp dược",
		After: "Trung Cấp Dược Hà Nội",
	},
	{
		Before: "Trung Cấp Dược Sĩ",
		After: "Trung Cấp Dược Hà Nội",
	},
	{
		Before: "Trung cấp Đắk Lắk",
		After: "Trung Cấp Đắk Lắk",
	},
	{
		Before: "TRUNG CẤP Học VIỆN HÀNG KHÔNG VIỆT NAM",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "TRUNG CẤP KẾ TOÁN",
		After: "",
	},
	{
		Before: "Trung Cấp Kinh Tế",
		After: "Trung Cấp Kinh Tế Hà Nội",
	},
	{
		Before: "Trung cấp Kinh tế - Kỹ thuật",
		After: "Trung Cấp Kinh Tế - Kỹ Thuật",
	},
	{
		Before: "Trung Cấp Kt Kt Tây Nam Á",
		After: "Trung Cấp Tây Nam Á",
	},
	{
		Before: "trung cấp nghề bạc liêu",
		After: "",
	},
	{
		Before: "Trung Cấp Nghề Nhân Đạo",
		After: "",
	},
	{
		Before: "Trung cấp nghề thủ đức",
		After: "",
	},
	{
		Before: "Trung Cấp Rio Class",
		After: "",
	},
	{
		Before: "Trung cấp Sài Gòn",
		After: "Trung Cấp Sài Gòn",
	},
	{
		Before: "Trung cấp Sài Gòn Tourist",
		After: "Trung Cấp Du Lịch Và Khách Sạn Saigontourist",
	},
	{
		Before: "Trung Cấp Trung Tâm Đâò Tạo Bồi Dưỡng Cán Bộ",
		After: "",
	},
	{
		Before: "Trung Cấp Việt Giao",
		After: "Trung Cấp Việt Giao",
	},
	{
		Before: "Trung Cấp Y Học Lê Hữu Trác",
		After: "Trung Cấp Y Dược Lê Hữu Trác",
	},
	{
		Before: "Trung Cấp Y Tuyên Quang",
		After: "Trung Cấp Y Tuyên Quang",
	},
	{
		Before: "Trung Cấp- Cao đẳng Công Nghệ Thủ Đức",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: "Trung Học Phổ Thông An Lương Đông",
		After: "",
	},
	{
		Before: "Trung Học Phổ Thông Chuyên Tuyên Quang",
		After: "",
	},
	{
		Before: "Trung Học phổ thông Kinh Môn",
		After: "",
	},
	{
		Before: "Trung Học Phổ Thông Lê Hoàn",
		After: "",
	},
	{
		Before: "trung Học phổ thông phan chu trinh",
		After: "",
	},
	{
		Before: "Trung Học Phổ Thông Số",
		After: "",
	},
	{
		Before: "Trung Học Phổ thông Tiếng Trung Tiếng Anh",
		After: "",
	},
	{
		Before: "Trung Tâm",
		After: "",
	},
	{
		Before: "Trung Tâm Anh Ngữ Sas Khóa Thứ 3. - Tự",
		After: "",
	},
	{
		Before: "Trung Tâm Bac",
		After: "",
	},
	{
		Before: "Trung Tâm Codegym",
		After: "",
	},
	{
		Before: "Trung Tâm Color Me",
		After: "",
	},
	{
		Before: "Trung Tâm Dạy Tester Tester",
		After: "",
	},
	{
		Before: "Trung Tâm Devpro",
		After: "",
	},
	{
		Before: "Trung Tâm Đào",
		After: "",
	},
	{
		Before: "Trung tâm Đào tạo",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo CNTT Bk Aptech",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Code",
		After: "",
	},
	{
		Before: "TRUNG TÂM ĐÀO TẠO CODESTAR",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Devmaster",
		After: "",
	},
	{
		Before: "TRUNG TÂM ĐÀO TẠO EXIM HÀ LÊ",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Ftms Acca Global",
		After: "",
	},
	{
		Before: "Trung tâm đào tạo kế toán",
		After: "",
	},
	{
		Before: "Trung cấp Công nghệ Hà Nội",
		After: "Trung Cấp Công Nghệ Hà Nội",
	},
	{
		Before: "Trung Tâm Đào Tạo Lập Trình Viên Korea It School Hcmc",
		After: "",
	},
	{
		Before: "Trung tâm đào tạo lập trình viên quốc tế APTECH",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Liên Tục- Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Trung Tâm Đào Tạo Mc Và Kỹ Năng Knb Enhance Mc Cơ Bản",
		After: "",
	},
	{
		Before: "Trung tâm đào tạo Mỹ thuật Đa phương ện",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Kiểm Thử Phần Mềm Hà Nội",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Ptland",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Mỹ Thuật Đa Phương Tiện Hà Nội Arena",
		After: "",
	},
	{
		Before: "Trung tâm đào tạo Tester ProVN",
		After: "",
	},
	{
		Before: "TRUNG TÂM ĐÀO TẠO TESTER TOP",
		After: "",
	},
	{
		Before: "Trung tâm đào tạo TesterTop",
		After: "",
	},
	{
		Before: "Trung Tâm Đhkhtn Tphcm",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Trung Tâm FPT Arena Multimedia",
		After: "",
	},
	{
		Before: "TRUNG TÂM GDTX - GDNN QUẬN THANH XUÂN",
		After: "",
	},
	{
		Before: "Trung Tâm Gdtx Ktth Hn Cần Thơ",
		After: "",
	},
	{
		Before: "Trung Tâm Hỗ Trợ Phát Triển Tài Năng Điện Ảnh Tpd Hội Điện",
		After: "",
	},
	{
		Before: "trung tâm idesign đà nẵng",
		After: "",
	},
	{
		Before: "Trung Tâm Đào Tạo Tester Hà Nội",
		After: "",
	},
	{
		Before: "TRUNG TÂM KẾ TOÁN TÀI CHIÍNH TUYẾT PHI",
		After: "",
	},
	{
		Before: "Trung tâm kế toán Thiên Ưng",
		After: "",
	},
	{
		Before: "Trung Tâm Kế Toán Hà Nội",
		After: "",
	},
	{
		Before: "Trung Tâm Mc Sukha",
		After: "",
	},
	{
		Before: "Trung Tâm Ngôn Ngữ Và Văn Hóa",
		After: "",
	},
	{
		Before: "Trung Tâm Nhất Nghệ",
		After: "",
	},
	{
		Before: "Trung Tâm Phát Triển Nguồn Lực Quốc Tế",
		After: "",
	},
	{
		Before: "Trung Tâm Qrs",
		After: "",
	},
	{
		Before: "Trung Tâm Quality Resources Solutions",
		After: "",
	},
	{
		Before: "Trung Tâm T3h",
		After: "",
	},
	{
		Before: "Trung Tâm Tạo Thiết Kế Colorme",
		After: "",
	},
	{
		Before: "Trung Tâm Kế Toán Thiên Ưng Hà Nội",
		After: "",
	},
	{
		Before: "Trung Tâm Tester Hanoi",
		After: "",
	},
	{
		Before: "Trung Tâm Tester Top",
		After: "",
	},
	{
		Before: "Trung Tâm Testertop",
		After: "",
	},
	{
		Before: "Trung tâm tiDng anh The lelts Workshop",
		After: "",
	},
	{
		Before: "Trung Tâm Tiếng Anh Alex Vuong",
		After: "",
	},
	{
		Before: "Trung Tâm Tin Học Vnpro",
		After: "",
	},
	{
		Before: "Trung Tâm Vnpro",
		After: "",
	},
	{
		Before: "TRUNG ƯƠNG GIÁO HỘI PHẬT GIÁO VIỆT NAM",
		After: "",
	},
	{
		Before: "Truyền Thông Thái Nguyên",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "  Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "TRUNG TÂM TESTER HÀ NỘI",
		After: "",
	},
	{
		Before: " Bach Khoa Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: " bách nghệ hóc môn",
		After: "Trung Cấp Bách Nghệ TPHCM",
	},
	{
		Before: "Trưởng Ban Tổ Chức- Xây Dựng Khoa Quản Trị",
		After: "",
	},
	{
		Before: " Cao Dẳng Kinh Tế Kĩ Thuật Trung Ương",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: " Cao đẳng , Kinh Doanh Xuất Nhâp",
		After: "",
	},
	{
		Before: " Cao đẳng An Ninh Mạng Ispace",
		After: "Cao Đẳng An Ninh Mạng iSPACE",
	},
	{
		Before: " Cao đẳng Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: " Cao đẳng Bách Khoa",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: " Cao đẳng Bachkhoa Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: " Cao đẳng Bến Tre",
		After: "Cao Đẳng Bến Tre",
	},
	{
		Before: " Cao đẳng Bình Định",
		After: "Cao Đẳng Bình Định",
	},
	{
		Before: " Cao đẳng Cần Thơ",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: " Cao đẳng CẦN THƠ KẾ TOÁN",
		After: "Cao Đẳng Cần Thơ",
	},
	{
		Before: " Cao đẳng Cộng Đồng Hà Tây",
		After: "Cao Đẳng Cộng Đồng Hà Tây",
	},
	{
		Before: " : Cao đẳng công nghệ hà nội",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: " Cao đẳng công nghệ bách khoa hà nội",
		After: "Cao Đẳng Công Nghệ Bách Khoa Hà Nội",
	},
	{
		Before: " Cao đẳng Công Nghệ Thông Tin",
		After: "Cao Đẳng Công Nghệ Thông Tin TPHCM",
	},
	{
		Before: " Cao đẳng công nghệ thông tin hữu nghị việt hàn",
		After: "Cao Đẳng CNTT Hữu Nghị Việt Hàn - Đại Học Đà Nẵng",
	},
	{
		Before: " Cao đẳng Công Nghệ Thông Tin Ispace",
		After: "",
	},
	{
		Before: " Cao đẳng Công Nghệ Thông Tin TPHCM",
		After: "Cao Đẳng Công Nghệ Thông Tin TPHCM",
	},
	{
		Before: " Cao đẳng Công Nghệ Thông Tin TPHCM",
		After: "Cao Đẳng Công Nghệ Thông Tin TPHCM",
	},
	{
		Before: " Cao đẳng CÔNG NGHỆ THỦ ĐỨC",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: " Cao đẳng Công Nghệ Tp Hồ Chí Minh",
		After: "Cao Đẳng Công Nghệ Thông Tin TPHCM",
	},
	{
		Before: " Cao đẳng Công Nghệ Và Thương Mại",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: " Cao đẳng công nghệ hà nội",
		After: "Cao Đẳng Công Nghệ Cao Hà Nội",
	},
	{
		Before: " Cao đẳng Công Nghệ Và Thương Mại Hà Nội",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: " Cao đẳng công nghiệp huế",
		After: "Cao Đẳng Công Nghiệp Huế",
	},
	{
		Before: " Cao đẳng CÔNG NGHIỆP QUỐC PHÒNG",
		After: "Cao Đẳng Công Nghiệp Quốc Phòng",
	},
	{
		Before: " Cao đẳng Công Nghiệp Thực Phẩm",
		After: "Cao Đẳng Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương Thành Phố Hồ Chí",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương TPHCM",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương Tp Hcm",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương Tp Hcm Ngành Quản Trị Kinh Doanh",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng Công Thương Tphcm",
		After: "Cao Đẳng Công Thương TPHCM",
	},
	{
		Before: " Cao đẳng công thương việt nam",
		After: "Cao Đẳng Công Thương Việt Nam",
	},
	{
		Before: " Cao đẳng Công Thương Viêt Nam Chuyên Ngành",
		After: "Cao Đẳng Công Thương Việt Nam",
	},
	{
		Before: " Cao đẳng Cơ Giới Ninh Bình",
		After: "Cao Đẳng Nghề Cơ Giới Ninh Bình",
	},
	{
		Before: " Cao đẳng Du Lịch Đà Nẵng",
		After: "Cao Đẳng Du Lịch Đà Nẵng",
	},
	{
		Before: " Cao đẳng Công Nghệ Và Thương Mại Hà Nội Dược",
		After: "Cao Đẳng Công Nghệ Và Thương Mại Hà Nội",
	},
	{
		Before: " Cao đẳng Du Lịch Huế",
		After: "Cao Đẳng Du Lịch Huế",
	},
	{
		Before: " Cao đẳng Du Lịch Khách Sạn Jtb",
		After: "",
	},
	{
		Before: " Cao đẳng Dược Tw Hải Dương",
		After: "Cao Đẳng Dược Trung Ương Hải Dương",
	},
	{
		Before: " Cao đẳng Đại Việt Sài Gòn",
		After: "Cao Đẳng Đại Việt Sài Gòn",
	},
	{
		Before: " Cao đẳng Du Lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: " Cao đẳng FPT",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng Điện Tử - Điện Lạnh Hà Nội",
		After: "Cao Đẳng Điện Tử - Điện Lạnh Hà Nội",
	},
	{
		Before: " Cao đẳng FPT Jetking",
		After: "Cao Đẳng FPT Jetking",
	},
	{
		Before: " Cao đẳng FPT Polytechnic",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng giao thông cận tải trung",
		After: "Cao Đẳng Giao Thông Vận Tải Trung Ương",
	},
	{
		Before: " Cao đẳng giao thông vận tải tp HCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Cao đẳng Kĩ Thuật Công Nghệ Tp Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Cao đẳng Kiên Giang",
		After: "Cao Đẳng Kiên Giang",
	},
	{
		Before: " Cao đẳng kinh tế",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng KINH TẾ - KẾ HOẠCH",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: " Cao đẳng Kinh Tế Công Nghệ Quản Lí Nhân Sự",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao Đẵng Kinh Tế Công Nghệ Tp Hcm",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: " Cao đẳng Kinh Tế Công Nghệ Tphcm",
		After: "Cao Đẳng Kinh Tế Công Nghệ TPHCM",
	},
	{
		Before: " Cao đẳng FPT Hà Nội",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng KINH TẾ ĐỐI",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cao đẳng KINH TẾ ĐỐI NGOẠI",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cao đẳng Kinh Tế Đối Ngoại Cấp",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cao đẳng Kinh Tế Đối Ngoại Chuyên Ngành",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cao đẳng Kinh Tế Đối Với",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cao đẳng Kinh Tế Kế Hoạch",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: " Cao đẳng Kinh Tế Kế Hoạch Đà",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: " Cao đẳng KINH TẾ KẾ HOẠCH ĐÀ NẴNG",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: " Cao đẳng Kinh Tế Kĩ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: " Cao đẳng Kinh Tế Kĩ Thuật Thương Mại",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Thương Mại",
	},
	{
		Before: " Cao đẳng Kinh Tế Kỹ Thuật",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật TPHCM",
	},
	{
		Before: " Cao đẳng Kinh Tế Kỹ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Cần Thơ",
	},
	{
		Before: " Cao đẳng Kinh Tế Kỹ Thuật Thái Nguyên",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật - ĐH Thái Nguyên",
	},
	{
		Before: " Cao đẳng Kinh Tế Kỹ Thuật Trung Ương",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: " Cao đẳng kinh tế phúc lợi toshima",
		After: "Đại Học Phúc Lợi Tokyo, Nhật Bản",
	},
	{
		Before: " Cao đẳng Kinh tế TPHCM",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng Kinh Tế Tp Hcm",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng Kinh Tế Tp Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng kinh tế tphcm",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng Ktkt Vinatex Tp Hồ Chí Minh",
		After: "Cao Đẳng Kinh Tế TPHCM",
	},
	{
		Before: " Cao đẳng Kỹ Thuật Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: " Cao đẳng Kỹ Thuật Cao Thắng Điện Tử Truyền Thông",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: " Cao đẳng lý tự trọng",
		After: "Cao Đẳng Lý Tự Trọng TPHCM",
	},
	{
		Before: " Cao đẳng Miền Nam",
		After: "Cao Đẳng Miền Nam",
	},
	{
		Before: " Cao đẳng nghề An Giang",
		After: "Cao Đẳng Nghề An Giang",
	},
	{
		Before: " Cao đẳng Nghề Bách Khoa",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: " Cao đẳng Kinh Tế Công Nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: " Cao đẳng Nghề Bình Thuận Chuyên Nghành Quản",
		After: "Cao Đẳng Bình Thuận",
	},
	{
		Before: " Cao đẳng Nghề Bách Khoa Hà Nội",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: " Cao đẳng Nghề BK Hà Nội",
		After: "Cao Đẳng Bách Khoa",
	},
	{
		Before: " Cao đẳng Nghề Công Nghệ Cao Hà Nội Công Nghệ Thông",
		After: "Cao Đẳng Công Nghệ Hà Nội",
	},
	{
		Before: " Cao đẳng nghề đà nẵng",
		After: "Cao Đẳng Nghề Đà Nẵng",
	},
	{
		Before: " Cao đẳng Nghề Gtvt Trung Ương",
		After: "Cao Đẳng Giao Thông Vận Tải Trung Ương",
	},
	{
		Before: " Cao đẳng nghề nguyễn văn trỗi",
		After: "Cao Đẳng Nghề Nguyễn Văn Trỗi",
	},
	{
		Before: " Cao đẳng NGHỀ SỐ",
		After: "",
	},
	{
		Before: " Cao đẳng Nghề Công Nghiệp Hà Nội",
		After: "Cao Đẳng Nghề Công Nghiệp Hà Nội",
	},
	{
		Before: " Cao đẳng Nông Lâm Phú Thọ",
		After: "Cao Đẳng Công Nghệ Và Nông Lâm Phú Thọ",
	},
	{
		Before: " Cao đẳng Ở Nhật Bản",
		After: "",
	},
	{
		Before: " Cao đẳng Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: " Cao đẳng Phương Đông Đà Nẵng",
		After: "Đại Học Phương Đông",
	},
	{
		Before: " Cao đẳng Quản Trị Purosuperagakuin Nhật",
		After: "",
	},
	{
		Before: " Cao đẳng Sài Gòn",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: " Cao đẳng Sài Gòn Chuyên Ngành Quản Trị Kinh Doanh",
		After: "Cao Đẳng Sài Gòn",
	},
	{
		Before: " Cao đẳng Sông Đà",
		After: "Cao Đẳng Nghề Sông Đà",
	},
	{
		Before: " Cao đẳng Sư Phạm",
		After: "",
	},
	{
		Before: " Cao Đăng Sư Phạm Đắk Lắk",
		After: "Cao Đẳng Sư Phạm Đắk Lắk",
	},
	{
		Before: " Cao đẳng Sư Phạm Trung Ương",
		After: "Cao Đẳng Sư Phạm Trung Ương",
	},
	{
		Before: " Cao đẳng TÀI CHÍNH HẢI QUAN KINH DOANH XUẤT",
		After: "Cao Đẳng Tài Chính Hải Quan",
	},
	{
		Before: " Cao đẳng Thực Hành FPT",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng thực hành FPT Polytechnic Đà Nẵng",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng Thực Hành FPT Ứng Dụng Phần Mềm",
		After: "Cao Đẳng FPT Polytechnic",
	},
	{
		Before: " Cao đẳng Thương Mại",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: " Cao đẳng Thương Mại Đà Nẵng",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: " Cao đẳng Thương Mại Đà Nẵng Quản Trị Kinh Doanh Khách Sạn",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: " Cao đẳng Thương mại và du lịch",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: " Cao đẳng Nội Vụ Hà Nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: " Cao đẳng thương mại và du lịch hà nội",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: " Cao đẳng Truyền Hình",
		After: "Cao Đẳng Truyền Hình",
	},
	{
		Before: " Cao đẳng Viễn Đông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: " Cao đẳng viễn thông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: " Cao đẳng Việt Mỹ",
		After: "Cao Đẳng Việt Mỹ",
	},
	{
		Before: " Cao đẳng Xây Dựng Số 2 TR.HCM",
		After: "Cao Đẳng Xây Dựng TPHCM",
	},
	{
		Before: " Cao đẳng Thương Mại Và Du Lịch Hà Nội Quản Trị Kinh Doanh",
		After: "Cao Đẳng Thương Mại Và Du Lịch Hà Nội",
	},
	{
		Before: " Cao đẳng Y Tế Cần Thơ",
		After: "Cao Đẳng Y Tế Cần Thơ",
	},
	{
		Before: " Cao đẳng y dược hà nội",
		After: "Cao Đẳng Y Dược Hà Nội",
	},
	{
		Before: " Cao đẳng Y Tế Khánh Hòa Dược Sĩ",
		After: "Cao Đẳng Y Tế Khánh Hòa",
	},
	{
		Before: " Cao đẳng Y TẾ QUẢNG",
		After: "",
	},
	{
		Before: " Cđ Công Nghệ Thủ Đức",
		After: "Cao Đẳng Công Nghệ Thủ Đức",
	},
	{
		Before: " Cđ Công Nghệ Và Thương Mại",
		After: "Cao Đẳng Công Nghệ Và Thương Mại",
	},
	{
		Before: " Cao đẳng y tế hà nội",
		After: "Cao Đẳng Y Tế Hà Nội",
	},
	{
		Before: " Cđ Kinh Tế Đố Ngoại",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: " Cđ Kinh Tế Kế Hoạch Đà Nẵng",
		After: "Cao Đẳng Kinh Tế Kế Hoạch Đà Nẵng",
	},
	{
		Before: " Cđ Kinh Tế Kĩ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: " Cđ Kinh Tế Kỹ Thuật Cần Thơ",
		After: "Cao Đẳng Kinh Tế - Kỹ Thuật Cần Thơ",
	},
	{
		Before: " CĐ Phát thanh - Truyền hình II",
		After: "Cao Đẳng Phát Thanh - Truyền Hình II",
	},
	{
		Before: " Cđcđ Hậu Giang",
		After: "Cao Đẳng Cộng Đồng Hậu Giang",
	},
	{
		Before: " Cđkt Cao Thắng",
		After: "Cao Đẳng Kỹ Thuật Cao Thắng",
	},
	{
		Before: " CHÍNH TRỊ QUẢNG NAM",
		After: "",
	},
	{
		Before: " Chính Trị Tỉnh",
		After: "",
	},
	{
		Before: " Chuyên Võ Nguyên Giáp",
		After: "",
	},
	{
		Before: " Chương Trình Cử Nhân Công Nghệ Thực Phẩm",
		After: "",
	},
	{
		Before: " Cđ Kinh Tế Công Nghiệp Hà Nội",
		After: "Cao Đẳng Kinh Tế Công Nghiệp Hà Nội",
	},
	{
		Before: " CNTT Bachkhoa Aptech",
		After: "Hệ Thống Đào Tạo CNTT Quốc Tế Bách Khoa Aptech",
	},
	{
		Before: " CNTT và TT, Đại Học BKHN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " CNTT - Đại Học bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " CNTT&TT- ĐH Bách Khoa HN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " CNTT&TT - Đại Học Bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công Nghệ Bách Khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " CNTT&TT, Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công Nghệ Thông Tin Và Truyền",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công nghệ thông tin và Truyền thông",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công Nghệ Thông Tin Truyền Thông - Đại Học Bách khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công nghệ thông tin và truyền thông - Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công nghệ thông tin và truyền thông, Đại Học BKHN",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Công Nghiệp Tp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Dạy Nghề Bách Khoa",
		After: "",
	},
	{
		Before: " Dh Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Doanh Nhân Hbr",
		After: "",
	},
	{
		Before: " Du Lịch- Đại Học Huế",
		After: "Đại Học Huế",
	},
	{
		Before: " ĐẠI",
		After: "",
	},
	{
		Before: " Công nghệ thông tin và truyền thông Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Đại Học",
		After: "",
	},
	{
		Before: " Đại Học : Công Nghệ Kỹ Thuật",
		After: "",
	},
	{
		Before: " Đại Học An Giang",
		After: "Đại Học An Giang - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học bách khoa",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Đại Học bách khoa đà",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Bách khoa Đà Nẵng",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: " Đại  Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Đại Học Bách Khoa TPHCM",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Bách Khoa Tphcm",
		After: "Đại Học Bách Khoa - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học CẦN THƠ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: " Đại Học Cần Thơ Kinh Doanh Quốc Tế Chất Lượng Cao",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: " Đại Học cần thơ kinh tế nông nghiệp",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: " Đại Học Chungang Hàn Quốc",
		After: "Đại Học Chungang, Hàn Quốc",
	},
	{
		Before: " Đại Học Chuyên Ngành Kế Toán Kiểm Toán",
		After: "",
	},
	{
		Before: " Đại Học CNTT Gia Định",
		After: "Đại Học Gia Định",
	},
	{
		Before: " Đại Học công",
		After: "",
	},
	{
		Before: " Đại Học CÔNG ĐOÀN",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: " Đại Học Công Đoàn Việt Nam",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: " Đại Học công nghệ",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học BÁCH KHOA HÀ NỘI",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " Đại Học Công nghê - ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học Công nghệ - ĐHQG Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học công nghệ Đông Ắ",
		After: "Đại Học Công Nghệ Đông Á",
	},
	{
		Before: " Đại Học Công Nghệ Giao thông vận tải",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Công Nghệ Giao Thông Vận Tải Chuyên Ngành",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before:
			" Đại Học Công Nghệ Giao Thông Vận Tải Chuyên Nghành Kinh Tế Xây Dựng",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Công Nghệ Gtvt",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Công Nghệ Gtvt Kế Toán",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Công Nghệ Sài Gòn",
		After: "Đại Học Công Nghệ Sài Gòn",
	},
	{
		Before: " Đại Học Công Nghệ Thành Phố",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công Nghệ Thành Phố Hồ Chí",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công Nghệ TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before:
			" Đại Học Công nghệ Thông tin & Truyền thông -  Đại Học Thái  Nguyên",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công nghệ Thông tin ĐHQG TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công nghệ thông tin TPHCM",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học công nghệ tp hcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công Nghệ TP HCM ( HUTECH )",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công Nghệ TP Hồ Chí Minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học công nghệ TP.hồ chí minh",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học công nghệ tphcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Công Nghệ Và",
		After: "",
	},
	{
		Before: " Đại Học CÔNG NGHỆ Đại Học QUỐC GIA HÀ NỘI",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học CÔNG NGHỆ, ĐHQGHN",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học công nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công nghiệp Dệt",
		After: "Đại Học Công Nghiệp Dệt May Hà Nội",
	},
	{
		Before: " Đại Học Công Nghệ, Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Chuyên Ngành",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Kế Toán Kiểm Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Khoa Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Khoa Quản Lý Kinh Doanh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Ngành Quản Trị Nhân Lực",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học Công Nghiệp Thành Phố HCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học công nghiệp thành phố hồ chí",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học công nghiệp thực phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Thành",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công nghiệp Thực phẩm Thành phố",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công nghiệp Thực phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Tp",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học công nghiệp thực phẩm tp hcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Tp Hồ Chí Minh Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm TP. HCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công nghiệp Thực phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công nghiệp Thực phẩm TP.Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học công nghiệp thực phẩm tphcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Tphcm Quản Trị",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Tphcm Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Tp Hcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Tp Hcm Quản Trị Kinh Doanh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Tp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp TP. HCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp TpHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công Nghiệp Tphcm Kế Toán",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đại Học Công nghiệp Việt Hung",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: " Đại Học Công Nghiệp Việt Trì",
		After: "Đại Học Công Nghiệp Việt Trì",
	},
	{
		Before: " Đại Học Cửu Long",
		After: "Đại Học Cửu Long",
	},
	{
		Before: " Đại Học Dân Lập Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: " Đại Học Dân Lập Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: " Đại Học Dân Lập Văn Lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: " Đại Học Du Lịch",
		After: "",
	},
	{
		Before: " Đại Học Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đại Học Duy Tân Đà Nẵng",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đại Học DUY TÂN ĐÀ NẴNG QUẢN TRỊ KINH DOANH",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đại Học Duy Tân Khoa Đào Tạo",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đại Học Duy Tân Truyền Thông Đa Phương Tiện",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đại Học Công Nghiệp Hà Nội Thời Gian",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đại Học ĐÀ LẠT",
		After: "Đại Học Đà Lạt",
	},
	{
		Before: " Đại Học Đại",
		After: "",
	},
	{
		Before: " Đại Học Đại Học Thái Nguyên |",
		After: "Đại Học Thái Nguyên",
	},
	{
		Before: " Đại Học Đại Nam",
		After: "Đại Học Đại Nam",
	},
	{
		Before: " Đại Học ĐIỆN LỰC",
		After: "Đại Học Điện Lực",
	},
	{
		Before: " Đại Học Dược Hà Nội",
		After: "Đại Học Dược Hà Nội",
	},
	{
		Before: " Đại Học Điện Lực Khoa Điều Khiển Và Tự Động Hóa",
		After: "Đại Học Điện Lực",
	},
	{
		Before: " Đại Học Đông Á",
		After: "Đại Học Đông Á",
	},
	{
		Before: " Đại Học Đông Đô",
		After: "Đại Học Đông Đô",
	},
	{
		Before: " Đại Học Đồng Nai",
		After: "Đại Học Đồng Nai",
	},
	{
		Before: " Đại Học Đồng Tháp",
		After: "Đại Học Đồng Tháp",
	},
	{
		Before: " Đại Học FPT",
		After: "Đại Học FPT",
	},
	{
		Before: " Đại Học FPT campus hòa lạc",
		After: "Đại Học FPT",
	},
	{
		Before: " Đại Học Gia Định",
		After: "Đại Học Gia Định",
	},
	{
		Before: " Đại Học Giang",
		After: "",
	},
	{
		Before: " Đại Học Giao Thông Vận Tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Điện Lực Hà Nội",
		After: "Đại Học Điện Lực",
	},
	{
		Before: " Đại Học Giao Thông Vận Tải Phân Hiệu Tại",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Đại Học GIAO THÔNG VẬN TẢI TẠI THÀNH",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Đại Học Giao Thông Vận Tải Tp Hcm",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Đại Học Giao Thông Vận Tải Tp Hcm Quản",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Đại Học Greenwich Đà Nẵng",
		After: "Đại Học Greenwich Đà Nẵng",
	},
	{
		Before: " Đại Học Greenwich Việt Nam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: " Đại Học Giao Thông Vận Tải Hà Nội",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: " Đại Học Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: " Đại Học Hoa Sen Quận",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: " Đại Học Hùng Vương Ngành Truyền Thông Đa Phương Tiện",
		After: "Đại Học Hùng Vương TPHCM",
	},
	{
		Before: " Đại Học Hùng Vương Tphcm",
		After: "Đại Học Hùng Vương TPHCM",
	},
	{
		Before: " Đại Học Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Đại Học Keimyung",
		After: "Đại Học Keimyung, Hàn Quốc",
	},
	{
		Before: " Đại Học Kế Toán Doanh",
		After: "",
	},
	{
		Before: " Đại Học Kế Toán Kiểm",
		After: "",
	},
	{
		Before: " Đại Học Khoa Học Huế",
		After: "Đại Học Khoa Học - ĐH Huế",
	},
	{
		Before: " Đại Học Khoa Học Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Tự Nhiên",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học khoa Học tự nhiên Đại Học quốc gia hà",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: " Đại Học Khoa Học Tự Nhiên Khoa Môi ",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Tự Nhiên Vnu",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Tự Nhiên, ĐHQGHN | Khoa Công Nghệ Sinh Học",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học khoa Học tự nhiên Đại Học quốc gia hà nội",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Nhân Văn Đhqghn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Và Nhân",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học khoa Học xã hội và nhân văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Tphcm",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Khoa Học xã hội và Nhân văn TPHCM",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Khoa Học Xã Hội Và Nhân Văn Vnu Ngôn Ngữ Và Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học Khoa Học- Đại Học Thái Nguyên",
		After: "Đại Học Khoa Học - ĐH Thái Nguyên",
	},
	{
		Before:
			" Đại Học Khoa Học Xã Hội Và Nhân Văn Đại Học Quốc Gia Hà Nội Văn Học",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đại Học kiến",
		After: "",
	},
	{
		Before: " Đại Học Kiên Giang",
		After: "Đại Học Kiên Giang",
	},
	{
		Before: " Đại Học KIẾN TRÚC ĐÀ NẴNG",
		After: "Đại Học Kiến Trúc Đà Nẵng",
	},
	{
		Before: " Đại Học Kiểm Sát Hà Nội",
		After: "Đại Học Kiểm Sát Hà Nội",
	},
	{
		Before: " Đại Học Kinh",
		After: "",
	},
	{
		Before: " Đại Học kinh doanh & công nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học kinh doanh & công nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh Công Nghệ Hà",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học kiến trúc hà nội",
		After: "Đại Học Kiến Trúc Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh Quốc Tế",
		After: "",
	},
	{
		Before: " Đại Học Kinh Doanh Và",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh Và Công",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh và Công nghệ",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học kinh doanh và công nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Doanh Và Công Nghệ Hn",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh Tế",
		After: "",
	},
	{
		Before: " Đại Học Kinh Doanh Và Công Nghệ Hà Nội Tốt",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Đại Học Kinh tế - ĐH Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh tế - Kỹ thuật Công nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh Tế Đại Học",
		After: "",
	},
	{
		Before: " Đại Học Kinh Tế Đại Học Đà",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học KINH TẾ Đại Học ĐÀ NẴNG",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh tế Đại Học Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh Tế Đại Học Đà Nẵng Chuyên Ngành Kinh Tế Đầu Tư",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh Tế Đại Học Đà Nẵng Chuyên Ngành Quản Trị Kinh",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học kinh tế Đại Học đà nẵng khoa thống kê tin Học",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh Tế Đại Học Đà Nẵng Sinh Viên Ngành Kế Toán",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Kinh tế Đại Học Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Đại Học kinh tế Đại Học quốc gia hà",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học KINH TẾ Đại Học QUỐC GIA HÀ HỘI",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học Kinh tế - Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học Kinh Tế Đhqghn",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học Kinh Tế Đhqghn , Kinh Tế",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học Kinh Tế Đối Ngoại",
		After: "",
	},
	{
		Before: " Đại Học KINH TẾ HUẾ",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Đại Học Kinh tế Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Đại Học Kinh Tế Huế Đại Học Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Đại Học Kinh tế HuếNiên khóa",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Đại Học kinh tế kĩ thuật",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học kinh tế kĩ thuật công nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kĩ Thuật Công Nghiệp Hà",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học kinh tế Đại Học quốc gia hà nội",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: " Đại Học kinh tế kỹ thuật",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kỹ Thuật Công",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kĩ Thuật Công Nghiệp Hà Nội Chuyên",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Hn",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Kinh Tế Kỹ Thuật Công Nghiệp Kế Toán",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học KINH TẾ LUẬT",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Luật Đại Học Quốc Gia TPHCM",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Luật Đại Học Quốc Gia Tphcm",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Luật Tphcm",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học kinh tế quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: " Đại Học Kinh Tế Quốc Dân Ngành Kinh Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: " Đại Học Kinh Tế Quốc Dân Thời Gian",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: " Đại Học Kinh Tế Tài Chính Tphcm",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Thành",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Thành Phố",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Thành Phố Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Tp Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Tp Hcm Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế TP Hồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before:
			" Đại Học Kinh Tế Tp Hồ Chí Minh Viện Nghiên Cứu Kinh Tế Phát Triển",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế TPHCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Tphcm Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Tphồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Tphồ Chí Minh Kế Toán",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học Kinh Tế Và Qtkd Thái Nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: " Đại Học Kinh Tế và Quản Trị Kinh Doanh Thái",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: " Đại Học kinh tế và quản trị kinh doanh thái nguyên",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: " Đại Học Lạc Hồng",
		After: "Đại Học Lạc Hồng",
	},
	{
		Before: " Đại Học Lao Động Và Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Cơ Sở",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Cơ Sở 2",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Cơ Sở Ii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Cs Ii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Csii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Csii Tphcm",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học KINH TẾ KỸ THUẬT CÔNG NGHIỆP HÀ NỘI",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Ii",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Quản Trị Kinh Doanh",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Tp Hồ Chí Minh",
		After: "Đại Học Lao Động - Xã Hội Cơ Sở 2, TPHCM",
	},
	{
		Before: " Đại Học Lao Động- Xá Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lao Động-Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Lâm Nghiệp",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: " Đại Học Luật",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: " Đại Học Lao Động Xã Hội Hà Nội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đại Học Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: " Đại Học Luật Tp Hcm",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: " Đại Học Luật Tphcm",
		After: "Đại Học Luật TPHCM",
	},
	{
		Before: " Đại Học Mỏ - ĐỊA CHẤT",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mỏ - địa chất / HUMG",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Luật Hà Nội | Ngành Luật Dân Sự Và",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: " Đại Học mỏ địa chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mỏ Địa Chất Công Nghệ Phân Mềm",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học MỎ ĐỊA CHẤT KẾ TOÁN",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mỏ Địa Chất Khóa Học",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mỏ Địa Chất Quản Lý Đất Đai",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "Trường Đại Học Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: " Đại Học MỞ HÀ NỘI",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: " Đại Học Mở TPHCM",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: " Đại Học Mở Tp Hcm",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: " Đại Học Mỏ Đại Chất Hà Nội",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đại Học Mở Tp Hồ Chí Minh",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: " Đại Học mở tphcm",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: " Đại Học Nam Cần Thơ",
		After: "Đại Học Nam Cần Thơ",
	},
	{
		Before: " Đại Học ngân hàng",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đại Học NGÂN HÀNG TPHCM",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đại Học ngân hàng tp hcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đại Học ngân hàng tp hồ chí minh",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đại Học Ngân Hàng Tphcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đại Học Ngoại",
		After: "",
	},
	{
		Before: " Đại Học Ngoại ngữ - Đại Học Đà Nẵng",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Ngoại ngữ - Tin Học",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: " Đại Học Ngoại ngữ - Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: " Đại Học Ngoại ngữ - Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: " Đại Học ngoại ngữ Đại Học đà",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Ngoại Ngữ Đại Học Đà Nẵng Chuyên Ngành Đông Phương Học",
		After: "Đại Học Ngoại Ngữ - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Ngoại Ngữ và Tin Học",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: " Đại Học Ngoại ngư-Đại Học Quốc gia Hà Nội",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: " Đại Học Ngoại ngữ-Tin Học TPHCM",
		After: "Đại Học Ngoại Ngữ Tin Học TPHCM",
	},
	{
		Before: " Đại Học Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: " Đại Học Ngoại Thương Chuyên Ngành Kinh Tế Đối Ngoại",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: " Đại Học Ngoại Thương Ftu",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: " Đại Học ngoại thương hà nội",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: " Đại Học Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: " Đại Học NHA TRANG",
		After: "Đại Học Nha Trang",
	},
	{
		Before: " Đại Học Nội Vụ Hà Nội",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: " Đại Học Nông Lâm TPHCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: " Đại Học Nông Lâm TP HCM",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: " Đại Học nông lâm tphcm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: " Đại Học nông nghiệp hà nội",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: " Đại Học open university",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: " Đại Học Phương Đông",
		After: "Đại Học Phương Đông",
	},
	{
		Before: " Đại Học Phương Đông Ngôn Ngữ Nhật",
		After: "Đại Học Phương Đông",
	},
	{
		Before: " Đại Học Quản Trị Dịch Vụ Du Lịch Và Lữ Hành",
		After: "",
	},
	{
		Before: " Đại Học Quản Trị Nhân Lực",
		After: "",
	},
	{
		Before: " Đại Học Quảng Nam",
		After: "Đại Học Quảng Nam",
	},
	{
		Before: " Đại Học quốc gia",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Đại Học Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Đại Học Quốc Tế Hồng Bàng",
		After: "Đại Học Quốc Tế Hồng Bàng",
	},
	{
		Before: " Đại Học Quốc Tế TPHCM",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before: " Đại Học Quy Nhơn",
		After: "Đại Học Quy Nhơn",
	},
	{
		Before: " Đại Học Sài Gòn",
		After: "Đại Học Sài Gòn",
	},
	{
		Before: " Đại Học Sân Khấu Điện Ảnh Hà Nội",
		After: "Đại Học Sân Khấu - Điện Ảnh Hà Nội",
	},
	{
		Before: " Đại Học Spkt Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đại Học Spkt Hưng Yên Chuyên Ngành",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đại Học Sư Phạm Đà Nẵng",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học sư phạm đhđn",
		After: "Đại Học Sư Phạm - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học Sư Phạm Giáo Dục Chính Trị",
		After: "",
	},
	{
		Before: " Đại Học Sư Phạm Hà Nội",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: " Đại Học Sư Phạm Hà Nội Tháng",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: " Đại Học Sư Phạm Hà Nộii",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: " Đại Học Sư Phạm Huế",
		After: "Đại Học Sư Phạm - ĐH Huế",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ Thuật",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đại Học sư phạm kỹ thuật đà",
		After: "Đại Học Sư Phạm Kỹ Thuật - ĐH Đà Nẵng",
	},
	{
		Before: " Đại Học sư phạm kỹ thuật hưng yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ Thuật Hưng Yên Công Nghệ Website",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ Thuật Nam Định",
		After: "Đại Học Sư Phạm Kỹ Thuật Nam Định",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ Thuật TPHCM Chuyên Ngành Kế Toán",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ thuật thành phố Hồ Chí Mink",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: " Đại Học Sư Phạm Kỹ Thuật Tphcm",
		After: "Đại Học Sư Phạm Kỹ Thuật TPHCM",
	},
	{
		Before: " Đại Học tài",
		After: "",
	},
	{
		Before: " Đại Học Tài chính",
		After: "",
	},
	{
		Before: " Đại Học Tài Chính - Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài chính - ngân hàng",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học tài chính - ngân hàng hà nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học Tài Chính Doanh Nghiệp",
		After: "",
	},
	{
		Before: " Đại Học Tài Chính Kế Toán",
		After: "Đại Học Tài Chính - Kế Toán",
	},
	{
		Before: " Đại Học TÀI CHÍNH KẾ TOÁN QUẢNG NGÃI",
		After: "Đại Học Tài Chính - Kế Toán",
	},
	{
		Before: " Đại Học tài chính maketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài Chính Markerting",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học tài chính marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài Chính Marketing Chuyên",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài Chính Marketing Tp",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài chính Marketing TpHCM",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài Chính Ngân Hàng",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học TÀI CHÍNH NGÂN HÀNG HÀ NỘI",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before:
			" Đại Học Tài Chính Ngân Hàng Hà Nội Chuyên Ngành Tài Chính Doanh Nghiệp",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học Tài Chính Ngân Hàng Hà Nội Sinh Viên Năm",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học Tài Chính Nhân Hàng Hà Nội Kế Toán",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đại Học Tài Chính Quản Trị Kinh Doanh",
		After: "Đại Học Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: " Đại Học Tài Chính Quản Trị Kinh Doanh Chuyên Ngành Kế Toán",
		After: "Đại Học Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: " Đại Học Tài Chính- Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đại Học Tài Nguyên Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học TÀI NGUYÊN MÔI  HÀ NỘI QUẢN LÝ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học tài nguyên và môi",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học Tài Nguyên Và Môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học Tài nguyên và môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học Tài Nguyên Và Môi Trường Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học tài nguyên và môi  hà nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học Tài Nguyên Và Môi  TPHCM",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đại Học Tài Nguyên Và Môi  Tphcm",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: " Đại Học Tây Đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: " Đại Học Tây Đô Cử Nhân Quản Trị Kinh Doanh",
		After: "Đại Học Tây Đô",
	},
	{
		Before: " Đại Học Tây Nguyên",
		After: "Đại Học Tây Nguyên",
	},
	{
		Before: " Đại Học Thạc Sỹ Kinh Tế Quản Trị Kinh Doanh",
		After: "Đại Học Kinh Tế Và Quản Trị Kinh Doanh - ĐH Thái Nguyên",
	},
	{
		Before: " Đại Học Thành Đô",
		After: "Đại Học Thành Đô",
	},
	{
		Before: " Đại Học THĂNG LONG",
		After: "Đại Học Thăng Long",
	},
	{
		Before: " Đại Học Thể Dục Thể Thao",
		After: "Đại Học Thể Dục Thể Thao TPHCM",
	},
	{
		Before: " Đại Học Thủ Dầu Một",
		After: "Đại Học Thủ Dầu Một",
	},
	{
		Before: " Đại Học Thủ Đô Hà Nội",
		After: "Đại Học Thủ Đô Hà Nội",
	},
	{
		Before: " Đại Học Thủy Lợi",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: " Đại Học Thủy Lợi Đại Học",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: " Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học Thương Mại Chuyên Ngành Quản Trị Nhân Lực",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học Thương Mại Hà Nội",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học thương mại khoa kế toán kiểm toán",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học Thương Mại Kinh Doanh Quốc Tế",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học THƯƠNG MẠI QUẢN TRỊ KHÁCH SẠN",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học Thương Mại Tài Chính Ngân Hàng",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Đại Học Tiếng Tây Ban Nha",
		After: "",
	},
	{
		Before: " Đại Học toulon pháp",
		After: "Đại Học Toulon",
	},
	{
		Before: " Đại Học TÔN ĐỨC THẮNG",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: " Đại Học Tổng Hợp La Habana Cuba",
		After: "Đại Học Tổng Hợp La Habana, Cuba",
	},
	{
		Before: " Đại Học Trà Vinh",
		After: "Đại Học Trà Vinh",
	},
	{
		Before: " Đại Học Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đại Học văn hiên",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: " Đại Học Văn Hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before: " Đại Học Văn Hoá Thành Phố",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: " Đại Học Văn Hoá Tp HCM",
		After: "Đại Học Văn Hóa TPHCM",
	},
	{
		Before: " Đại Học văn lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: " Đại Học vinh",
		After: "Đại Học Vinh",
	},
	{
		Before: " Đại Học Võ  Toản",
		After: "Đại Học Võ  Toản",
	},
	{
		Before: " Đại Học Xây dựng",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "TRƯƠNG Đại Học XÂY DỰNG HÀ NỘI",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: " Đại Học Y Khoa Vinh",
		After: "Đại Học Y Khoa Vinh",
	},
	{
		Before: " Đại Học Y Tế Công Cộng",
		After: "Đại Học Y Tế Công Cộng",
	},
	{
		Before: " Đào Tạo Doanh Nhân",
		After: "",
	},
	{
		Before: " Đào Tạo Đại Học Nông Lâm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: " Đào Tạo Lập Trình Viên Quốc Tế Thăng Long Aptech",
		After: "Đào Tạo Lập Trình Viên Quốc Tế Thăng Long - Aptech",
	},
	{
		Before: " Đào Tạo- Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đh Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: " ĐH Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: " Đh Công Nghệ Đhqg Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đh Công Nghệ- Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: " Đh Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đh Công Nghiệp Hà Nội Qtkd Clc",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đh Công Nghiệp Thực Phẩm Tp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " ĐH Công Nghiệp Thực Phẩm TPHCM",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đh Công Nghiệp Thực Phẩm Tphcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đh Công Nghiệp Tp Hồ Chí Minh",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " ĐH Công Nghiệp TPHCM",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đh Công Nghiệp Tphcm",
		After: "Đại Học Công Nghiệp TPHCM",
	},
	{
		Before: " Đh Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: " Đh Đại Nam",
		After: "Đại Học Đại Nam",
	},
	{
		Before: " đh giao thông vận tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: " Đh Giao Thông Vận Tải Hn",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: " ĐH Hà Nội",
		After: "Đại Học Hà Nội",
	},
	{
		Before: " ĐH Khoa Học Xã hội & Nhân văn - ĐHQG Hà Nội.",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: " Đh Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " ĐH KINH DOANH VÀ CÔNG NGHỆ HÀ NỘI DU LỊCH",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " đh kinh tế ĐH Đà Nẵng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đh Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " đh kinh tế quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: " Đh Kinh Tế Tp Hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Đh Kinh Tế Tphcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " ĐH Lao động và Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " Đh Lao Động Xã hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " ĐH Lao động Xã hội Loại khá",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: " ĐH Lâm Nghiệp",
		After: "Đại Học Lâm Nghiệp Việt Nam",
	},
	{
		Before: " Đh Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: " Đh Ngân Hàng",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đh Ngân Hàng Tphcm",
		After: "Đại Học Ngân Hàng TPHCM",
	},
	{
		Before: " Đh Ngoại Thương",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: " Đh Nông Lâm Tphcm",
		After: "Đại Học Nông Lâm TPHCM",
	},
	{
		Before: " Đh Sư Phạm Kỹ Thuật Hưng Yên",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before: " Đh Sư Phạm Tp Hcm Chuyên Ngành Ngôn Ngữ Anh Thương Mại",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: " ĐH Tài chính - Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " ĐH Tài chính -Ngân Hàng Hà Nội",
		After: "Đại Học Tài Chính - Ngân Hàng Hà Nội",
	},
	{
		Before: " Đh Tài Chính Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: " Đh Tài Nguyên Và Môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " ĐH Tài nguyên và Môi  Hà Nội",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: " Đh Tài Nguyên Và Môi  Tphcm",
		After: "Đại Học Tài Nguyên Và Môi  TPHCM",
	},
	{
		Before: " đh tây đô",
		After: "Đại Học Tây Đô",
	},
	{
		Before: " Đh Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " ĐH Tôn Đức Tháng",
		After: "Đại Học Tôn Đức Thắng",
	},
	{
		Before: " Đh Văn Hóa Nghệ Thuật Quân Đội",
		After: "Đại Học Văn Hóa - Nghệ Thuật Quân Đội",
	},
	{
		Before: " Đh Vhnt Quân Đội",
		After: "Đại Học Văn Hóa - Nghệ Thuật Quân Đội",
	},
	{
		Before: " Đhcn Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: " Đhkt Đhđn Ngân Hàng",
		After: "Đại Học Kinh Tế - ĐH Đà Nẵng",
	},
	{
		Before: " Đhnn Đhqghn",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: " đhtc-qtkd",
		After: "Đại Học Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: " đời",
		After: "",
	},
	{
		Before: " Đơn Vị",
		After: "",
	},
	{
		Before: " đơn vị đào tạo",
		After: "",
	},
	{
		Before: " Đv Đào Tạo",
		After: "",
	},
	{
		Before: " giao thông vận tải tp HCM",
		After: "Đại Học Giao Thông Vận Tải TPHCM",
	},
	{
		Before: " Hcm Hutech",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: " Học",
		After: "",
	},
	{
		Before: " Học Kinh Tế Huế",
		After: "Đại Học Kinh Tế - ĐH Huế",
	},
	{
		Before: " Học Trung Tâm Tin Học Đhqg Thành Phố Hcm",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: " Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: " Học viện báo trí và tuyên truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: " Học Viện Chính Sách Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: " Học Viện Chính Sách và Phát Triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: " Học Viện Công Nghệ Bưu Chính Viễn",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: " Học Viện Công Nghệ Bưu Chính Viễn Thông",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: " Học viện công nghệ thông tin NIIT",
		After: "",
	},
	{
		Before: " Học Viện Đào Tạo Doanh Nhân Pti",
		After: "",
	},
	{
		Before: " Học Viện Hành Chính",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: " Học Viện Hành Chính Quốc Gia Tại Tp Hồ Chí Minh",
		After: "Học Viện Hành Chính Quốc Gia",
	},
	{
		Before: " Học viện kỹ thuật mật mã",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: " Học Viện Kỹ Thuật Quân Sự",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: " Học VIỆN NGÂN HÀNG",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: " Học viện nông nghiệp việt nam",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: " Học Viện Phụ Nữ Việt Nam",
		After: "Học Viện Phụ Nữ Việt Nam",
	},
	{
		Before: " Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: " Kinh Doanh Toulouse",
		After: "Kinh Doanh Toulouse, Pháp",
	},
	{
		Before: " Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: " Kinh Doanh- Đại Học Ueh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Kinh Tế Kĩ Thuật Công Nghiệp CNTT",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Kinh Tế Tp Hồ Chí Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: " Kinh Tế-  Đại Học Vinh",
		After: "Đại Học Vinh",
	},
	{
		Before: " LÀNG",
		After: "",
	},
	{
		Before: " Mầm Non Quốc Tế Wonderkids",
		After: "",
	},
	{
		Before: " Nhật Ngữ JLA",
		After: "",
	},
	{
		Before: " nơi đào tạo",
		After: "",
	},
	{
		Before: " Nơi Đào Tạo Bách Khoa Đà Nẵng",
		After: "Đại Học Bách Khoa - ĐH Đà Nẵng",
	},
	{
		Before: " nơi đào tạo cao đẵng kinh tế kỹ thuật",
		After: "Cao Đẳng Kinh Tế Kỹ Thuật Trung Ương",
	},
	{
		Before: " nơi đào tạo Cư nhân Quản trị Kinh doanh",
		After: "",
	},
	{
		Before: " nơi đào tạo đa",
		After: "",
	},
	{
		Before: " nơi đào tạo đh giao thông vận tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: " Nơi Đào Tạo Đh Kinh Tế Kỹ Thuật Công",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: " Nơi Đào Tạo Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: " nơi đào tạo Học viện chính sách và phát triển",
		After: "Học Viện Chính Sách Và Phát Triển",
	},
	{
		Before: " Nơi Đào Tạo Học Viện Công Nghệ Bưu",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: " Nơi Đào Tạo Học Viện Ngân Hàng",
		After: "Học Viện Ngân Hàng",
	},
	{
		Before: " Nơi Đào Tạo Học Viện Tài Chính",
		After: "Học Viện Tài Chính",
	},
	{
		Before: " Nơi Đào Tạo  Đh Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: " Nơi Đào Tạo-Đại Học Kinh Tế Kỹ Thuật Công Nghiệp",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "Trưởng Phòng Truyền Thông Công Ty Đầu Tư Phát Triển Máy Việt Nam",
		After: "",
	},
	{
		Before: " Ptth A Hải Hậu",
		After: "",
	},
	{
		Before: " Quản Trị Và Kinh Doanh- Đại Học Quốc Gia Hà Nội",
		After: "Quản Trị Và Kinh Doanh - ĐH QGHN",
	},
	{
		Before: " Quốc Tế - Đại Học Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Quốc Tế Đhqghn",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Quốc Tế Shelton",
		After: "Cao Đẳng Quốc Tế Shelton, Singapore",
	},
	{
		Before: " Quốc Tế VNU-IS ĐHQG Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Quốc Tế- Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Quốc Tế-Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: " Softech Arena Multimedia",
		After: "",
	},
	{
		Before: " THCS Phường",
		After: "",
	},
	{
		Before: " Thcs Tân Thành",
		After: "",
	},
	{
		Before: " Thcs Thanh Hải",
		After: "",
	},
	{
		Before: " Thpt",
		After: "",
	},
	{
		Before: " Thpt Chuyên Đại Học Sư Phạm",
		After: "",
	},
	{
		Before: " Thpt Chuyên Vĩnh Phúc",
		After: "",
	},
	{
		Before: " Thpt Đoàn Thị Điểm",
		After: "",
	},
	{
		Before: " Thpt Gia Viễn B",
		After: "",
	},
	{
		Before: " THPT Giao Thủy B",
		After: "",
	},
	{
		Before: " Thpt Huỳnh Thúc",
		After: "",
	},
	{
		Before: " THPT Lê Quý Đôn",
		After: "",
	},
	{
		Before: " Thpt Nghi Lộc",
		After: "",
	},
	{
		Before: " Thpt Phạm Hồng Thái Hà Nội",
		After: "",
	},
	{
		Before: " Thpt Phan Chu Trinh",
		After: "",
	},
	{
		Before: " THPT Phan Thành",
		After: "",
	},
	{
		Before: " Thpt Phước Bửu",
		After: "",
	},
	{
		Before: " THPT SỐ",
		After: "",
	},
	{
		Before: " THPT THANH OAI B",
		After: "",
	},
	{
		Before: " THPT Trần Hưng Đạo",
		After: "",
	},
	{
		Before: " Tiểu Học Lê Quý Đôn",
		After: "",
	},
	{
		Before: " Trung Cấp",
		After: "",
	},
	{
		Before: " Trung Cấp Bách Khoa Sài Gòn",
		After: "Trung Cấp Bách Khoa Sài Gòn",
	},
	{
		Before: " TRUNG CẤP DU LỊCH VÀKHÁCH SẠN SAIGONTOURIS",
		After: "Trung Cấp Du Lịch Và Khách Sạn Saigontourist",
	},
	{
		Before: " Trung Cấp Giao Thông Vận Tải",
		After: "Trung Cấp Giao Thông Vận Tải Hà Nội",
	},
	{
		Before: " trung cấp hồng hà",
		After: "Trung Cấp Hồng Hà",
	},
	{
		Before: " Trung Cấp Kinh Tế Kỹ Thuật",
		After: "Trung Cấp Kinh Tế Kỹ Thuật",
	},
	{
		Before: " Trung Cấp Y Dược Vạn Hạnh",
		After: "Trung Cấp Y Dược Vạn Hạnh",
	},
	{
		Before: " Trung Học phổ thông Chuyên Lê Quý Đôn",
		After: "",
	},
	{
		Before: " Trung Học Phổ Thông Tiền",
		After: "",
	},
	{
		Before: "Trưởng  Đại Học Kinh",
		After: "",
	},
	{
		Before: "-Đại Học Khoa Học Tự Nhiên Đhqghn",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "-Nơi Đào Tạo Cao đẳng Du Lịch Hà Nội",
		After: "Cao Đẳng Du Lịch Hà Nội",
	},
	{
		Before: "-Nơi Đào Tạo Cao đẳng Kinh Tế Đối",
		After: "Cao Đẳng Kinh Tế Đối Ngoại",
	},
	{
		Before: "-Nơi Đào Tạo Cao đẳng Thương Mại",
		After: "Cao Đẳng Thương Mại",
	},
	{
		Before: "-Nơi Đào Tạo Cao đẳng Viễn Đông",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Điện Lực",
		After: "Đại Học Điện Lực",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Giao Thông Vận Tải",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Hoa Sen",
		After: "Đại Học Hoa Sen",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Khoa Học Xã Hội Và",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Thủy Lợi",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "-Nơi Đào Tạo Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Cần Thơ",
		After: "Đại Học Cần Thơ",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Công Nghệ Tphcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Công Nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Công Nghiệp Hà Nội",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Kinh Tế Quốc",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Lao Động Xã Hội",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Mỏ Địa Chất",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "-Nơi Đào Tạo  Đại Học Tài Nguyên Và Môi ",
		After: "Đại Học Tài Nguyên Và Môi  Hà Nội",
	},
	{
		Before: "-Nơi Đào Tạo-Đại Học Công Nghiệp Hà Nội Ngành Kế Toán",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: ": Phân hiệu  Đại Học Nội vụ Hà Nội tại TPHCM",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before: "/ nơi đào tạo: Đại Học Luật Hà Nội",
		After: "Đại Học Luật Hà Nội",
	},
	{
		Before: "/ nơi đào tạo: Đại Học Nguyễn Tất Thành",
		After: "Đại Học Nguyễn Tất Thành",
	},
	{
		Before: "/ nơi đào tạo:  Đại Học Công nghiệp",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "/ nơi đào tạo:  Đại Học Kinh tế Quốc dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "/ nơi đào tạo:  Đại Học Tài chính - Kế toán",
		After: "Đại Học Tài Chính - Kế Toán",
	},
	{
		Before: "/ nơi đào tạo:  ĐH Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "/ nơi đào tạo:  ĐH Duy Tân",
		After: "Đại Học Duy Tân",
	},
	{
		Before: "TTGDTX huyện vị thuỷ",
		After: "",
	},
	{
		Before: "Tuanvu2503Ndgmailcom",
		After: "",
	},
	{
		Before: "Tudangdogmailcom",
		After: "",
	},
	{
		Before: "tuyendung",
		After: "",
	},
	{
		Before:
			"Từ 04 2014 Đến Nay Làm Việc Tại Công Ty Tnhh Tiếng Vang Việt Nam Địa",
		After: "",
	},
	{
		Before: "Tư Duy Và Nghiệp Vụ Marketing  Markus Marketing School",
		After: "",
	},
	{
		Before: "tử tại Đại Học Thương Mại Hà Nội",
		After: "Đại Học Thương Mại",
	},
	{
		Before:
			"Từ Tháng 03 2021 Đến Nay Kế Toán Tại Công Ty Cổ Phần Blooming Forest",
		After: "",
	},
	{
		Before:
			"Từ Tháng 4-Tháng 10 2021 Tham Gia Khóa Đào Tạo Lập Trình Viên Aspnet Mvc Tại Hệ Thống Đào Tạo CNTT T3H Cơ Sở Hà Nội",
		After: "",
	},
	{
		Before: "Từ Tháng 8 2016 6 2018  Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before:
			"Từ Tháng 9 1999 Đến Tháng 10- 2003 Học Tại Đại Học Thương Mại Hà Nội",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Ubis University",
		After: "Đại Học Đổi Mới Kinh Doanh Và Bền Vững",
	},
	{
		Before: "Udemy",
		After: "",
	},
	{
		Before: "Ueb Vnu- University Economics",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Ueh College Of Business Ueh University",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "UEH university",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "UET",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "UET - Đại Học công nghệ",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "UHM GROUP UHM GROUP",
		After: "",
	},
	{
		Before: "Uinversity of Economics and Finance",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "Ulaw University Business Management",
		After: "",
	},
	{
		Before: "UNIVERSITY",
		After: "",
	},
	{
		Before: "University Academy Of Journalism And",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "University Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "University Amgorky",
		After: "Đại Học Angkor",
	},
	{
		Before: "University Australia",
		After: "",
	},
	{
		Before: "University Bedfordshire",
		After: "Đại Học Bedfordshire, Anh",
	},
	{
		Before: "University Canberra",
		After: "Đại Học Canberra",
	},
	{
		Before: "University Cincinnati",
		After: "Đại Học Cincincati, Mỹ",
	},
	{
		Before: "University College",
		After: "",
	},
	{
		Before: "University College Dublin - National University of Ireland",
		After: "Đại Học Dublin, Ireland",
	},
	{
		Before: "university college of foreign",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "university commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "University Company",
		After: "",
	},
	{
		Before: "university cox school of business",
		After: "Kinh Doanh Cox - Đại Học Southern Methodist, Texas",
	},
	{
		Before: "University De Toulon",
		After: "Đại Học Toulon",
	},
	{
		Before: "University Degree Of National Economics University",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "University Đại Học Kinh Tế",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "UNIVERSITY Đại Học NGOẠI THƯƠNG HÀ NỘI",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "university economic",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Economic And Business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Economic Of Ho Chi Minh City",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Economics",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "university economics and business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Economics And Finance",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "University Economics And Law",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University Education",
		After: "Đại Học Sư Phạm Hà Nội",
	},
	{
		Before: "University Faculty of Tourism",
		After: "",
	},
	{
		Before: "University Finance",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University finance marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Foreign",
		After: "Đại Học Ngoại Thương",
	},
	{
		Before: "University Gloucestershire",
		After: "Đại Học Gloucestershire",
	},
	{
		Before: "University Gothenburg",
		After: "Đại Học Gothenburg",
	},
	{
		Before: "University Greenwich",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "university ha noi",
		After: "Đại Học Hà Nội",
	},
	{
		Before:
			"University Hanoi Bachelor of Business Administration in Hospitality",
		After: "Đại Học Hà Nội",
	},
	{
		Before: "University Hcm",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "university hcmc",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "University Hertfordshire",
		After: "Đại Học Hertfordshire",
	},
	{
		Before: "University Ho Chi Minh",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "UNIVERSITY HO CHI MINH CITY",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "university in hanoi university of",
		After: "",
	},
	{
		Before: "university in russia",
		After: "",
	},
	{
		Before: "university in zlin czech republic",
		After: "Đại Học Tomas, Bata In Zlin",
	},
	{
		Before: "University Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "university international",
		After: "Đại Học Quốc tế - ĐHQG HN",
	},
	{
		Before: "University Languages",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "University Lincoln",
		After: "Đại Học Lincoln, Anh",
	},
	{
		Before: "university malaysia",
		After: "",
	},
	{
		Before: "University Medical",
		After: "Đại Học Dược Hà Nội",
	},
	{
		Before: "UNIVERSITY MELBOURNE AUSTRALIA",
		After: "Đại Học Melbourne",
	},
	{
		Before: "university national economics university",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "University National University Of Civil Engineering",
		After: "Đại Học Xây Dựng",
	},
	{
		Before: "UNIVERSITY NORTH VANCOUVER BC",
		After: "",
	},
	{
		Before: "University Northampton",
		After: "Đại Học Northampton",
	},
	{
		Before: "university oct",
		After: "",
	},
	{
		Before: "UNIVERSITY OF",
		After: "",
	},
	{
		Before: "university of america aliso viejo ca",
		After: "",
	},
	{
		Before: "University Of America Master Of Science",
		After: "Đại Học Hoa kỳ",
	},
	{
		Before: "UNIVERSITY OF ANTWERP ANTWERP BELGIUM",
		After: "Đại Học Antwerp, Đức",
	},
	{
		Before: "university of applied sciences erasmus exchange",
		After: "",
	},
	{
		Before: "University Of Architecture Hcm",
		After: "Đại Học Kiến Trúc TPHCM",
	},
	{
		Before: "University Of Auckland New Zealand Graduate School Of Management",
		After: "Đại Học Auckland",
	},
	{
		Before: "university of bedfordshire",
		After: "Đại Học Bedfordshire, Anh",
	},
	{
		Before: "University Of Bedfordshire Uk",
		After: "Đại Học Bedfordshire, Anh",
	},
	{
		Before: "University Of Birmingham",
		After: "Đại Học Birmingham, Anh",
	},
	{
		Before: "University Of Bonn",
		After: "Đại Học Bonn, Đức",
	},
	{
		Before: "University Of Business Economics",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "UNIVERSITY OF BUSSINESS AND ECONOMICS",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Of California Long Beach Usa The Study Program Is",
		After: "Đại Học Bang California, Hoa Kỳ",
	},
	{
		Before: "University of Chicago Booth School of Business Chicago IL",
		After: "Kinh Doanh Booth - Đại Học Chicago",
	},
	{
		Before: "University Of Colorado Boulder",
		After: "Đại Học Colorado Boulder, Boulder, Mỹ",
	},
	{
		Before: "University of Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "university of communications and transport",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of East Anglia",
		After: "Đại Học Đông Anglia",
	},
	{
		Before: "University Of East Anglia United Kingdom",
		After: "Đại Học Đông Anglia",
	},
	{
		Before: "University Of East London Khoa Quốc Tế Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc tế - ĐHQG HN",
	},
	{
		Before: "University Of Ecomomics",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "university of economic",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "UNIVERSITY OF ECONOMIC AND LAW",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University of Economic HCM",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economic Hcmc",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University of Economic Ho Chi Minh City",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "UNIVERSITY OF ECONOMICS & LAW",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University of Economics and Business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Of Economics And Business Vietnam Nation University",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Of Economics And Business Vietnam National University",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before:
			"University Of Economics And Business Vietnam National University ,",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Of Economics And Business Vnu",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "UNIVERSITY OF ECONOMICS AND HUMAN SCIENCE",
		After: "Đại Học Warsaw, Ba Lan",
	},
	{
		Before: "University Of Economics And Law",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University Of Economics And Law Major Business Administration",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University Of Economics And Law Vnu Hcmc",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University Of Economics And Laws",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "University Of Economics Finance",
		After: "Đại Học Kinh Tế - Tài Chính TPHCM",
	},
	{
		Before: "University Of Economics Hanoi National University",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "university of economics hcm city",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics Hcmc",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "university of economics hcmc Đại Học kinh tế tp hcm",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics Ho",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "university of economics ho chi",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics Ho Chi Minh",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "university of economics ho chi minh city",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before:
			"UNIVERSITY OF ECONOMICS HO CHI MINH CITY - UEH Major: Corporate Finance",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before:
			"University Of Economics Ho Chi Minh City Institute Of Development Economic",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before:
			"University Of Economics Ho Chi Minh City Master Of Business Administration",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics Ho Chi Minh City Sep",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University Of Economics Hochiminh City",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "University of Economics in July",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "University Of Economics Law",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "university of economics technology for industries",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "University Of Economics Technology For Industries Ha Noi",
		After: "Đại Học Kinh Tế - Kỹ Thuật Công Nghiệp",
	},
	{
		Before: "University Of Economics The University Of Danang",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "University Of Economics The University Of Danang Danang",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "University Of Economics University Of Danang",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "University of Education Information Technology Engineer",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "University Of Engineer And Technology Vietnam National University",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Engineering And",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Engineering And Technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Engineering And Technology - Vnu",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before:
			"University Of Engineering And Technology Vietnam National University",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before:
			"University Of Engineering And Technology Vietnam Nationaluniversity",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Engineering And Technology Vnu Cau Giay",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Exeter Exeter United Kingdom",
		After: "Đại Học Exeter",
	},
	{
		Before: "University Of Finance",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Finance And Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Finance And Marketing Major Hospitality Management",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Finance Business Administration",
		After: "Đại Học Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: "University Of Finance Business Administration Auditing",
		After: "Đại Học Tài Chính - Quản Trị Kinh Doanh",
	},
	{
		Before: "university of finance marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Finance Marketing District",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Finnance And Marketing",
		After: "Đại Học Tài Chính - Marketing",
	},
	{
		Before: "University Of Food Industry",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "University Of Food Industry Hcmc",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: "university of foreign language - Hue university",
		After: "Đại Học Ngoại Ngữ - ĐH Huế",
	},
	{
		Before: "University Of Greenwich",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "University of Greenwich",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "University Of Greenwich London",
		After: "Đại Học Greenwich London",
	},
	{
		Before: "University of Greenwich London UK",
		After: "Đại Học Greenwich London",
	},
	{
		Before: "University Of Greenwich Vietnam",
		After: "Đại Học Greenwich Việt Nam",
	},
	{
		Before: "University Of Hamburg",
		After: "Đại Học Hamburg",
	},
	{
		Before: "University Of Havana",
		After: "Đại Học La Habana",
	},
	{
		Before: "University of Ho Chi Minh City",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "University Of Hochiminh Education",
		After: "Đại Học Sư Phạm TPHCM",
	},
	{
		Before: "University of Home Affair",
		After: "Đại Học Nội Vụ Hà Nội",
	},
	{
		Before:
			"University of Huddersfield Huddersfield West Yorkshire England the UK",
		After: "Đại Học Huddersfield",
	},
	{
		Before: "University Of Huddersfield Uk",
		After: "Đại Học Huddersfield",
	},
	{
		Before: "University Of Huddersfield United Kingdom",
		After: "Đại Học Huddersfield",
	},
	{
		Before: "University Of Industry",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "University Of Infomation And Communication",
		After: "Đại Học Công Nghệ Thông Tin Và Truyền Thông - ĐH Thái Nguyên",
	},
	{
		Before: "University Of Information",
		After: "",
	},
	{
		Before: "University Of Information Technology Vnu Hcm",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "University Of Information Technology Vnuhcm",
		After: "Đại Học Công Nghệ Thông Tin - ĐHQG TPHCM",
	},
	{
		Before: "University Of Labour And Social Affairs",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before:
			"University Of Labour Social Affair Hanoi Vietnam Human Resources Management Gpa",
		After: "Đại Học Lao Động - Xã Hội",
	},
	{
		Before: "University of Languages and International Studies",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "University Of Languages And International Studies Major English",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "University Of Languages Vietnam National University",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "University Of Leeds Uk",
		After: "Đại Học Leeds, Anh",
	},
	{
		Before: "University of Leicester",
		After: "Đại Học Leicester, Anh",
	},
	{
		Before: "University Of Messina",
		After: "Đại Học Messina, Ý",
	},
	{
		Before: "University of Mining and",
		After: "Đại Học Mỏ - Địa Chất",
	},
	{
		Before: "University Of Montpellier I France",
		After: "Đại Học Montpellier, Pháp",
	},
	{
		Before: "University Of Natural Sciences",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "University Of Natural Sciences Vnu Hcmc",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "University Of Nebraska Lincoln",
		After: "Đại Học Nebraska - Lincoln",
	},
	{
		Before: "University of Nice Sophia",
		After: "Đại Học Nice Sophia Antipolis",
	},
	{
		Before: "University Of Paris Sorbonne Iae De Paris",
		After: "Đại Học Paris 1 Pantheon-Sorbonne",
	},
	{
		Before: "University Of Portsmouth",
		After: "Đaị Học Portsmouth, Singapore",
	},
	{
		Before: "University of Science",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Science And Technology Of Hanoi",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "University Of Science Hanoi",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "University Of Science Ho Chi Minh City",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "University of Social Sciences and Humanities in Ho Chi Minh city",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "university of social sciences and humanities vietnam national",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "University Of Social Sciences And Humanity ,",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before:
			"UNIVERSITY OF SOCIALSCIENCES AND HUMANITIES -VIETNAM NATIONALUNIVERSITY HO CHI MINH CITY",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐHQG TPHCM",
	},
	{
		Before: "University Of South Australia",
		After: "Đại Học Nam Úc",
	},
	{
		Before: "University Of South Florida Tampa Fl",
		After: "Đại Học Nam Florida",
	},
	{
		Before: "University Of Southampton",
		After: "Đại Học Southampton",
	},
	{
		Before: "University Of Southampton ,",
		After: "Đại Học Southampton",
	},
	{
		Before: "University Of Southern Queensland",
		After: "Đại Học Queensland",
	},
	{
		Before: "university of stirling scotland",
		After: "Đại Học Stirling, Scotland",
	},
	{
		Before: "University of Suderland",
		After: "Đại Học Sunderland",
	},
	{
		Before: "University Of Sunderland",
		After: "Đại Học Sunderland",
	},
	{
		Before: "University Of Sunderland Banking Academy",
		After: "Đại Học Sunderland",
	},
	{
		Before: "University Of Sunderland United Kingdom",
		After: "Đại Học Sunderland",
	},
	{
		Before: "University of Sydney Australia",
		After: "Đại Học Sydney",
	},
	{
		Before: "University Of Tasmania",
		After: "Đại Học Tasmania",
	},
	{
		Before: "university of technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Technology And Education",
		After: "Đại Học Sư Phạm Kỹ Thuật Hưng Yên",
	},
	{
		Before:
			"University Of Technology And Engineering Vietnam National University Hanoi",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "University Of Technology Hcm",
		After: "Đại Học Công Nghệ TPHCM",
	},
	{
		Before: "University Of The Incarnate Word",
		After: "Đại Học Incarnate Word, Texas",
	},
	{
		Before: "University Of The People",
		After: "Đại Học The People",
	},
	{
		Before: "University of the West of England",
		After: "Đại Học Tây Anh Bristol",
	},
	{
		Before: "University Of The West Of Scotland",
		After: "Đại Học Tây Scotland",
	},
	{
		Before: "University Of Transport And Communication",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of Transport And Communications",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of Transport And Communications Major",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of Transport Andcommunications Major Information",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "UNIVERSITY OF TRANSPORT TECHNOLOGY",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of Transport Technology Major Information Technology",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Of Trento Italy",
		After: "Đại Học Trento",
	},
	{
		Before: "University Of Ulsan Ulsan Korea",
		After: "Đại Học Ulsan. Hàn",
	},
	{
		Before: "University of Varese Italy",
		After: "Đại Học Varese, Ý",
	},
	{
		Before: "University Of Wales",
		After: "Đại Học Wales",
	},
	{
		Before:
			"University Of Wales Trinity Saint David Swansea The United Kingdom",
		After: "Đại Học Wales Trinity Saint David, Anh",
	},
	{
		Before: "University Of Westminster London London Masters Degree",
		After: "Đại Học Westminster, London, Anh",
	},
	{
		Before: "UNIVERSITY OF WOLLONGONG",
		After: "Đại Học Wollongong, Úc",
	},
	{
		Before: "University Open University HCMC",
		After: "Đại Học Mở TPHCM",
	},
	{
		Before: "University Pavia",
		After: "Đại Học Pavia",
	},
	{
		Before: "University Portsmouth campus in Singapore",
		After: "Đaị Học Portsmouth, Singapore",
	},
	{
		Before: "university posts and telecommunications",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "University Salford",
		After: "Đại Học Salford, Anh",
	},
	{
		Before: "UNIVERSITY San Francisco CA USA",
		After: "Đại Học San Francisco, California",
	},
	{
		Before: "University Scholarship For Excellent Students",
		After: "",
	},
	{
		Before: "University School FPT Polytechnic Hanoi",
		After: "Đại Học FPT",
	},
	{
		Before: "University Science and Technology",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "University Social",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "University Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "University Software Engineering",
		After: "",
	},
	{
		Before:
			"University such as Vietnam National University National Economics University Vietnam",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "university surrey",
		After: "",
	},
	{
		Before: "university technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "university the united",
		After: "",
	},
	{
		Before: "University Thuong Mai University",
		After: "Đại Học Thương Mại",
	},
	{
		Before:
			"University Training Center Hanoi University Of Industry Major Software Engineering",
		After: "Đại Học Công Nghiệp Hà Nội",
	},
	{
		Before: "University Training Center Military Technical Academy",
		After: "Học Viện Kỹ Thuật Quân Sự",
	},
	{
		Before: "University Training Center Vietbac University",
		After: "Đại Học Việt Bắc",
	},
	{
		Before: "University Transport and Communication",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Transport And Communications",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "University Transport And Comunication",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "university viet nam",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "University Vietnam",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "University Vietnam National University Ho Chi Minh City",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before: "University Warsaw",
		After: "Đại Học Warsaw, Ba Lan",
	},
	{
		Before: "University Wellington",
		After: "Đại Học Victoria Wellington",
	},
	{
		Before: "University West Of England",
		After: "Đại Học Tây Anh Bristol",
	},
	{
		Before: "University Wisconsin",
		After: "Đại Học Wisconsin—Madison",
	},
	{
		Before: "Usol Vietnam",
		After: "",
	},
	{
		Before: "USTH - Dai Hoc Viet Phap Hanoi",
		After: "Đại Học Khoa Học Và Công Nghệ Hà Nội",
	},
	{
		Before: "Utc",
		After: "Đại Học Giao Thông Vận Tải",
	},
	{
		Before: "Ute- University Of Technology And Education",
		After: "Đại Học Sư Phạm Kỹ Thuật - ĐH Đà Nẵng",
	},
	{
		Before: "UTT",
		After: "Đại Học Công Nghệ Giao Thông Vận Tải",
	},
	{
		Before: "Uvbch-Đoàn Khoa Tài Chính Công",
		After: "",
	},
	{
		Before: "Ủy Ban Chứng Khoán",
		After: "",
	},
	{
		Before: "Ủy Ban Chứng Khoán Nhà Nước",
		After: "",
	},
	{
		Before: "ỨNG Tbiem Thung binh 3.2644",
		After: "",
	},
	{
		Before: "Van Hien University",
		After: "Đại Học Văn Hiến",
	},
	{
		Before: "Van lang",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Van Lang University",
		After: "Đại Học Văn Lang",
	},
	{
		Before: "Vanto Group",
		After: "",
	},
	{
		Before: "Văn - Đại Học Quốc Gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Văn Hóa Truyền Thông | Đại Học Văn Hóa Hà Nội",
		After: "Đại Học Văn Hóa Hà Nội",
	},
	{
		Before:
			"Văn Học Và Ngôn Ngữ--09 2009- 09 2013 Đại Học Khoa Học Xã Hội Và Nhân Văn",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Văn Phòng Công Chứng Số",
		After: "",
	},
	{
		Before: "Vccorpvccorp",
		After: "",
	},
	{
		Before: "VENTURE OF VIETNAM COMMERCIAL BANK AND",
		After: "",
	},
	{
		Before: "Vi Etnam-Nati Onal- Uni Versi Ty",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Vị Trí Trưởng Bộ Phận Nội Dung",
		After: "",
	},
	{
		Before: "Vice President Of Communication-Young Economists Club Yec",
		After: "",
	},
	{
		Before: "Victoria University Of Melbourne Footscray Campus",
		After: "Đại Học Victoria",
	},
	{
		Before: "Vien Dong College",
		After: "Cao Đẳng Viễn Đông",
	},
	{
		Before: "Viet Corner Store Pty Ltd Australia",
		After: "",
	},
	{
		Before: "Viet Nam University Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Viet Nam University Of Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Viet Tri University Of Industry Engineer",
		After: "Đại Học Công Nghiệp Việt Trì",
	},
	{
		Before: "Viet-Hung Industrial University Tester Ha Noi June",
		After: "Đại Học Công Nghiệp Việt-Hung",
	},
	{
		Before: "Vietbee Trading And Services Jsc",
		After: "",
	},
	{
		Before: "Vietinbank",
		After: "",
	},
	{
		Before: "Vietnam",
		After: "",
	},
	{
		Before: "Vietnam Academy Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Vietnam Academy Of Cryptography Techniques",
		After: "Học Viện Kỹ Thuật Mật Mã",
	},
	{
		Before: "Vietnam Aviation Academy",
		After: "Học Viện Hậu Cần",
	},
	{
		Before:
			"Vietnam Aviation Academy Technology Electronic Engineering Telecommunications",
		After: "Học Viện Hàng Không Việt Nam",
	},
	{
		Before: "Vietnam Aviation Academy University",
		After: "Học Viện Hậu Cần",
	},
	{
		Before: "Vietnam Commercial University",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Vietnam Logistics And Aviation School",
		After: "Học Viện Hậu Cần",
	},
	{
		Before: "Vietnam Maritime University",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Vietnam Maritime University | MAR 2016-DEC 2020",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Vietnam Maritime University, Hai Phong",
		After: "Đại Học Hàng Hải Việt Nam",
	},
	{
		Before: "Vietnam National University Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Vietnam National University Hanoi",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Vietnam National University HCMC International University",
		After: "Đại Học Quốc Tế - ĐHQG TPHCM",
	},
	{
		Before:
			"Vietnam National University Hcmc Kế Toán Và Báo Cáo Thuế Doanh Nghiệp",
		After: "Đại Học Quốc Gia TPHCM",
	},
	{
		Before:
			"Vietnam National University Ho Chi Minh City University Of Economics And Law",
		After: "Đại Học Kinh Tế - Luật - ĐHQG TPHCM",
	},
	{
		Before: "Vietnam National University International School",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Vietnam National University Keuka College",
		After: "Cao Đẳng Keuka",
	},
	{
		Before: "Vietnam National University Of",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Vietnam National University Of Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Vietnam National University University Of Economics And Business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Vietnam National University University Of Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Vietnam National-University Of Economics And Business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "vietnam trade union university",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Vietnam Trade Unions University",
		After: "Đại Học Công Đoàn",
	},
	{
		Before: "Vietnam Training Center",
		After: "",
	},
	{
		Before: "Vietnam University Of Agriculture",
		After: "Học Viện Nông Nghiệp Việt Nam",
	},
	{
		Before: "Vietnam University Of Commerce",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Vietnam University Of Commerce Hanoi",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Vietnam Youth Academy",
		After: "Học Viện Thanh Thiếu Niên Việt Nam",
	},
	{
		Before:
			"Vietnam-National-University University For Foreign Languages And International Studies",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before: "Vietnamese- German University",
		After: "Đại Học Việt Đức",
	},
	{
		Before: "Vietnammarcom",
		After: "",
	},
	{
		Before: "Vietpro Academy",
		After: "",
	},
	{
		Before: "Viettri University",
		After: "Đại Học Công Nghiệp Việt Trì",
	},
	{
		Before: "Viện Báo Chí & Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: "Viện Công Nghệ Thông Tin",
		After: "",
	},
	{
		Before: "Viện Công nghệ thông tin - Đại Học Quốc gia Hà Nội",
		After: "Đại Học Quốc Gia Hà Nội",
	},
	{
		Before: "Viện Đại Học Mở",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "viện Đại Học mở hà nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Viện Đại Học Mở Hà Nội , Tài Chính Ngân",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Viện Đại Học Mở Hà Nội Cao Học",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Viện Đào tạo Quốc tế FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Viện Đào Tạo Quốc Tế- Đại Học Thương Mại",
		After: "Đại Học Thương Mại",
	},
	{
		Before: "Viện ĐH Mở Hà Nội",
		After: "Đại Học Mở Hà Nội",
	},
	{
		Before: "Viện Hợp Tác Quốc Tế  Đại Học",
		After: "",
	},
	{
		Before: "Viện ISB- Đại Học Kinh tế TPHCM (UEH)",
		After: "Đại Học Kinh Tế TPHCM",
	},
	{
		Before: "Viện Kế toán Kiểm toán",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Viện Kế Toán- Kiểm Toán Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "Viện Kinh Tế Và Quản Lý - Đại Học Bách Khoa Hà Nội",
		After: "Đại Học Bách Khoa Hà Nội",
	},
	{
		Before: "Viện Nghiên Cứu Đông Nam Á",
		After: "",
	},
	{
		Before: "Viện Quản Trị Công Nghệ Fsb",
		After: "Đại Học FPT",
	},
	{
		Before: "Viện Quản Trị-Công Nghệ Fsb-Đại Học FPT",
		After: "Đại Học FPT",
	},
	{
		Before: "Viện Thủy Công",
		After: "",
	},
	{
		Before: "Viện Tòa Án",
		After: "Học Viện Tòa Án",
	},
	{
		Before: "Viện Viễn Thông Chuyên Ngành Kỹ Sư Kỹ Thuật Máy Tính",
		After: "Học Viện Công Nghệ Bưu Chính Viễn Thông",
	},
	{
		Before: "Viện Việt - Anh, Đại Học Đà Nẵng",
		After: "Đại Học Đà Nẵng",
	},
	{
		Before: "VII  DỰ ÁN TẠI FPT SOFTWARE",
		After: "",
	},
	{
		Before: "Villanova University Villanova Pennsylvania",
		After: "",
	},
	{
		Before: "Vinalink Academy",
		After: "",
	},
	{
		Before: "Vinalink Media",
		After: "",
	},
	{
		Before: "Vinatex College Of Economics And Technology",
		After: "Cao Đẳng Nghề Kinh Tế Kỹ Thuật Vinatex",
	},
	{
		Before: "Vinh University",
		After: "Đại Học Vinh",
	},
	{
		Before: "Viva Excon Curatorial And Art Management Workshop",
		After: "",
	},
	{
		Before: "Vkist Nacentech Joint Laboratory",
		After: "",
	},
	{
		Before: "Vnu University Economics And Business",
		After: "Đại Học Kinh Tế - ĐH QGHN",
	},
	{
		Before: "Vnu University Engineering And Technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Vnu University Of Engineering And Technology",
		After: "Đại Học Công Nghệ - ĐH QGHN",
	},
	{
		Before: "Vnu University Of Languages And International Studies",
		After: "Đại Học Ngoại Ngữ - ĐH QGHN",
	},
	{
		Before:
			"Vnu University Of Science Specialized Computer And Information Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Vnu University Of Sciences",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Vnu University Of Social Sciences And Humanities",
		After: "Đại Học Khoa Học Xã Hội Và Nhân Văn - ĐH QGHN",
	},
	{
		Before: "Vnu University Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐH QGHN",
	},
	{
		Before: "Vnuhcm- University Of Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "Vnuhcm- University Science",
		After: "Đại Học Khoa Học Tự Nhiên - ĐHQG TPHCM",
	},
	{
		Before: "VNware Education",
		After: "",
	},
	{
		Before: "Volgograd State University",
		After: "Đại Học Tổng Hợp Kỹ Thuật Quốc Gia Volgograd",
	},
	{
		Before: "VTC ACADEMY",
		After: "",
	},
	{
		Before: "Vti Academy",
		After: "",
	},
	{
		Before: "Vti Academy Java Fullstack Course",
		After: "",
	},
	{
		Before: "VŨ MINH HOÀNG",
		After: "",
	},
	{
		Before: "VŨ THỊ NHẬT LỆ",
		After: "",
	},
	{
		Before: "Vungoctu231294Gmailcom",
		After: "",
	},
	{
		Before: "Vương Khải Hoàn",
		After: "",
	},
	{
		Before: "Vviện Kế Toán Kiểm Toán-Đại Học Kinh Tế Quốc Dân",
		After: "Đại Học Kinh Tế Quốc Dân",
	},
	{
		Before: "VWA",
		After: "",
	},
	{
		Before: "Washington State UniversityPullman, United States",
		After: "Đại Học Bang Washington",
	},
	{
		Before: "water resource university",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Water Resources University",
		After: "Đại Học Thủy Lợi",
	},
	{
		Before: "Western University Ivey Business School",
		After: "Đại Học Western",
	},
	{
		Before: "With Students From The Foreign Trade And Rmit University",
		After: "Đại Học RMIT",
	},
	{
		Before: "World Tesol Academy",
		After: "",
	},
	{
		Before: "Worldinternetacademycom",
		After: "",
	},
	{
		Before: "Xã Hội Học",
		After: "",
	},
	{
		Before:
			"Young Leaders Program 2021, 13Th South China Sea International Conference",
		After: "",
	},
	{
		Before: "Zero To Mastery Academy",
		After: "",
	},
	{
		Before: "新日本学院 New Japan Academy",
		After: "",
	},
	{
		Before: " University Sunderland",
		After: "Đại Học Sunderland",
	},
	{
		Before: " Học Viện Báo Chí Và Tuyên Truyền",
		After: "Học Viện Báo Chí Và Tuyên Truyền",
	},
	{
		Before: " Đại Học Công Nghiệp Thực Phẩm Tp Hcm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
	{
		Before: " Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
		After: "Đại Học Kinh Doanh Và Công Nghệ Hà Nội",
	},
	{
		Before: "  Đại Học Công Nghiệp Thực Phẩm",
		After: "Đại Học Công Nghiệp Thực Phẩm TPHCM",
	},
];

function GenSQLCommand(input) {
	let deleteItems = [];
	let changeItems = [];

	input.forEach((item) => {
		if (item.After == "Xóa" || !item.After) deleteItems.push(item.Before);
		else if (item.After != "#N/A") {
            changeItems.push(item);
        };
	});

	let insertCommand = "INSERT INTO education_place_map (EducationPlaceName, EducationPlaceMapName, IsDeleted) VALUES ";

	deleteItems.forEach((item) => {
		insertCommand += ` ('${item}', '', TRUE), `;
	})

	changeItems.forEach((item) => {
		insertCommand += ` ('${item.Before}', '${item.After}', FALSE), `;
	})

    return insertCommand;
}

console.log(GenSQLCommand(input));
