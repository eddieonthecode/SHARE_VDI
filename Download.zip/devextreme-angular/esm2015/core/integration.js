/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
import { NgModule, Inject, NgZone, Optional, VERSION } from '@angular/core';
import { XhrFactory } from '@angular/common/http';
import * as httpRequest from 'devextreme/core/http_request';
import { DOCUMENT } from '@angular/common';
import * as domAdapter from 'devextreme/core/dom_adapter';
import * as readyCallbacks from 'devextreme/core/utils/ready_callbacks';
import * as eventsEngine from 'devextreme/events/core/events_engine';
const outsideZoneEvents = ['mousemove', 'mouseover', 'mouseout'];
const insideZoneEvents = ['mouseup', 'click', 'mousedown', 'transitionend', 'wheel'];
let originalAdd;
let readyCallbackAdd = function (callback) {
    if (!originalAdd) {
        originalAdd = this.callBase.bind(this);
    }
    callbacks.push(callback);
};
const ɵ0 = readyCallbackAdd;
let callbacks = [];
readyCallbacks.inject({
    add: function (callback) {
        return readyCallbackAdd.call(this, callback);
    }
});
let doInjections = (document, ngZone, xhrFactory) => {
    if (Number(VERSION.major) < 7) {
        console.warn('Your version of Angular is not supported (https://supportcenter.devexpress.com/ticket/details/t879496). Please update your project to version 7 or later. Please refer to the Angular Update Guide for more information: https://update.angular.io');
    }
    domAdapter.inject({
        _document: document,
        listen: function (...args) {
            const eventName = args[1];
            if (outsideZoneEvents.indexOf(eventName) !== -1) {
                return ngZone.runOutsideAngular(() => {
                    return this.callBase.apply(this, args);
                });
            }
            if (ngZone.isStable && insideZoneEvents.indexOf(eventName) !== -1) {
                return ngZone.run(() => {
                    return this.callBase.apply(this, args);
                });
            }
            return this.callBase.apply(this, args);
        },
        isElementNode: function (element) {
            return element && element.nodeType === 1;
        },
        isTextNode: function (element) {
            return element && element.nodeType === 3;
        },
        isDocument: function (element) {
            return element && element.nodeType === 9;
        }
    });
    httpRequest.inject({
        getXhr: function () {
            if (!xhrFactory) {
                return this.callBase.apply(this);
            }
            let _xhr = xhrFactory.build();
            if (!('withCredentials' in _xhr)) {
                _xhr['withCredentials'] = false;
            }
            return _xhr;
        }
    });
    const runReadyCallbacksInZone = () => {
        ngZone.run(() => {
            eventsEngine.set({});
            callbacks.forEach(callback => originalAdd.call(null, callback));
            callbacks = [];
            readyCallbacks.fire();
        });
    };
    runReadyCallbacksInZone();
    readyCallbackAdd = (callback) => ngZone.run(() => callback());
    doInjections = runReadyCallbacksInZone;
};
const ɵ1 = doInjections;
let DxIntegrationModule = class DxIntegrationModule {
    constructor(document, ngZone, xhrFactory) {
        doInjections(document, ngZone, xhrFactory);
    }
};
DxIntegrationModule.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] },
    { type: NgZone },
    { type: XhrFactory, decorators: [{ type: Optional }] }
];
DxIntegrationModule = tslib_1.__decorate([
    NgModule({}),
    tslib_1.__param(0, Inject(DOCUMENT)), tslib_1.__param(2, Optional()),
    tslib_1.__metadata("design:paramtypes", [Object, NgZone, XhrFactory])
], DxIntegrationModule);
export { DxIntegrationModule };
export { ɵ0, ɵ1 };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZWdyYXRpb24uanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvY29yZS8iLCJzb3VyY2VzIjpbImludGVncmF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHOztBQUdILE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzVFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssV0FBVyxNQUFNLDhCQUE4QixDQUFDO0FBQzVELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUUzQyxPQUFPLEtBQUssVUFBVSxNQUFNLDZCQUE2QixDQUFDO0FBQzFELE9BQU8sS0FBSyxjQUFjLE1BQU0sdUNBQXVDLENBQUM7QUFDeEUsT0FBTyxLQUFLLFlBQVksTUFBTSxzQ0FBc0MsQ0FBQztBQUVyRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNqRSxNQUFNLGdCQUFnQixHQUFHLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBRXJGLElBQUksV0FBVyxDQUFDO0FBQ2hCLElBQUksZ0JBQWdCLEdBQUcsVUFBUyxRQUFRO0lBQ3BDLElBQUksQ0FBQyxXQUFXLEVBQUU7UUFDZCxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDMUM7SUFDRCxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQzs7QUFFRixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7QUFDbkIsY0FBYyxDQUFDLE1BQU0sQ0FBQztJQUNsQixHQUFHLEVBQUUsVUFBUyxRQUFRO1FBQ2xCLE9BQU8sZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztJQUNqRCxDQUFDO0NBQ0osQ0FBQyxDQUFDO0FBRUgsSUFBSSxZQUFZLEdBQUcsQ0FBQyxRQUFhLEVBQUUsTUFBYyxFQUFFLFVBQXNCLEVBQUUsRUFBRTtJQUN6RSxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzNCLE9BQU8sQ0FBQyxJQUFJLENBQUMsb1BBQW9QLENBQUMsQ0FBQztLQUN0UTtJQUVELFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDZCxTQUFTLEVBQUUsUUFBUTtRQUVuQixNQUFNLEVBQUUsVUFBUyxHQUFHLElBQUk7WUFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLElBQUksaUJBQWlCLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUM3QyxPQUFPLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUU7b0JBQ2pDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzQyxDQUFDLENBQUMsQ0FBQzthQUNOO1lBRUQsSUFBSSxNQUFNLENBQUMsUUFBUSxJQUFJLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDL0QsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRTtvQkFDbkIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNDLENBQUMsQ0FBQyxDQUFDO2FBQ047WUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzQyxDQUFDO1FBRUQsYUFBYSxFQUFFLFVBQVMsT0FBTztZQUMzQixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQztRQUM3QyxDQUFDO1FBRUQsVUFBVSxFQUFFLFVBQVMsT0FBTztZQUN4QixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQztRQUM3QyxDQUFDO1FBRUQsVUFBVSxFQUFFLFVBQVMsT0FBTztZQUN4QixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQztRQUM3QyxDQUFDO0tBQ0osQ0FBQyxDQUFDO0lBRUgsV0FBVyxDQUFDLE1BQU0sQ0FBQztRQUNmLE1BQU0sRUFBRTtZQUNKLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ2IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNwQztZQUNELElBQUksSUFBSSxHQUFHLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsRUFBRTtnQkFDN0IsSUFBWSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQzVDO1lBRUQsT0FBTyxJQUFJLENBQUM7UUFDaEIsQ0FBQztLQUNKLENBQUMsQ0FBQztJQUVILE1BQU0sdUJBQXVCLEdBQUcsR0FBRyxFQUFFO1FBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFO1lBQ1osWUFBWSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyQixTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNoRSxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBQ2YsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDO0lBRUYsdUJBQXVCLEVBQUUsQ0FBQztJQUUxQixnQkFBZ0IsR0FBRyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQzlELFlBQVksR0FBRyx1QkFBdUIsQ0FBQztBQUMzQyxDQUFDLENBQUM7O0FBR0YsSUFBYSxtQkFBbUIsR0FBaEMsTUFBYSxtQkFBbUI7SUFDNUIsWUFBOEIsUUFBYSxFQUFFLE1BQWMsRUFBYyxVQUFzQjtRQUMzRixZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO0NBQ0osQ0FBQTs7NENBSGdCLE1BQU0sU0FBQyxRQUFRO1lBQXlCLE1BQU07WUFBMEIsVUFBVSx1QkFBakMsUUFBUTs7QUFEN0QsbUJBQW1CO0lBRC9CLFFBQVEsQ0FBQyxFQUFFLENBQUM7SUFFSSxtQkFBQSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUEsRUFBaUMsbUJBQUEsUUFBUSxFQUFFLENBQUE7cURBQW5CLE1BQU0sRUFBMEIsVUFBVTtHQUR0RixtQkFBbUIsQ0FJL0I7U0FKWSxtQkFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cblxuaW1wb3J0IHsgTmdNb2R1bGUsIEluamVjdCwgTmdab25lLCBPcHRpb25hbCwgVkVSU0lPTiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgWGhyRmFjdG9yeSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCAqIGFzIGh0dHBSZXF1ZXN0IGZyb20gJ2RldmV4dHJlbWUvY29yZS9odHRwX3JlcXVlc3QnO1xuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5pbXBvcnQgKiBhcyBkb21BZGFwdGVyIGZyb20gJ2RldmV4dHJlbWUvY29yZS9kb21fYWRhcHRlcic7XG5pbXBvcnQgKiBhcyByZWFkeUNhbGxiYWNrcyBmcm9tICdkZXZleHRyZW1lL2NvcmUvdXRpbHMvcmVhZHlfY2FsbGJhY2tzJztcbmltcG9ydCAqIGFzIGV2ZW50c0VuZ2luZSBmcm9tICdkZXZleHRyZW1lL2V2ZW50cy9jb3JlL2V2ZW50c19lbmdpbmUnO1xuXG5jb25zdCBvdXRzaWRlWm9uZUV2ZW50cyA9IFsnbW91c2Vtb3ZlJywgJ21vdXNlb3ZlcicsICdtb3VzZW91dCddO1xuY29uc3QgaW5zaWRlWm9uZUV2ZW50cyA9IFsnbW91c2V1cCcsICdjbGljaycsICdtb3VzZWRvd24nLCAndHJhbnNpdGlvbmVuZCcsICd3aGVlbCddO1xuXG5sZXQgb3JpZ2luYWxBZGQ7XG5sZXQgcmVhZHlDYWxsYmFja0FkZCA9IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG4gICAgaWYgKCFvcmlnaW5hbEFkZCkge1xuICAgICAgICBvcmlnaW5hbEFkZCA9IHRoaXMuY2FsbEJhc2UuYmluZCh0aGlzKTtcbiAgICB9XG4gICAgY2FsbGJhY2tzLnB1c2goY2FsbGJhY2spO1xufTtcblxubGV0IGNhbGxiYWNrcyA9IFtdO1xucmVhZHlDYWxsYmFja3MuaW5qZWN0KHtcbiAgICBhZGQ6IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG4gICAgICAgIHJldHVybiByZWFkeUNhbGxiYWNrQWRkLmNhbGwodGhpcywgY2FsbGJhY2spO1xuICAgIH1cbn0pO1xuXG5sZXQgZG9JbmplY3Rpb25zID0gKGRvY3VtZW50OiBhbnksIG5nWm9uZTogTmdab25lLCB4aHJGYWN0b3J5OiBYaHJGYWN0b3J5KSA9PiB7XG4gICAgaWYgKE51bWJlcihWRVJTSU9OLm1ham9yKSA8IDcpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdZb3VyIHZlcnNpb24gb2YgQW5ndWxhciBpcyBub3Qgc3VwcG9ydGVkIChodHRwczovL3N1cHBvcnRjZW50ZXIuZGV2ZXhwcmVzcy5jb20vdGlja2V0L2RldGFpbHMvdDg3OTQ5NikuIFBsZWFzZSB1cGRhdGUgeW91ciBwcm9qZWN0IHRvIHZlcnNpb24gNyBvciBsYXRlci4gUGxlYXNlIHJlZmVyIHRvIHRoZSBBbmd1bGFyIFVwZGF0ZSBHdWlkZSBmb3IgbW9yZSBpbmZvcm1hdGlvbjogaHR0cHM6Ly91cGRhdGUuYW5ndWxhci5pbycpO1xuICAgIH1cblxuICAgIGRvbUFkYXB0ZXIuaW5qZWN0KHtcbiAgICAgICAgX2RvY3VtZW50OiBkb2N1bWVudCxcblxuICAgICAgICBsaXN0ZW46IGZ1bmN0aW9uKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50TmFtZSA9IGFyZ3NbMV07XG4gICAgICAgICAgICBpZiAob3V0c2lkZVpvbmVFdmVudHMuaW5kZXhPZihldmVudE5hbWUpICE9PSAtMSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZ1pvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jYWxsQmFzZS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG5nWm9uZS5pc1N0YWJsZSAmJiBpbnNpZGVab25lRXZlbnRzLmluZGV4T2YoZXZlbnROYW1lKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmdab25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNhbGxCYXNlLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jYWxsQmFzZS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgfSxcblxuICAgICAgICBpc0VsZW1lbnROb2RlOiBmdW5jdGlvbihlbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gZWxlbWVudCAmJiBlbGVtZW50Lm5vZGVUeXBlID09PSAxO1xuICAgICAgICB9LFxuXG4gICAgICAgIGlzVGV4dE5vZGU6IGZ1bmN0aW9uKGVsZW1lbnQpIHtcbiAgICAgICAgICAgIHJldHVybiBlbGVtZW50ICYmIGVsZW1lbnQubm9kZVR5cGUgPT09IDM7XG4gICAgICAgIH0sXG5cbiAgICAgICAgaXNEb2N1bWVudDogZnVuY3Rpb24oZWxlbWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQgJiYgZWxlbWVudC5ub2RlVHlwZSA9PT0gOTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgaHR0cFJlcXVlc3QuaW5qZWN0KHtcbiAgICAgICAgZ2V0WGhyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIGlmICgheGhyRmFjdG9yeSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNhbGxCYXNlLmFwcGx5KHRoaXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IF94aHIgPSB4aHJGYWN0b3J5LmJ1aWxkKCk7XG4gICAgICAgICAgICBpZiAoISgnd2l0aENyZWRlbnRpYWxzJyBpbiBfeGhyKSkge1xuICAgICAgICAgICAgICAgIChfeGhyIGFzIGFueSlbJ3dpdGhDcmVkZW50aWFscyddID0gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBfeGhyO1xuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBjb25zdCBydW5SZWFkeUNhbGxiYWNrc0luWm9uZSA9ICgpID0+IHtcbiAgICAgICAgbmdab25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICBldmVudHNFbmdpbmUuc2V0KHt9KTtcbiAgICAgICAgICAgIGNhbGxiYWNrcy5mb3JFYWNoKGNhbGxiYWNrID0+IG9yaWdpbmFsQWRkLmNhbGwobnVsbCwgY2FsbGJhY2spKTtcbiAgICAgICAgICAgIGNhbGxiYWNrcyA9IFtdO1xuICAgICAgICAgICAgcmVhZHlDYWxsYmFja3MuZmlyZSgpO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgcnVuUmVhZHlDYWxsYmFja3NJblpvbmUoKTtcblxuICAgIHJlYWR5Q2FsbGJhY2tBZGQgPSAoY2FsbGJhY2spID0+IG5nWm9uZS5ydW4oKCkgPT4gY2FsbGJhY2soKSk7XG4gICAgZG9JbmplY3Rpb25zID0gcnVuUmVhZHlDYWxsYmFja3NJblpvbmU7XG59O1xuXG5ATmdNb2R1bGUoe30pXG5leHBvcnQgY2xhc3MgRHhJbnRlZ3JhdGlvbk1vZHVsZSB7XG4gICAgY29uc3RydWN0b3IoQEluamVjdChET0NVTUVOVCkgZG9jdW1lbnQ6IGFueSwgbmdab25lOiBOZ1pvbmUsIEBPcHRpb25hbCgpIHhockZhY3Rvcnk6IFhockZhY3RvcnkpIHtcbiAgICAgICAgZG9JbmplY3Rpb25zKGRvY3VtZW50LCBuZ1pvbmUsIHhockZhY3RvcnkpO1xuICAgIH1cbn1cbiJdfQ==