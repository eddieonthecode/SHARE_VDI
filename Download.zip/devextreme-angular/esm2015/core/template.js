/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
/* tslint:disable:use-input-property-decorator */
import { Directive, NgModule, TemplateRef, ViewContainerRef, Input, Renderer2, NgZone, EmbeddedViewRef } from '@angular/core';
import { DxTemplateHost } from './template-host';
import { getElement } from './utils';
import * as events from 'devextreme/events';
import * as domAdapter from 'devextreme/core/dom_adapter';
export const DX_TEMPLATE_WRAPPER_CLASS = 'dx-template-wrapper';
export class RenderData {
}
let DxTemplateDirective = class DxTemplateDirective {
    constructor(templateRef, viewContainerRef, templateHost, renderer, zone) {
        this.templateRef = templateRef;
        this.viewContainerRef = viewContainerRef;
        this.renderer = renderer;
        this.zone = zone;
        templateHost.setTemplate(this);
    }
    set dxTemplateOf(value) {
        this.name = value;
    }
    ;
    renderTemplate(renderData) {
        const childView = this.viewContainerRef.createEmbeddedView(this.templateRef, {
            '$implicit': renderData.model,
            index: renderData.index
        });
        const container = getElement(renderData.container);
        if (renderData.container) {
            childView.rootNodes.forEach((element) => {
                this.renderer.appendChild(container, element);
            });
        }
        return childView;
    }
    render(renderData) {
        let childView;
        if (this.zone.isStable) {
            childView = this.zone.run(() => {
                return this.renderTemplate(renderData);
            });
        }
        else {
            childView = this.renderTemplate(renderData);
        }
        // =========== WORKAROUND =============
        // https://github.com/angular/angular/issues/12243
        childView['detectChanges']();
        // =========== /WORKAROUND =============
        childView.rootNodes.forEach((element) => {
            if (element.nodeType === 1) {
                domAdapter.setClass(element, DX_TEMPLATE_WRAPPER_CLASS, true);
            }
            events.one(element, 'dxremove', ({}, params) => {
                if (!params || !params._angularIntegration) {
                    childView.destroy();
                }
            });
        });
        return childView.rootNodes;
    }
};
DxTemplateDirective.ctorParameters = () => [
    { type: TemplateRef },
    { type: ViewContainerRef },
    { type: DxTemplateHost },
    { type: Renderer2 },
    { type: NgZone }
];
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxTemplateDirective.prototype, "dxTemplateOf", null);
DxTemplateDirective = tslib_1.__decorate([
    Directive({
        selector: '[dxTemplate]'
    }),
    tslib_1.__metadata("design:paramtypes", [TemplateRef,
        ViewContainerRef,
        DxTemplateHost,
        Renderer2,
        NgZone])
], DxTemplateDirective);
export { DxTemplateDirective };
let DxTemplateModule = class DxTemplateModule {
};
DxTemplateModule = tslib_1.__decorate([
    NgModule({
        declarations: [DxTemplateDirective],
        exports: [DxTemplateDirective]
    })
], DxTemplateModule);
export { DxTemplateModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtcGxhdGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvY29yZS8iLCJzb3VyY2VzIjpbInRlbXBsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHOztBQUVILGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUNULFFBQVEsRUFDUixXQUFXLEVBQ1gsZ0JBQWdCLEVBQ2hCLEtBQUssRUFDTCxTQUFTLEVBQ1QsTUFBTSxFQUNOLGVBQWUsRUFDbEIsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2pELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxTQUFTLENBQUM7QUFDckMsT0FBTyxLQUFLLE1BQU0sTUFBTSxtQkFBbUIsQ0FBQztBQUM1QyxPQUFPLEtBQUssVUFBVSxNQUFNLDZCQUE2QixDQUFDO0FBRTFELE1BQU0sQ0FBQyxNQUFNLHlCQUF5QixHQUFHLHFCQUFxQixDQUFDO0FBRS9ELE1BQU0sT0FBTyxVQUFVO0NBSXRCO0FBS0QsSUFBYSxtQkFBbUIsR0FBaEMsTUFBYSxtQkFBbUI7SUFPNUIsWUFBb0IsV0FBNkIsRUFDckMsZ0JBQWtDLEVBQzFDLFlBQTRCLEVBQ3BCLFFBQW1CLEVBQ25CLElBQVk7UUFKSixnQkFBVyxHQUFYLFdBQVcsQ0FBa0I7UUFDckMscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtRQUVsQyxhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ25CLFNBQUksR0FBSixJQUFJLENBQVE7UUFDcEIsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBWEQsSUFBSSxZQUFZLENBQUMsS0FBSztRQUNsQixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQUEsQ0FBQztJQVdNLGNBQWMsQ0FBQyxVQUFzQjtRQUN6QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUN6RSxXQUFXLEVBQUUsVUFBVSxDQUFDLEtBQUs7WUFDN0IsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLO1NBQzFCLENBQUMsQ0FBQztRQUVILE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDbkQsSUFBSSxVQUFVLENBQUMsU0FBUyxFQUFFO1lBQ3RCLFNBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUU7Z0JBQ3BDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNsRCxDQUFDLENBQUMsQ0FBQztTQUNOO1FBRUQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVELE1BQU0sQ0FBQyxVQUFzQjtRQUN6QixJQUFJLFNBQVMsQ0FBQztRQUNkLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDcEIsU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRTtnQkFDM0IsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFBTTtZQUNILFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQy9DO1FBQ0QsdUNBQXVDO1FBQ3ZDLGtEQUFrRDtRQUNsRCxTQUFTLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQztRQUM3Qix3Q0FBd0M7UUFFeEMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUNwQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssQ0FBQyxFQUFFO2dCQUN4QixVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNqRTtZQUVELE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRTtvQkFDeEMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUN2QjtZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDL0IsQ0FBQztDQUNKLENBQUE7O1lBcERvQyxXQUFXO1lBQ2QsZ0JBQWdCO1lBQzVCLGNBQWM7WUFDVixTQUFTO1lBQ2IsTUFBTTs7QUFUeEI7SUFEQyxLQUFLLEVBQUU7Ozt1REFHUDtBQUpRLG1CQUFtQjtJQUgvQixTQUFTLENBQUM7UUFDUCxRQUFRLEVBQUUsY0FBYztLQUMzQixDQUFDOzZDQVFtQyxXQUFXO1FBQ2QsZ0JBQWdCO1FBQzVCLGNBQWM7UUFDVixTQUFTO1FBQ2IsTUFBTTtHQVhmLG1CQUFtQixDQTJEL0I7U0EzRFksbUJBQW1CO0FBaUVoQyxJQUFhLGdCQUFnQixHQUE3QixNQUFhLGdCQUFnQjtDQUFJLENBQUE7QUFBcEIsZ0JBQWdCO0lBSjVCLFFBQVEsQ0FBQztRQUNOLFlBQVksRUFBRSxDQUFDLG1CQUFtQixDQUFDO1FBQ25DLE9BQU8sRUFBRSxDQUFDLG1CQUFtQixDQUFDO0tBQ2pDLENBQUM7R0FDVyxnQkFBZ0IsQ0FBSTtTQUFwQixnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBEaXJlY3RpdmUsXG4gICAgTmdNb2R1bGUsXG4gICAgVGVtcGxhdGVSZWYsXG4gICAgVmlld0NvbnRhaW5lclJlZixcbiAgICBJbnB1dCxcbiAgICBSZW5kZXJlcjIsXG4gICAgTmdab25lLFxuICAgIEVtYmVkZGVkVmlld1JlZlxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRHhUZW1wbGF0ZUhvc3QgfSBmcm9tICcuL3RlbXBsYXRlLWhvc3QnO1xuaW1wb3J0IHsgZ2V0RWxlbWVudCB9IGZyb20gJy4vdXRpbHMnO1xuaW1wb3J0ICogYXMgZXZlbnRzIGZyb20gJ2RldmV4dHJlbWUvZXZlbnRzJztcbmltcG9ydCAqIGFzIGRvbUFkYXB0ZXIgZnJvbSAnZGV2ZXh0cmVtZS9jb3JlL2RvbV9hZGFwdGVyJztcblxuZXhwb3J0IGNvbnN0IERYX1RFTVBMQVRFX1dSQVBQRVJfQ0xBU1MgPSAnZHgtdGVtcGxhdGUtd3JhcHBlcic7XG5cbmV4cG9ydCBjbGFzcyBSZW5kZXJEYXRhIHtcbiAgICBtb2RlbDogYW55O1xuICAgIGluZGV4OiBudW1iZXI7XG4gICAgY29udGFpbmVyOiBhbnk7XG59XG5cbkBEaXJlY3RpdmUoe1xuICAgIHNlbGVjdG9yOiAnW2R4VGVtcGxhdGVdJ1xufSlcbmV4cG9ydCBjbGFzcyBEeFRlbXBsYXRlRGlyZWN0aXZlIHtcbiAgICBASW5wdXQoKVxuICAgIHNldCBkeFRlbXBsYXRlT2YodmFsdWUpIHtcbiAgICAgICAgdGhpcy5uYW1lID0gdmFsdWU7XG4gICAgfTtcbiAgICBuYW1lOiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHRlbXBsYXRlUmVmOiBUZW1wbGF0ZVJlZjxhbnk+LFxuICAgICAgICBwcml2YXRlIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWYsXG4gICAgICAgIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICAgICAgcHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHtcbiAgICAgICAgdGVtcGxhdGVIb3N0LnNldFRlbXBsYXRlKHRoaXMpO1xuICAgIH1cblxuICAgIHByaXZhdGUgcmVuZGVyVGVtcGxhdGUocmVuZGVyRGF0YTogUmVuZGVyRGF0YSk6IEVtYmVkZGVkVmlld1JlZjxhbnk+IHtcbiAgICAgICAgY29uc3QgY2hpbGRWaWV3ID0gdGhpcy52aWV3Q29udGFpbmVyUmVmLmNyZWF0ZUVtYmVkZGVkVmlldyh0aGlzLnRlbXBsYXRlUmVmLCB7XG4gICAgICAgICAgICAnJGltcGxpY2l0JzogcmVuZGVyRGF0YS5tb2RlbCxcbiAgICAgICAgICAgIGluZGV4OiByZW5kZXJEYXRhLmluZGV4XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IGdldEVsZW1lbnQocmVuZGVyRGF0YS5jb250YWluZXIpO1xuICAgICAgICBpZiAocmVuZGVyRGF0YS5jb250YWluZXIpIHtcbiAgICAgICAgICAgIGNoaWxkVmlldy5yb290Tm9kZXMuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMucmVuZGVyZXIuYXBwZW5kQ2hpbGQoY29udGFpbmVyLCBlbGVtZW50KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGNoaWxkVmlldztcbiAgICB9XG5cbiAgICByZW5kZXIocmVuZGVyRGF0YTogUmVuZGVyRGF0YSkge1xuICAgICAgICBsZXQgY2hpbGRWaWV3O1xuICAgICAgICBpZiAodGhpcy56b25lLmlzU3RhYmxlKSB7XG4gICAgICAgICAgICBjaGlsZFZpZXcgPSB0aGlzLnpvbmUucnVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZW5kZXJUZW1wbGF0ZShyZW5kZXJEYXRhKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2hpbGRWaWV3ID0gdGhpcy5yZW5kZXJUZW1wbGF0ZShyZW5kZXJEYXRhKTtcbiAgICAgICAgfVxuICAgICAgICAvLyA9PT09PT09PT09PSBXT1JLQVJPVU5EID09PT09PT09PT09PT1cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9pc3N1ZXMvMTIyNDNcbiAgICAgICAgY2hpbGRWaWV3WydkZXRlY3RDaGFuZ2VzJ10oKTtcbiAgICAgICAgLy8gPT09PT09PT09PT0gL1dPUktBUk9VTkQgPT09PT09PT09PT09PVxuXG4gICAgICAgIGNoaWxkVmlldy5yb290Tm9kZXMuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGVsZW1lbnQubm9kZVR5cGUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICBkb21BZGFwdGVyLnNldENsYXNzKGVsZW1lbnQsIERYX1RFTVBMQVRFX1dSQVBQRVJfQ0xBU1MsIHRydWUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBldmVudHMub25lKGVsZW1lbnQsICdkeHJlbW92ZScsICh7fSwgcGFyYW1zKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwYXJhbXMgfHwgIXBhcmFtcy5fYW5ndWxhckludGVncmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGNoaWxkVmlldy5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBjaGlsZFZpZXcucm9vdE5vZGVzO1xuICAgIH1cbn1cblxuQE5nTW9kdWxlKHtcbiAgICBkZWNsYXJhdGlvbnM6IFtEeFRlbXBsYXRlRGlyZWN0aXZlXSxcbiAgICBleHBvcnRzOiBbRHhUZW1wbGF0ZURpcmVjdGl2ZV1cbn0pXG5leHBvcnQgY2xhc3MgRHhUZW1wbGF0ZU1vZHVsZSB7IH1cbiJdfQ==