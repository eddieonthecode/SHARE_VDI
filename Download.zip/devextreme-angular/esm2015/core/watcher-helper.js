/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import * as commonUtils from 'devextreme/core/utils/common';
let WatcherHelper = class WatcherHelper {
    constructor() {
        this._watchers = [];
    }
    getWatchMethod() {
        let watchMethod = (valueGetter, valueChangeCallback, options) => {
            let oldValue = valueGetter();
            options = options || {};
            if (!options.skipImmediate) {
                valueChangeCallback(oldValue);
            }
            let watcher = () => {
                let newValue = valueGetter();
                if (this._isDifferentValues(oldValue, newValue, options.deep)) {
                    valueChangeCallback(newValue);
                    oldValue = newValue;
                }
            };
            this._watchers.push(watcher);
            return () => {
                let index = this._watchers.indexOf(watcher);
                if (index !== -1) {
                    this._watchers.splice(index, 1);
                }
            };
        };
        return watchMethod;
    }
    _isDifferentValues(oldValue, newValue, deepCheck) {
        let comparableNewValue = this._toComparable(newValue);
        let comparableOldValue = this._toComparable(oldValue);
        let isObjectValues = comparableNewValue instanceof Object && comparableOldValue instanceof Object;
        if (deepCheck && isObjectValues) {
            return this._checkObjectsFields(newValue, oldValue);
        }
        return comparableNewValue !== comparableOldValue;
    }
    _toComparable(value) {
        if (value instanceof Date) {
            return value.getTime();
        }
        return value;
    }
    _checkObjectsFields(checkingFromObject, checkingToObject) {
        for (let field in checkingFromObject) {
            let oldValue = this._toComparable(checkingFromObject[field]);
            let newValue = this._toComparable(checkingToObject[field]);
            let isEqualObjects = false;
            if (typeof oldValue === 'object' && typeof newValue === 'object') {
                isEqualObjects = commonUtils.equalByValue(oldValue, newValue);
            }
            if (oldValue !== newValue && !isEqualObjects) {
                return true;
            }
        }
    }
    checkWatchers() {
        for (let watcher of this._watchers) {
            watcher();
        }
    }
};
WatcherHelper = tslib_1.__decorate([
    Injectable()
], WatcherHelper);
export { WatcherHelper };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2F0Y2hlci1oZWxwZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvY29yZS8iLCJzb3VyY2VzIjpbIndhdGNoZXItaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHOztBQUVILE9BQU8sRUFDSCxVQUFVLEVBQ2IsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxLQUFLLFdBQVcsTUFBTSw4QkFBOEIsQ0FBQztBQUc1RCxJQUFhLGFBQWEsR0FBMUIsTUFBYSxhQUFhO0lBRDFCO1FBRVksY0FBUyxHQUFVLEVBQUUsQ0FBQztJQXlFbEMsQ0FBQztJQXZFRyxjQUFjO1FBQ1YsSUFBSSxXQUFXLEdBQUcsQ0FBQyxXQUFXLEVBQUUsbUJBQW1CLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDNUQsSUFBSSxRQUFRLEdBQUcsV0FBVyxFQUFFLENBQUM7WUFDN0IsT0FBTyxHQUFHLE9BQU8sSUFBSSxFQUFFLENBQUM7WUFFeEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7Z0JBQ3hCLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ2pDO1lBRUQsSUFBSSxPQUFPLEdBQUcsR0FBRyxFQUFFO2dCQUNmLElBQUksUUFBUSxHQUFHLFdBQVcsRUFBRSxDQUFDO2dCQUU3QixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDM0QsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzlCLFFBQVEsR0FBRyxRQUFRLENBQUM7aUJBQ3ZCO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFN0IsT0FBTyxHQUFHLEVBQUU7Z0JBQ1IsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBRTVDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxFQUFFO29CQUNkLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbkM7WUFDTCxDQUFDLENBQUM7UUFDTixDQUFDLENBQUM7UUFFRixPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU8sa0JBQWtCLENBQUMsUUFBYSxFQUFFLFFBQWEsRUFBRSxTQUFrQjtRQUN2RSxJQUFJLGtCQUFrQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEQsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RELElBQUksY0FBYyxHQUFHLGtCQUFrQixZQUFZLE1BQU0sSUFBSSxrQkFBa0IsWUFBWSxNQUFNLENBQUM7UUFFbEcsSUFBSSxTQUFTLElBQUksY0FBYyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztTQUN2RDtRQUNELE9BQU8sa0JBQWtCLEtBQUssa0JBQWtCLENBQUM7SUFDckQsQ0FBQztJQUVPLGFBQWEsQ0FBQyxLQUFLO1FBQ3ZCLElBQUksS0FBSyxZQUFZLElBQUksRUFBRTtZQUN2QixPQUFPLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxrQkFBMEIsRUFBRSxnQkFBd0I7UUFDNUUsS0FBSyxJQUFJLEtBQUssSUFBSSxrQkFBa0IsRUFBRTtZQUNsQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDN0QsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQzNELElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQztZQUUzQixJQUFJLE9BQU8sUUFBUSxLQUFLLFFBQVEsSUFBSSxPQUFPLFFBQVEsS0FBSyxRQUFRLEVBQUU7Z0JBQzlELGNBQWMsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUNqRTtZQUNELElBQUksUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLGNBQWMsRUFBRTtnQkFDMUMsT0FBTyxJQUFJLENBQUM7YUFDZjtTQUNKO0lBQ0wsQ0FBQztJQUVELGFBQWE7UUFDVixLQUFLLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDL0IsT0FBTyxFQUFFLENBQUM7U0FDYjtJQUNMLENBQUM7Q0FDSixDQUFBO0FBMUVZLGFBQWE7SUFEekIsVUFBVSxFQUFFO0dBQ0EsYUFBYSxDQTBFekI7U0ExRVksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyMC4yLjEyXG4gKiBCdWlsZCBkYXRlOiBUdWUgT2N0IDE4IDIwMjJcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDIyIERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuaW1wb3J0IHtcbiAgICBJbmplY3RhYmxlXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgKiBhcyBjb21tb25VdGlscyBmcm9tICdkZXZleHRyZW1lL2NvcmUvdXRpbHMvY29tbW9uJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFdhdGNoZXJIZWxwZXIge1xuICAgIHByaXZhdGUgX3dhdGNoZXJzOiBhbnlbXSA9IFtdO1xuXG4gICAgZ2V0V2F0Y2hNZXRob2QoKSB7XG4gICAgICAgIGxldCB3YXRjaE1ldGhvZCA9ICh2YWx1ZUdldHRlciwgdmFsdWVDaGFuZ2VDYWxsYmFjaywgb3B0aW9ucykgPT4ge1xuICAgICAgICAgICAgbGV0IG9sZFZhbHVlID0gdmFsdWVHZXR0ZXIoKTtcbiAgICAgICAgICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMuc2tpcEltbWVkaWF0ZSkge1xuICAgICAgICAgICAgICAgIHZhbHVlQ2hhbmdlQ2FsbGJhY2sob2xkVmFsdWUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgd2F0Y2hlciA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgbmV3VmFsdWUgPSB2YWx1ZUdldHRlcigpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzRGlmZmVyZW50VmFsdWVzKG9sZFZhbHVlLCBuZXdWYWx1ZSwgb3B0aW9ucy5kZWVwKSkge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZUNoYW5nZUNhbGxiYWNrKG5ld1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgb2xkVmFsdWUgPSBuZXdWYWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICB0aGlzLl93YXRjaGVycy5wdXNoKHdhdGNoZXIpO1xuXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IHRoaXMuX3dhdGNoZXJzLmluZGV4T2Yod2F0Y2hlcik7XG5cbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3dhdGNoZXJzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gd2F0Y2hNZXRob2Q7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBfaXNEaWZmZXJlbnRWYWx1ZXMob2xkVmFsdWU6IGFueSwgbmV3VmFsdWU6IGFueSwgZGVlcENoZWNrOiBib29sZWFuKSB7XG4gICAgICAgIGxldCBjb21wYXJhYmxlTmV3VmFsdWUgPSB0aGlzLl90b0NvbXBhcmFibGUobmV3VmFsdWUpO1xuICAgICAgICBsZXQgY29tcGFyYWJsZU9sZFZhbHVlID0gdGhpcy5fdG9Db21wYXJhYmxlKG9sZFZhbHVlKTtcbiAgICAgICAgbGV0IGlzT2JqZWN0VmFsdWVzID0gY29tcGFyYWJsZU5ld1ZhbHVlIGluc3RhbmNlb2YgT2JqZWN0ICYmIGNvbXBhcmFibGVPbGRWYWx1ZSBpbnN0YW5jZW9mIE9iamVjdDtcblxuICAgICAgICBpZiAoZGVlcENoZWNrICYmIGlzT2JqZWN0VmFsdWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2hlY2tPYmplY3RzRmllbGRzKG5ld1ZhbHVlLCBvbGRWYWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBhcmFibGVOZXdWYWx1ZSAhPT0gY29tcGFyYWJsZU9sZFZhbHVlO1xuICAgIH1cblxuICAgIHByaXZhdGUgX3RvQ29tcGFyYWJsZSh2YWx1ZSkge1xuICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUuZ2V0VGltZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cblxuICAgIHByaXZhdGUgX2NoZWNrT2JqZWN0c0ZpZWxkcyhjaGVja2luZ0Zyb21PYmplY3Q6IE9iamVjdCwgY2hlY2tpbmdUb09iamVjdDogT2JqZWN0KSB7XG4gICAgICAgIGZvciAobGV0IGZpZWxkIGluIGNoZWNraW5nRnJvbU9iamVjdCkge1xuICAgICAgICAgICAgbGV0IG9sZFZhbHVlID0gdGhpcy5fdG9Db21wYXJhYmxlKGNoZWNraW5nRnJvbU9iamVjdFtmaWVsZF0pO1xuICAgICAgICAgICAgbGV0IG5ld1ZhbHVlID0gdGhpcy5fdG9Db21wYXJhYmxlKGNoZWNraW5nVG9PYmplY3RbZmllbGRdKTtcbiAgICAgICAgICAgIGxldCBpc0VxdWFsT2JqZWN0cyA9IGZhbHNlO1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9sZFZhbHVlID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgbmV3VmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgaXNFcXVhbE9iamVjdHMgPSBjb21tb25VdGlscy5lcXVhbEJ5VmFsdWUob2xkVmFsdWUsIG5ld1ZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvbGRWYWx1ZSAhPT0gbmV3VmFsdWUgJiYgIWlzRXF1YWxPYmplY3RzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjaGVja1dhdGNoZXJzKCkge1xuICAgICAgIGZvciAobGV0IHdhdGNoZXIgb2YgdGhpcy5fd2F0Y2hlcnMpIHtcbiAgICAgICAgICAgIHdhdGNoZXIoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ==