/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
import { Injectable, SimpleChanges, IterableDiffers } from '@angular/core';
let IterableDifferHelper = class IterableDifferHelper {
    constructor(_differs) {
        this._differs = _differs;
        this._propertyDiffers = {};
    }
    setHost(host) {
        this._host = host;
    }
    setup(prop, changes) {
        if (prop in changes) {
            const value = changes[prop].currentValue;
            this.setupSingle(prop, value);
        }
    }
    setupSingle(prop, value) {
        if (value && Array.isArray(value)) {
            if (!this._propertyDiffers[prop]) {
                try {
                    this._propertyDiffers[prop] = this._differs.find(value).create(null);
                    return true;
                }
                catch (e) { }
            }
        }
        else {
            delete this._propertyDiffers[prop];
        }
        return false;
    }
    getChanges(prop, value) {
        if (this._propertyDiffers[prop]) {
            return this._propertyDiffers[prop].diff(value);
        }
    }
    checkChangedOptions(propName, hostValue) {
        return this._host.changedOptions[propName] === hostValue;
    }
    ;
    doCheck(prop) {
        if (this._propertyDiffers[prop]) {
            let hostValue = this._host[prop], isChangedOption = this.checkChangedOptions(prop, hostValue);
            const changes = this.getChanges(prop, hostValue);
            if (changes && this._host.instance && !isChangedOption) {
                this._host.lockWidgetUpdate();
                this._host.instance.option(prop, hostValue);
            }
        }
    }
};
IterableDifferHelper.ctorParameters = () => [
    { type: IterableDiffers }
];
IterableDifferHelper = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [IterableDiffers])
], IterableDifferHelper);
export { IterableDifferHelper };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlcmFibGUtZGlmZmVyLWhlbHBlci5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2RldmV4dHJlbWUtYW5ndWxhci9jb3JlLyIsInNvdXJjZXMiOlsiaXRlcmFibGUtZGlmZmVyLWhlbHBlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRzs7QUFFSCxPQUFPLEVBQ0gsVUFBVSxFQUNWLGFBQWEsRUFDYixlQUFlLEVBQ2xCLE1BQU0sZUFBZSxDQUFDO0FBT3ZCLElBQWEsb0JBQW9CLEdBQWpDLE1BQWEsb0JBQW9CO0lBSzdCLFlBQW9CLFFBQXlCO1FBQXpCLGFBQVEsR0FBUixRQUFRLENBQWlCO1FBRnJDLHFCQUFnQixHQUEyQixFQUFFLENBQUM7SUFFTCxDQUFDO0lBRWxELE9BQU8sQ0FBQyxJQUFpQjtRQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztJQUN0QixDQUFDO0lBRUQsS0FBSyxDQUFDLElBQVksRUFBRSxPQUFzQjtRQUN0QyxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUU7WUFDakIsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFRCxXQUFXLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDaEMsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM5QixJQUFJO29CQUNBLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3JFLE9BQU8sSUFBSSxDQUFDO2lCQUNmO2dCQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUc7YUFDbEI7U0FDSjthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdEM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQy9CLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxRQUFnQixFQUFFLFNBQWM7UUFDaEQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsS0FBSyxTQUFTLENBQUM7SUFDN0QsQ0FBQztJQUFBLENBQUM7SUFFRixPQUFPLENBQUMsSUFBWTtRQUNoQixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM3QixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUM1QixlQUFlLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUVoRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUNqRCxJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxDQUFDLGVBQWUsRUFBRTtnQkFDcEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUM5QixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2FBQy9DO1NBQ0o7SUFDTCxDQUFDO0NBRUosQ0FBQTs7WUFuRGlDLGVBQWU7O0FBTHBDLG9CQUFvQjtJQURoQyxVQUFVLEVBQUU7NkNBTXFCLGVBQWU7R0FMcEMsb0JBQW9CLENBd0RoQztTQXhEWSxvQkFBb0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmltcG9ydCB7XG4gICAgSW5qZWN0YWJsZSxcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIEl0ZXJhYmxlRGlmZmVyc1xufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHtcbiAgICBEeENvbXBvbmVudFxufSBmcm9tICcuL2NvbXBvbmVudCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBJdGVyYWJsZURpZmZlckhlbHBlciB7XG5cbiAgICBwcml2YXRlIF9ob3N0OiBEeENvbXBvbmVudDtcbiAgICBwcml2YXRlIF9wcm9wZXJ0eURpZmZlcnM6IHsgW2lkOiBzdHJpbmddOiBhbnk7IH0gPSB7fTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2RpZmZlcnM6IEl0ZXJhYmxlRGlmZmVycykgeyB9XG5cbiAgICBzZXRIb3N0KGhvc3Q6IER4Q29tcG9uZW50KSB7XG4gICAgICAgIHRoaXMuX2hvc3QgPSBob3N0O1xuICAgIH1cblxuICAgIHNldHVwKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAocHJvcCBpbiBjaGFuZ2VzKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGNoYW5nZXNbcHJvcF0uY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgdGhpcy5zZXR1cFNpbmdsZShwcm9wLCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBzZXR1cFNpbmdsZShwcm9wOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICAgICAgaWYgKHZhbHVlICYmIEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuX3Byb3BlcnR5RGlmZmVyc1twcm9wXSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Byb3BlcnR5RGlmZmVyc1twcm9wXSA9IHRoaXMuX2RpZmZlcnMuZmluZCh2YWx1ZSkuY3JlYXRlKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7IH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9wcm9wZXJ0eURpZmZlcnNbcHJvcF07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgZ2V0Q2hhbmdlcyhwcm9wOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICAgICAgaWYgKHRoaXMuX3Byb3BlcnR5RGlmZmVyc1twcm9wXSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3Byb3BlcnR5RGlmZmVyc1twcm9wXS5kaWZmKHZhbHVlKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGNoZWNrQ2hhbmdlZE9wdGlvbnMocHJvcE5hbWU6IHN0cmluZywgaG9zdFZhbHVlOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hvc3QuY2hhbmdlZE9wdGlvbnNbcHJvcE5hbWVdID09PSBob3N0VmFsdWU7XG4gICAgfTtcblxuICAgIGRvQ2hlY2socHJvcDogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLl9wcm9wZXJ0eURpZmZlcnNbcHJvcF0pIHtcbiAgICAgICAgICAgIGxldCBob3N0VmFsdWUgPSB0aGlzLl9ob3N0W3Byb3BdLFxuICAgICAgICAgICAgICAgIGlzQ2hhbmdlZE9wdGlvbiA9IHRoaXMuY2hlY2tDaGFuZ2VkT3B0aW9ucyhwcm9wLCBob3N0VmFsdWUpO1xuXG4gICAgICAgICAgICBjb25zdCBjaGFuZ2VzID0gdGhpcy5nZXRDaGFuZ2VzKHByb3AsIGhvc3RWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoY2hhbmdlcyAmJiB0aGlzLl9ob3N0Lmluc3RhbmNlICYmICFpc0NoYW5nZWRPcHRpb24pIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9ob3N0LmxvY2tXaWRnZXRVcGRhdGUoKTtcbiAgICAgICAgICAgICAgICB0aGlzLl9ob3N0Lmluc3RhbmNlLm9wdGlvbihwcm9wLCBob3N0VmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG59XG4iXX0=