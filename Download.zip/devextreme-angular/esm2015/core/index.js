/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
export * from './component';
export * from './events-strategy';
export * from './integration';
export * from './iterable-differ-helper';
export * from './nested-option';
export * from './template-host';
export * from './template';
export * from './transfer-state';
export * from './utils';
export * from './watcher-helper';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvY29yZS8iLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsY0FBYyxhQUFhLENBQUM7QUFDNUIsY0FBYyxtQkFBbUIsQ0FBQztBQUNsQyxjQUFjLGVBQWUsQ0FBQztBQUM5QixjQUFjLDBCQUEwQixDQUFDO0FBQ3pDLGNBQWMsaUJBQWlCLENBQUM7QUFDaEMsY0FBYyxpQkFBaUIsQ0FBQztBQUNoQyxjQUFjLFlBQVksQ0FBQztBQUMzQixjQUFjLGtCQUFrQixDQUFDO0FBQ2pDLGNBQWMsU0FBUyxDQUFDO0FBQ3hCLGNBQWMsa0JBQWtCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vZXZlbnRzLXN0cmF0ZWd5JztcbmV4cG9ydCAqIGZyb20gJy4vaW50ZWdyYXRpb24nO1xuZXhwb3J0ICogZnJvbSAnLi9pdGVyYWJsZS1kaWZmZXItaGVscGVyJztcbmV4cG9ydCAqIGZyb20gJy4vbmVzdGVkLW9wdGlvbic7XG5leHBvcnQgKiBmcm9tICcuL3RlbXBsYXRlLWhvc3QnO1xuZXhwb3J0ICogZnJvbSAnLi90ZW1wbGF0ZSc7XG5leHBvcnQgKiBmcm9tICcuL3RyYW5zZmVyLXN0YXRlJztcbmV4cG9ydCAqIGZyb20gJy4vdXRpbHMnO1xuZXhwb3J0ICogZnJvbSAnLi93YXRjaGVyLWhlbHBlcic7XG4iXX0=