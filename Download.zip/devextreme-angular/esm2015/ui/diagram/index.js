/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
/* tslint:disable:max-line-length */
import { BrowserTransferStateModule } from '@angular/platform-browser';
import { TransferState } from '@angular/platform-browser';
import { Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, OnDestroy, EventEmitter, OnChanges, DoCheck, SimpleChanges, ContentChildren, QueryList } from '@angular/core';
import DxDiagram from 'devextreme/ui/diagram';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoContextMenuModule } from 'devextreme-angular/ui/nested';
import { DxiCommandModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoContextToolboxModule } from 'devextreme-angular/ui/nested';
import { DxiCustomShapeModule } from 'devextreme-angular/ui/nested';
import { DxiConnectionPointModule } from 'devextreme-angular/ui/nested';
import { DxoDefaultItemPropertiesModule } from 'devextreme-angular/ui/nested';
import { DxoEdgesModule } from 'devextreme-angular/ui/nested';
import { DxoEditingModule } from 'devextreme-angular/ui/nested';
import { DxoExportModule } from 'devextreme-angular/ui/nested';
import { DxoGridSizeModule } from 'devextreme-angular/ui/nested';
import { DxoHistoryToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoMainToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoNodesModule } from 'devextreme-angular/ui/nested';
import { DxoAutoLayoutModule } from 'devextreme-angular/ui/nested';
import { DxoPageSizeModule } from 'devextreme-angular/ui/nested';
import { DxoPropertiesPanelModule } from 'devextreme-angular/ui/nested';
import { DxiTabModule } from 'devextreme-angular/ui/nested';
import { DxiGroupModule } from 'devextreme-angular/ui/nested';
import { DxoToolboxModule } from 'devextreme-angular/ui/nested';
import { DxoViewToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoZoomLevelModule } from 'devextreme-angular/ui/nested';
import { DxiCustomShapeComponent } from 'devextreme-angular/ui/nested';
/**
 * The Diagram UI component provides a visual interface to help you design new and modify existing diagrams.

 */
let DxDiagramComponent = class DxDiagramComponent extends DxComponent {
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemDblClick', emit: 'onItemDblClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'requestEditOperation', emit: 'onRequestEditOperation' },
            { subscribe: 'requestLayoutUpdate', emit: 'onRequestLayoutUpdate' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'autoZoomModeChange' },
            { emit: 'contextMenuChange' },
            { emit: 'contextToolboxChange' },
            { emit: 'customShapesChange' },
            { emit: 'customShapeTemplateChange' },
            { emit: 'customShapeToolboxTemplateChange' },
            { emit: 'defaultItemPropertiesChange' },
            { emit: 'disabledChange' },
            { emit: 'edgesChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'exportChange' },
            { emit: 'fullScreenChange' },
            { emit: 'gridSizeChange' },
            { emit: 'hasChangesChange' },
            { emit: 'heightChange' },
            { emit: 'historyToolbarChange' },
            { emit: 'mainToolbarChange' },
            { emit: 'nodesChange' },
            { emit: 'pageColorChange' },
            { emit: 'pageOrientationChange' },
            { emit: 'pageSizeChange' },
            { emit: 'propertiesPanelChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showGridChange' },
            { emit: 'simpleViewChange' },
            { emit: 'snapToGridChange' },
            { emit: 'toolboxChange' },
            { emit: 'unitsChange' },
            { emit: 'viewToolbarChange' },
            { emit: 'viewUnitsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'zoomLevelChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    /**
     * Specifies how the Diagram UI component automatically zooms the work area.
    
     */
    get autoZoomMode() {
        return this._getOption('autoZoomMode');
    }
    set autoZoomMode(value) {
        this._setOption('autoZoomMode', value);
    }
    /**
     * Configures the context menu's settings.
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * Configures the context toolbox's settings.
    
     */
    get contextToolbox() {
        return this._getOption('contextToolbox');
    }
    set contextToolbox(value) {
        this._setOption('contextToolbox', value);
    }
    /**
     * Provide access to an array of custom shapes.
    
     */
    get customShapes() {
        return this._getOption('customShapes');
    }
    set customShapes(value) {
        this._setOption('customShapes', value);
    }
    /**
     * Specifies a custom template for shapes.
    
     */
    get customShapeTemplate() {
        return this._getOption('customShapeTemplate');
    }
    set customShapeTemplate(value) {
        this._setOption('customShapeTemplate', value);
    }
    /**
     * Specifies a custom template for shapes in the toolbox.
    
     */
    get customShapeToolboxTemplate() {
        return this._getOption('customShapeToolboxTemplate');
    }
    set customShapeToolboxTemplate(value) {
        this._setOption('customShapeToolboxTemplate', value);
    }
    /**
     * Configures default item properties.
    
     */
    get defaultItemProperties() {
        return this._getOption('defaultItemProperties');
    }
    set defaultItemProperties(value) {
        this._setOption('defaultItemProperties', value);
    }
    /**
     * Specifies whether the UI component responds to user interaction.
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * Allows you to bind the collection of diagram edges to a data source. For more information, see the Data Binding section.
    
     */
    get edges() {
        return this._getOption('edges');
    }
    set edges(value) {
        this._setOption('edges', value);
    }
    /**
     * Specifies which editing operations a user can perform.
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * Specifies the global attributes to be attached to the UI component's container element.
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * Configures export settings.
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * Specifies whether or not to display the UI component in full-screen mode.
    
     */
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    /**
     * Specifies the grid pitch.
    
     */
    get gridSize() {
        return this._getOption('gridSize');
    }
    set gridSize(value) {
        this._setOption('gridSize', value);
    }
    /**
     * Indicates whether diagram content has been changed.
    
     */
    get hasChanges() {
        return this._getOption('hasChanges');
    }
    set hasChanges(value) {
        this._setOption('hasChanges', value);
    }
    /**
     * Specifies the UI component's height.
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * Configures the history toolbar's settings.
    
     */
    get historyToolbar() {
        return this._getOption('historyToolbar');
    }
    set historyToolbar(value) {
        this._setOption('historyToolbar', value);
    }
    /**
     * Configures the main toolbar settings.
    
     */
    get mainToolbar() {
        return this._getOption('mainToolbar');
    }
    set mainToolbar(value) {
        this._setOption('mainToolbar', value);
    }
    /**
     * Allows you to bind the collection of diagram nodes to a data source. For more information, see the Data Binding section.
    
     */
    get nodes() {
        return this._getOption('nodes');
    }
    set nodes(value) {
        this._setOption('nodes', value);
    }
    /**
     * Specifies the color of a diagram page.
    
     */
    get pageColor() {
        return this._getOption('pageColor');
    }
    set pageColor(value) {
        this._setOption('pageColor', value);
    }
    /**
     * Specifies the page orientation.
    
     */
    get pageOrientation() {
        return this._getOption('pageOrientation');
    }
    set pageOrientation(value) {
        this._setOption('pageOrientation', value);
    }
    /**
     * Specifies a size of pages.
    
     */
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    /**
     * Configures the Properties panel settings.
    
     */
    get propertiesPanel() {
        return this._getOption('propertiesPanel');
    }
    set propertiesPanel(value) {
        this._setOption('propertiesPanel', value);
    }
    /**
     * Specifies whether the diagram is read-only.
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * Switches the UI component to a right-to-left representation.
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * Specifies whether grid lines are visible.
    
     */
    get showGrid() {
        return this._getOption('showGrid');
    }
    set showGrid(value) {
        this._setOption('showGrid', value);
    }
    /**
     * Switch the Diagram UI component to simple view mode.
    
     */
    get simpleView() {
        return this._getOption('simpleView');
    }
    set simpleView(value) {
        this._setOption('simpleView', value);
    }
    /**
     * Specifies whether diagram elements should snap to grid lines.
    
     */
    get snapToGrid() {
        return this._getOption('snapToGrid');
    }
    set snapToGrid(value) {
        this._setOption('snapToGrid', value);
    }
    /**
     * Configures the toolbox settings.
    
     */
    get toolbox() {
        return this._getOption('toolbox');
    }
    set toolbox(value) {
        this._setOption('toolbox', value);
    }
    /**
     * Specifies the measurement unit for size properties.
    
     */
    get units() {
        return this._getOption('units');
    }
    set units(value) {
        this._setOption('units', value);
    }
    /**
     * Configures the view toolbar settings.
    
     */
    get viewToolbar() {
        return this._getOption('viewToolbar');
    }
    set viewToolbar(value) {
        this._setOption('viewToolbar', value);
    }
    /**
     * Specifies the measurement unit that is displayed in user interface elements.
    
     */
    get viewUnits() {
        return this._getOption('viewUnits');
    }
    set viewUnits(value) {
        this._setOption('viewUnits', value);
    }
    /**
     * Specifies whether the UI component is visible.
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * Specifies the UI component's width.
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * Specifies the zoom level.
    
     */
    get zoomLevel() {
        return this._getOption('zoomLevel');
    }
    set zoomLevel(value) {
        this._setOption('zoomLevel', value);
    }
    get customShapesChildren() {
        return this._getOption('customShapes');
    }
    set customShapesChildren(value) {
        this.setChildren('customShapes', value);
    }
    _createInstance(element, options) {
        return new DxDiagram(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('customShapes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('customShapes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
};
DxDiagramComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: DxTemplateHost },
    { type: WatcherHelper },
    { type: IterableDifferHelper },
    { type: NestedOptionHost },
    { type: TransferState },
    { type: undefined, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
];
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxDiagramComponent.prototype, "autoZoomMode", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "contextMenu", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "contextToolbox", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Array),
    tslib_1.__metadata("design:paramtypes", [Array])
], DxDiagramComponent.prototype, "customShapes", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "customShapeTemplate", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "customShapeToolboxTemplate", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "defaultItemProperties", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "disabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "edges", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "editing", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "elementAttr", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "export", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "fullScreen", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "gridSize", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "hasChanges", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "height", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "historyToolbar", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "mainToolbar", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "nodes", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxDiagramComponent.prototype, "pageColor", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxDiagramComponent.prototype, "pageOrientation", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "pageSize", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "propertiesPanel", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "readOnly", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "rtlEnabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "showGrid", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "simpleView", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "snapToGrid", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "toolbox", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxDiagramComponent.prototype, "units", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "viewToolbar", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxDiagramComponent.prototype, "viewUnits", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxDiagramComponent.prototype, "visible", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "width", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "zoomLevel", null);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onContentReady", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onCustomCommand", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onDisposing", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onInitialized", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onItemClick", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onItemDblClick", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onOptionChanged", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onRequestEditOperation", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onRequestLayoutUpdate", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "onSelectionChanged", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "autoZoomModeChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "contextMenuChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "contextToolboxChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "customShapesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "customShapeTemplateChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "customShapeToolboxTemplateChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "defaultItemPropertiesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "disabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "edgesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "editingChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "elementAttrChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "exportChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "fullScreenChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "gridSizeChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "hasChangesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "heightChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "historyToolbarChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "mainToolbarChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "nodesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "pageColorChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "pageOrientationChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "pageSizeChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "propertiesPanelChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "readOnlyChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "rtlEnabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "showGridChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "simpleViewChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "snapToGridChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "toolboxChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "unitsChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "viewToolbarChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "viewUnitsChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "visibleChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "widthChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxDiagramComponent.prototype, "zoomLevelChange", void 0);
tslib_1.__decorate([
    ContentChildren(DxiCustomShapeComponent),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxDiagramComponent.prototype, "customShapesChildren", null);
DxDiagramComponent = tslib_1.__decorate([
    Component({
        selector: 'dx-diagram',
        template: '',
        providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ]
    }),
    tslib_1.__param(7, Inject(PLATFORM_ID)),
    tslib_1.__metadata("design:paramtypes", [ElementRef, NgZone, DxTemplateHost,
        WatcherHelper,
        IterableDifferHelper,
        NestedOptionHost,
        TransferState, Object])
], DxDiagramComponent);
export { DxDiagramComponent };
let DxDiagramModule = class DxDiagramModule {
};
DxDiagramModule = tslib_1.__decorate([
    NgModule({
        imports: [
            DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxIntegrationModule,
            DxTemplateModule,
            BrowserTransferStateModule
        ],
        declarations: [
            DxDiagramComponent
        ],
        exports: [
            DxDiagramComponent,
            DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxTemplateModule
        ]
    })
], DxDiagramModule);
export { DxDiagramModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvdWkvZGlhZ3JhbS8iLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHOztBQUVILG9DQUFvQztBQUdwQyxPQUFPLEVBQUUsMEJBQTBCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUN2RSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFFMUQsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE1BQU0sRUFDTixXQUFXLEVBQ1gsTUFBTSxFQUVOLEtBQUssRUFDTCxNQUFNLEVBQ04sU0FBUyxFQUNULFlBQVksRUFDWixTQUFTLEVBQ1QsT0FBTyxFQUNQLGFBQWEsRUFDYixlQUFlLEVBQ2YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBS3ZCLE9BQU8sU0FBUyxNQUFNLHVCQUF1QixDQUFDO0FBRzlDLE9BQU8sRUFDSCxXQUFXLEVBQ1gsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2hCLE1BQU0seUJBQXlCLENBQUM7QUFFakMsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3BFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSw4QkFBOEIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDakUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdkUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFbEUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFJdkU7OztHQUdHO0FBV0gsSUFBYSxrQkFBa0IsR0FBL0IsTUFBYSxrQkFBbUIsU0FBUSxXQUFXO0lBNHhCL0MsWUFBWSxVQUFzQixFQUFFLE1BQWMsRUFBRSxZQUE0QixFQUNoRSxjQUE2QixFQUM3QixJQUEwQixFQUNsQyxVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFeEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFOdkUsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsU0FBSSxHQUFKLElBQUksQ0FBc0I7UUFPdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDdkQsRUFBRSxTQUFTLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLHdCQUF3QixFQUFFO1lBQ3JFLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNuRSxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUU7WUFDckMsRUFBRSxJQUFJLEVBQUUsa0NBQWtDLEVBQUU7WUFDNUMsRUFBRSxJQUFJLEVBQUUsNkJBQTZCLEVBQUU7WUFDdkMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtZQUM3QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNqQyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNqQyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7U0FDOUIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBcDFCRDs7O09BR0c7SUFFSCxJQUFJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWE7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBNkY7UUFDekcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUF3STtRQUN2SixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWk3QjtRQUM5N0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFJLG1CQUFtQixDQUFDLEtBQVU7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSwwQkFBMEI7UUFDMUIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNELElBQUksMEJBQTBCLENBQUMsS0FBVTtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLHFCQUFxQjtRQUNyQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBSSxxQkFBcUIsQ0FBQyxLQUE2TjtRQUNuUCxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBc2xCO1FBQzVsQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUErUjtRQUN2UyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQStDO1FBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBeUQ7UUFDbEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFpQztRQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQTZGO1FBQzVHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBNkY7UUFDekcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBMnVCO1FBQ2p2QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFhO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBYTtRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQW1IO1FBQzVILElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBa1A7UUFDbFEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFjO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBdU87UUFDL08sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBYTtRQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUE2RjtRQUN6RyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFhO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBaUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBeUQ7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQTJVRCxJQUFJLG9CQUFvQjtRQUNwQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksb0JBQW9CLENBQUMsS0FBSztRQUMxQixJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBa0VTLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUV0QyxPQUFPLElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0QsV0FBVztRQUNQLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFZLEVBQUUsT0FBc0I7UUFDN0MsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFZLEVBQUUsS0FBVTtRQUMvQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDakQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztRQUUzRCxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDdEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0NBQ0osQ0FBQTs7WUFqRzJCLFVBQVU7WUFBVSxNQUFNO1lBQWdCLGNBQWM7WUFDaEQsYUFBYTtZQUN2QixvQkFBb0I7WUFDdEIsZ0JBQWdCO1lBQ2IsYUFBYTs0Q0FDM0IsTUFBTSxTQUFDLFdBQVc7O0FBenhCM0I7SUFEQyxLQUFLLEVBQUU7OztzREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7cURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3dEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7c0NBSWdCLEtBQUs7NkNBQUwsS0FBSztzREFENUI7QUFXRDtJQURDLEtBQUssRUFBRTs7OzZEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztvRUFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7K0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2tEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OzsrQ0FHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7aURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3FEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztnREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7b0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2tEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztvREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7Z0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3dEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztxREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7K0NBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O21EQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7Ozt5REFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7a0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3lEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztrREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7b0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2tEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztvREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7b0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2lEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OzsrQ0FHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7cURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O21EQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztpREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7K0NBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O21EQUdQO0FBV1M7SUFBVCxNQUFNLEVBQUU7c0NBQWlCLFlBQVk7MERBQU07QUFRbEM7SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7MkRBQU07QUFRbkM7SUFBVCxNQUFNLEVBQUU7c0NBQWMsWUFBWTt1REFBTTtBQVEvQjtJQUFULE1BQU0sRUFBRTtzQ0FBZ0IsWUFBWTt5REFBTTtBQVFqQztJQUFULE1BQU0sRUFBRTtzQ0FBYyxZQUFZO3VEQUFNO0FBUS9CO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZOzBEQUFNO0FBUWxDO0lBQVQsTUFBTSxFQUFFO3NDQUFrQixZQUFZOzJEQUFNO0FBUW5DO0lBQVQsTUFBTSxFQUFFO3NDQUF5QixZQUFZO2tFQUFNO0FBUTFDO0lBQVQsTUFBTSxFQUFFO3NDQUF3QixZQUFZO2lFQUFNO0FBUXpDO0lBQVQsTUFBTSxFQUFFO3NDQUFxQixZQUFZOzhEQUFNO0FBT3RDO0lBQVQsTUFBTSxFQUFFO3NDQUFxQixZQUFZOzhEQUFTO0FBT3pDO0lBQVQsTUFBTSxFQUFFO3NDQUFvQixZQUFZOzZEQUF5RjtBQU94SDtJQUFULE1BQU0sRUFBRTtzQ0FBdUIsWUFBWTtnRUFBb0k7QUFPdEs7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7OERBQTY2QjtBQU83OEI7SUFBVCxNQUFNLEVBQUU7c0NBQTRCLFlBQVk7cUVBQU07QUFPN0M7SUFBVCxNQUFNLEVBQUU7c0NBQW1DLFlBQVk7NEVBQU07QUFPcEQ7SUFBVCxNQUFNLEVBQUU7c0NBQThCLFlBQVk7dUVBQXlOO0FBT2xRO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZOzBEQUFVO0FBT3RDO0lBQVQsTUFBTSxFQUFFO3NDQUFjLFlBQVk7dURBQWtsQjtBQU8zbUI7SUFBVCxNQUFNLEVBQUU7c0NBQWdCLFlBQVk7eURBQTJSO0FBT3RUO0lBQVQsTUFBTSxFQUFFO3NDQUFvQixZQUFZOzZEQUFNO0FBT3JDO0lBQVQsTUFBTSxFQUFFO3NDQUFlLFlBQVk7d0RBQTJDO0FBT3JFO0lBQVQsTUFBTSxFQUFFO3NDQUFtQixZQUFZOzREQUFVO0FBT3hDO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZOzBEQUFxRDtBQU9qRjtJQUFULE1BQU0sRUFBRTtzQ0FBbUIsWUFBWTs0REFBVTtBQU94QztJQUFULE1BQU0sRUFBRTtzQ0FBZSxZQUFZO3dEQUE2QjtBQU92RDtJQUFULE1BQU0sRUFBRTtzQ0FBdUIsWUFBWTtnRUFBeUY7QUFPM0g7SUFBVCxNQUFNLEVBQUU7c0NBQW9CLFlBQVk7NkRBQXlGO0FBT3hIO0lBQVQsTUFBTSxFQUFFO3NDQUFjLFlBQVk7dURBQXV1QjtBQU9od0I7SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7MkRBQVM7QUFPdEM7SUFBVCxNQUFNLEVBQUU7c0NBQXdCLFlBQVk7aUVBQVM7QUFPNUM7SUFBVCxNQUFNLEVBQUU7c0NBQWlCLFlBQVk7MERBQStHO0FBTzNJO0lBQVQsTUFBTSxFQUFFO3NDQUF3QixZQUFZO2lFQUE4TztBQU9qUjtJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTswREFBVTtBQU90QztJQUFULE1BQU0sRUFBRTtzQ0FBbUIsWUFBWTs0REFBVTtBQU94QztJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTswREFBVTtBQU90QztJQUFULE1BQU0sRUFBRTtzQ0FBbUIsWUFBWTs0REFBVTtBQU94QztJQUFULE1BQU0sRUFBRTtzQ0FBbUIsWUFBWTs0REFBVTtBQU94QztJQUFULE1BQU0sRUFBRTtzQ0FBZ0IsWUFBWTt5REFBbU87QUFPOVA7SUFBVCxNQUFNLEVBQUU7c0NBQWMsWUFBWTt1REFBUztBQU9sQztJQUFULE1BQU0sRUFBRTtzQ0FBb0IsWUFBWTs2REFBeUY7QUFPeEg7SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7MkRBQVM7QUFPdEM7SUFBVCxNQUFNLEVBQUU7c0NBQWdCLFlBQVk7eURBQVU7QUFPckM7SUFBVCxNQUFNLEVBQUU7c0NBQWMsWUFBWTt1REFBNkI7QUFPdEQ7SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7MkRBQXFEO0FBTTVGO0lBREMsZUFBZSxDQUFDLHVCQUF1QixDQUFDO3NDQUNiLFNBQVM7OzhEQUVwQztBQXB4QlEsa0JBQWtCO0lBVjlCLFNBQVMsQ0FBQztRQUNQLFFBQVEsRUFBRSxZQUFZO1FBQ3RCLFFBQVEsRUFBRSxFQUFFO1FBQ1osU0FBUyxFQUFFO1lBQ1AsY0FBYztZQUNkLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsb0JBQW9CO1NBQ3ZCO0tBQ0osQ0FBQztJQWt5QlcsbUJBQUEsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFBOzZDQUxKLFVBQVUsRUFBVSxNQUFNLEVBQWdCLGNBQWM7UUFDaEQsYUFBYTtRQUN2QixvQkFBb0I7UUFDdEIsZ0JBQWdCO1FBQ2IsYUFBYTtHQWh5QjNCLGtCQUFrQixDQTYzQjlCO1NBNzNCWSxrQkFBa0I7QUF5N0IvQixJQUFhLGVBQWUsR0FBNUIsTUFBYSxlQUFlO0NBQUksQ0FBQTtBQUFuQixlQUFlO0lBMUQzQixRQUFRLENBQUM7UUFDUixPQUFPLEVBQUU7WUFDUCxvQkFBb0I7WUFDcEIsZ0JBQWdCO1lBQ2hCLGFBQWE7WUFDYix1QkFBdUI7WUFDdkIsb0JBQW9CO1lBQ3BCLHdCQUF3QjtZQUN4Qiw4QkFBOEI7WUFDOUIsY0FBYztZQUNkLGdCQUFnQjtZQUNoQixlQUFlO1lBQ2YsaUJBQWlCO1lBQ2pCLHVCQUF1QjtZQUN2QixvQkFBb0I7WUFDcEIsY0FBYztZQUNkLG1CQUFtQjtZQUNuQixpQkFBaUI7WUFDakIsd0JBQXdCO1lBQ3hCLFlBQVk7WUFDWixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtZQUNwQixrQkFBa0I7WUFDbEIsbUJBQW1CO1lBQ25CLGdCQUFnQjtZQUNoQiwwQkFBMEI7U0FDM0I7UUFDRCxZQUFZLEVBQUU7WUFDWixrQkFBa0I7U0FDbkI7UUFDRCxPQUFPLEVBQUU7WUFDUCxrQkFBa0I7WUFDbEIsb0JBQW9CO1lBQ3BCLGdCQUFnQjtZQUNoQixhQUFhO1lBQ2IsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQix3QkFBd0I7WUFDeEIsOEJBQThCO1lBQzlCLGNBQWM7WUFDZCxnQkFBZ0I7WUFDaEIsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQix1QkFBdUI7WUFDdkIsb0JBQW9CO1lBQ3BCLGNBQWM7WUFDZCxtQkFBbUI7WUFDbkIsaUJBQWlCO1lBQ2pCLHdCQUF3QjtZQUN4QixZQUFZO1lBQ1osY0FBYztZQUNkLGdCQUFnQjtZQUNoQixvQkFBb0I7WUFDcEIsa0JBQWtCO1lBQ2xCLGdCQUFnQjtTQUNqQjtLQUNGLENBQUM7R0FDVyxlQUFlLENBQUk7U0FBbkIsZUFBZSIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyMC4yLjEyXG4gKiBCdWlsZCBkYXRlOiBUdWUgT2N0IDE4IDIwMjJcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDIyIERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXHJcblxyXG5cclxuaW1wb3J0IHsgQnJvd3NlclRyYW5zZmVyU3RhdGVNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuaW1wb3J0IHsgVHJhbnNmZXJTdGF0ZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE5nTW9kdWxlLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIE5nWm9uZSxcclxuICAgIFBMQVRGT1JNX0lELFxyXG4gICAgSW5qZWN0LFxyXG5cclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgRG9DaGVjayxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBDb250ZW50Q2hpbGRyZW4sXHJcbiAgICBRdWVyeUxpc3RcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcblxyXG5pbXBvcnQgRGV2RXhwcmVzcyBmcm9tICdkZXZleHRyZW1lL2J1bmRsZXMvZHguYWxsJztcclxuXHJcbmltcG9ydCBEeERpYWdyYW0gZnJvbSAnZGV2ZXh0cmVtZS91aS9kaWFncmFtJztcclxuXHJcblxyXG5pbXBvcnQge1xyXG4gICAgRHhDb21wb25lbnQsXHJcbiAgICBEeFRlbXBsYXRlSG9zdCxcclxuICAgIER4SW50ZWdyYXRpb25Nb2R1bGUsXHJcbiAgICBEeFRlbXBsYXRlTW9kdWxlLFxyXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyLFxyXG4gICAgV2F0Y2hlckhlbHBlclxyXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IER4b0NvbnRleHRNZW51TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4aUNvbW1hbmRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhpSXRlbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9Db250ZXh0VG9vbGJveE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlDdXN0b21TaGFwZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlDb25uZWN0aW9uUG9pbnRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvRGVmYXVsdEl0ZW1Qcm9wZXJ0aWVzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0VkZ2VzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0VkaXRpbmdNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvRXhwb3J0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0dyaWRTaXplTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0hpc3RvcnlUb29sYmFyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b01haW5Ub29sYmFyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b05vZGVzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0F1dG9MYXlvdXRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvUGFnZVNpemVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvUHJvcGVydGllc1BhbmVsTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4aVRhYk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlHcm91cE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9Ub29sYm94TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b1ZpZXdUb29sYmFyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b1pvb21MZXZlbE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5cclxuaW1wb3J0IHsgRHhpQ3VzdG9tU2hhcGVDb21wb25lbnQgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuXHJcblxyXG5cclxuLyoqXHJcbiAqIFtkZXNjcjpkeERpYWdyYW1dXHJcblxyXG4gKi9cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2R4LWRpYWdyYW0nLFxyXG4gICAgdGVtcGxhdGU6ICcnLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgRHhUZW1wbGF0ZUhvc3QsXHJcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcclxuICAgICAgICBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gICAgICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyXHJcbiAgICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEeERpYWdyYW1Db21wb25lbnQgZXh0ZW5kcyBEeENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBEb0NoZWNrIHtcclxuICAgIGluc3RhbmNlOiBEeERpYWdyYW07XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuYXV0b1pvb21Nb2RlXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgYXV0b1pvb21Nb2RlKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYXV0b1pvb21Nb2RlJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgYXV0b1pvb21Nb2RlKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2F1dG9ab29tTW9kZScsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuY29udGV4dE1lbnVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBjb250ZXh0TWVudSgpOiB7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgZW5hYmxlZD86IGJvb2xlYW4gfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29udGV4dE1lbnUnKTtcclxuICAgIH1cclxuICAgIHNldCBjb250ZXh0TWVudSh2YWx1ZTogeyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIGVuYWJsZWQ/OiBib29sZWFuIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbnRleHRNZW51JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5jb250ZXh0VG9vbGJveF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGNvbnRleHRUb29sYm94KCk6IHsgY2F0ZWdvcnk/OiBzdHJpbmcsIGRpc3BsYXlNb2RlPzogc3RyaW5nLCBlbmFibGVkPzogYm9vbGVhbiwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hhcGVzPzogQXJyYXk8c3RyaW5nPiwgd2lkdGg/OiBudW1iZXIgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29udGV4dFRvb2xib3gnKTtcclxuICAgIH1cclxuICAgIHNldCBjb250ZXh0VG9vbGJveCh2YWx1ZTogeyBjYXRlZ29yeT86IHN0cmluZywgZGlzcGxheU1vZGU/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBzaGFwZUljb25zUGVyUm93PzogbnVtYmVyLCBzaGFwZXM/OiBBcnJheTxzdHJpbmc+LCB3aWR0aD86IG51bWJlciB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb250ZXh0VG9vbGJveCcsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuY3VzdG9tU2hhcGVzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgY3VzdG9tU2hhcGVzKCk6IEFycmF5PGFueSB8IHsgYWxsb3dFZGl0SW1hZ2U/OiBib29sZWFuLCBhbGxvd0VkaXRUZXh0PzogYm9vbGVhbiwgYWxsb3dSZXNpemU/OiBib29sZWFuLCBiYWNrZ3JvdW5kSW1hZ2VIZWlnaHQ/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZUxlZnQ/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZVRvb2xib3hVcmw/OiBzdHJpbmcsIGJhY2tncm91bmRJbWFnZVRvcD86IG51bWJlciwgYmFja2dyb3VuZEltYWdlVXJsPzogc3RyaW5nLCBiYWNrZ3JvdW5kSW1hZ2VXaWR0aD86IG51bWJlciwgYmFzZVR5cGU/OiBzdHJpbmcsIGNhdGVnb3J5Pzogc3RyaW5nLCBjb25uZWN0aW9uUG9pbnRzPzogQXJyYXk8YW55IHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0+LCBkZWZhdWx0SGVpZ2h0PzogbnVtYmVyLCBkZWZhdWx0SW1hZ2VVcmw/OiBzdHJpbmcsIGRlZmF1bHRUZXh0Pzogc3RyaW5nLCBkZWZhdWx0V2lkdGg/OiBudW1iZXIsIGltYWdlSGVpZ2h0PzogbnVtYmVyLCBpbWFnZUxlZnQ/OiBudW1iZXIsIGltYWdlVG9wPzogbnVtYmVyLCBpbWFnZVdpZHRoPzogbnVtYmVyLCBrZWVwUmF0aW9PbkF1dG9TaXplPzogYm9vbGVhbiwgbWF4SGVpZ2h0PzogbnVtYmVyLCBtYXhXaWR0aD86IG51bWJlciwgbWluSGVpZ2h0PzogbnVtYmVyLCBtaW5XaWR0aD86IG51bWJlciwgdGVtcGxhdGU/OiBhbnksIHRlbXBsYXRlSGVpZ2h0PzogbnVtYmVyLCB0ZW1wbGF0ZUxlZnQ/OiBudW1iZXIsIHRlbXBsYXRlVG9wPzogbnVtYmVyLCB0ZW1wbGF0ZVdpZHRoPzogbnVtYmVyLCB0ZXh0SGVpZ2h0PzogbnVtYmVyLCB0ZXh0TGVmdD86IG51bWJlciwgdGV4dFRvcD86IG51bWJlciwgdGV4dFdpZHRoPzogbnVtYmVyLCB0aXRsZT86IHN0cmluZywgdG9vbGJveFRlbXBsYXRlPzogYW55LCB0b29sYm94V2lkdGhUb0hlaWdodFJhdGlvPzogbnVtYmVyLCB0eXBlPzogc3RyaW5nIH0+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjdXN0b21TaGFwZXMnKTtcclxuICAgIH1cclxuICAgIHNldCBjdXN0b21TaGFwZXModmFsdWU6IEFycmF5PGFueSB8IHsgYWxsb3dFZGl0SW1hZ2U/OiBib29sZWFuLCBhbGxvd0VkaXRUZXh0PzogYm9vbGVhbiwgYWxsb3dSZXNpemU/OiBib29sZWFuLCBiYWNrZ3JvdW5kSW1hZ2VIZWlnaHQ/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZUxlZnQ/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZVRvb2xib3hVcmw/OiBzdHJpbmcsIGJhY2tncm91bmRJbWFnZVRvcD86IG51bWJlciwgYmFja2dyb3VuZEltYWdlVXJsPzogc3RyaW5nLCBiYWNrZ3JvdW5kSW1hZ2VXaWR0aD86IG51bWJlciwgYmFzZVR5cGU/OiBzdHJpbmcsIGNhdGVnb3J5Pzogc3RyaW5nLCBjb25uZWN0aW9uUG9pbnRzPzogQXJyYXk8YW55IHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0+LCBkZWZhdWx0SGVpZ2h0PzogbnVtYmVyLCBkZWZhdWx0SW1hZ2VVcmw/OiBzdHJpbmcsIGRlZmF1bHRUZXh0Pzogc3RyaW5nLCBkZWZhdWx0V2lkdGg/OiBudW1iZXIsIGltYWdlSGVpZ2h0PzogbnVtYmVyLCBpbWFnZUxlZnQ/OiBudW1iZXIsIGltYWdlVG9wPzogbnVtYmVyLCBpbWFnZVdpZHRoPzogbnVtYmVyLCBrZWVwUmF0aW9PbkF1dG9TaXplPzogYm9vbGVhbiwgbWF4SGVpZ2h0PzogbnVtYmVyLCBtYXhXaWR0aD86IG51bWJlciwgbWluSGVpZ2h0PzogbnVtYmVyLCBtaW5XaWR0aD86IG51bWJlciwgdGVtcGxhdGU/OiBhbnksIHRlbXBsYXRlSGVpZ2h0PzogbnVtYmVyLCB0ZW1wbGF0ZUxlZnQ/OiBudW1iZXIsIHRlbXBsYXRlVG9wPzogbnVtYmVyLCB0ZW1wbGF0ZVdpZHRoPzogbnVtYmVyLCB0ZXh0SGVpZ2h0PzogbnVtYmVyLCB0ZXh0TGVmdD86IG51bWJlciwgdGV4dFRvcD86IG51bWJlciwgdGV4dFdpZHRoPzogbnVtYmVyLCB0aXRsZT86IHN0cmluZywgdG9vbGJveFRlbXBsYXRlPzogYW55LCB0b29sYm94V2lkdGhUb0hlaWdodFJhdGlvPzogbnVtYmVyLCB0eXBlPzogc3RyaW5nIH0+KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjdXN0b21TaGFwZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLmN1c3RvbVNoYXBlVGVtcGxhdGVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBjdXN0b21TaGFwZVRlbXBsYXRlKCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY3VzdG9tU2hhcGVUZW1wbGF0ZScpO1xyXG4gICAgfVxyXG4gICAgc2V0IGN1c3RvbVNoYXBlVGVtcGxhdGUodmFsdWU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY3VzdG9tU2hhcGVUZW1wbGF0ZScsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBjdXN0b21TaGFwZVRvb2xib3hUZW1wbGF0ZSgpOiBhbnkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2N1c3RvbVNoYXBlVG9vbGJveFRlbXBsYXRlJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGUodmFsdWU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGUnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLmRlZmF1bHRJdGVtUHJvcGVydGllc11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGRlZmF1bHRJdGVtUHJvcGVydGllcygpOiB7IGNvbm5lY3RvckxpbmVFbmQ/OiBzdHJpbmcsIGNvbm5lY3RvckxpbmVTdGFydD86IHN0cmluZywgY29ubmVjdG9yTGluZVR5cGU/OiBzdHJpbmcsIHNoYXBlTWF4SGVpZ2h0PzogbnVtYmVyLCBzaGFwZU1heFdpZHRoPzogbnVtYmVyLCBzaGFwZU1pbkhlaWdodD86IG51bWJlciwgc2hhcGVNaW5XaWR0aD86IG51bWJlciwgc3R5bGU/OiBhbnksIHRleHRTdHlsZT86IGFueSB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkZWZhdWx0SXRlbVByb3BlcnRpZXMnKTtcclxuICAgIH1cclxuICAgIHNldCBkZWZhdWx0SXRlbVByb3BlcnRpZXModmFsdWU6IHsgY29ubmVjdG9yTGluZUVuZD86IHN0cmluZywgY29ubmVjdG9yTGluZVN0YXJ0Pzogc3RyaW5nLCBjb25uZWN0b3JMaW5lVHlwZT86IHN0cmluZywgc2hhcGVNYXhIZWlnaHQ/OiBudW1iZXIsIHNoYXBlTWF4V2lkdGg/OiBudW1iZXIsIHNoYXBlTWluSGVpZ2h0PzogbnVtYmVyLCBzaGFwZU1pbldpZHRoPzogbnVtYmVyLCBzdHlsZT86IGFueSwgdGV4dFN0eWxlPzogYW55IH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2RlZmF1bHRJdGVtUHJvcGVydGllcycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6V2lkZ2V0Lk9wdGlvbnMuZGlzYWJsZWRdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNhYmxlZCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IGRpc2FibGVkKHZhbHVlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkaXNhYmxlZCcsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuZWRnZXNdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBlZGdlcygpOiB7IGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGZyb21FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGZyb21MaW5lRW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBmcm9tUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsaW5lVHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbG9ja2VkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwb2ludHNFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0U3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0b0xpbmVFbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgekluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VkZ2VzJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgZWRnZXModmFsdWU6IHsgY3VzdG9tRGF0YUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55PiwgZnJvbUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgZnJvbUxpbmVFbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGZyb21Qb2ludEluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGxpbmVUeXBlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsb2NrZWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHBvaW50c0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgc3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRTdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdG9FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvTGluZUVuZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdG9Qb2ludEluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB6SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWRnZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLmVkaXRpbmddXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBlZGl0aW5nKCk6IHsgYWxsb3dBZGRTaGFwZT86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdGlvbj86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdG9yUG9pbnRzPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0b3JUZXh0PzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VTaGFwZVRleHQ/OiBib29sZWFuLCBhbGxvd0RlbGV0ZUNvbm5lY3Rvcj86IGJvb2xlYW4sIGFsbG93RGVsZXRlU2hhcGU/OiBib29sZWFuLCBhbGxvd01vdmVTaGFwZT86IGJvb2xlYW4sIGFsbG93UmVzaXplU2hhcGU/OiBib29sZWFuIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VkaXRpbmcnKTtcclxuICAgIH1cclxuICAgIHNldCBlZGl0aW5nKHZhbHVlOiB7IGFsbG93QWRkU2hhcGU/OiBib29sZWFuLCBhbGxvd0NoYW5nZUNvbm5lY3Rpb24/OiBib29sZWFuLCBhbGxvd0NoYW5nZUNvbm5lY3RvclBvaW50cz86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdG9yVGV4dD86IGJvb2xlYW4sIGFsbG93Q2hhbmdlU2hhcGVUZXh0PzogYm9vbGVhbiwgYWxsb3dEZWxldGVDb25uZWN0b3I/OiBib29sZWFuLCBhbGxvd0RlbGV0ZVNoYXBlPzogYm9vbGVhbiwgYWxsb3dNb3ZlU2hhcGU/OiBib29sZWFuLCBhbGxvd1Jlc2l6ZVNoYXBlPzogYm9vbGVhbiB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlZGl0aW5nJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy5lbGVtZW50QXR0cl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGVsZW1lbnRBdHRyKCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcclxuICAgIH1cclxuICAgIHNldCBlbGVtZW50QXR0cih2YWx1ZTogYW55KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuZXhwb3J0XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZXhwb3J0KCk6IHsgZmlsZU5hbWU/OiBzdHJpbmcsIHByb3h5VXJsPzogc3RyaW5nIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2V4cG9ydCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IGV4cG9ydCh2YWx1ZTogeyBmaWxlTmFtZT86IHN0cmluZywgcHJveHlVcmw/OiBzdHJpbmcgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZXhwb3J0JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5mdWxsU2NyZWVuXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZnVsbFNjcmVlbigpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmdWxsU2NyZWVuJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgZnVsbFNjcmVlbih2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZnVsbFNjcmVlbicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuZ3JpZFNpemVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBncmlkU2l6ZSgpOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZ3JpZFNpemUnKTtcclxuICAgIH1cclxuICAgIHNldCBncmlkU2l6ZSh2YWx1ZTogbnVtYmVyIHwgeyBpdGVtcz86IEFycmF5PG51bWJlcj4sIHZhbHVlPzogbnVtYmVyIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2dyaWRTaXplJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5oYXNDaGFuZ2VzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgaGFzQ2hhbmdlcygpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoYXNDaGFuZ2VzJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgaGFzQ2hhbmdlcyh2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGFzQ2hhbmdlcycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50Lk9wdGlvbnMuaGVpZ2h0XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgaGVpZ2h0KCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoZWlnaHQnKTtcclxuICAgIH1cclxuICAgIHNldCBoZWlnaHQodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoZWlnaHQnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLmhpc3RvcnlUb29sYmFyXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgaGlzdG9yeVRvb2xiYXIoKTogeyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIHZpc2libGU/OiBib29sZWFuIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hpc3RvcnlUb29sYmFyJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgaGlzdG9yeVRvb2xiYXIodmFsdWU6IHsgY29tbWFuZHM/OiBBcnJheTxEZXZFeHByZXNzLnVpLmR4RGlhZ3JhbUN1c3RvbUNvbW1hbmQgfCBzdHJpbmc+LCB2aXNpYmxlPzogYm9vbGVhbiB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoaXN0b3J5VG9vbGJhcicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMubWFpblRvb2xiYXJdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBtYWluVG9vbGJhcigpOiB7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgdmlzaWJsZT86IGJvb2xlYW4gfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbWFpblRvb2xiYXInKTtcclxuICAgIH1cclxuICAgIHNldCBtYWluVG9vbGJhcih2YWx1ZTogeyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIHZpc2libGU/OiBib29sZWFuIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21haW5Ub29sYmFyJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5ub2Rlc11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IG5vZGVzKCk6IHsgYXV0b0xheW91dD86IHN0cmluZyB8IHsgb3JpZW50YXRpb24/OiBzdHJpbmcsIHR5cGU/OiBzdHJpbmcgfSwgYXV0b1NpemVFbmFibGVkPzogYm9vbGVhbiwgY29udGFpbmVyQ2hpbGRyZW5FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGNvbnRhaW5lcktleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgY3VzdG9tRGF0YUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55PiwgaGVpZ2h0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBpbWFnZVVybEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgaXRlbXNFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbGVmdEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbG9ja2VkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwYXJlbnRLZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0U3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvcEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgd2lkdGhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHpJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdub2RlcycpO1xyXG4gICAgfVxyXG4gICAgc2V0IG5vZGVzKHZhbHVlOiB7IGF1dG9MYXlvdXQ/OiBzdHJpbmcgfCB7IG9yaWVudGF0aW9uPzogc3RyaW5nLCB0eXBlPzogc3RyaW5nIH0sIGF1dG9TaXplRW5hYmxlZD86IGJvb2xlYW4sIGNvbnRhaW5lckNoaWxkcmVuRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBjb250YWluZXJLZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGhlaWdodEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgaW1hZ2VVcmxFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGl0ZW1zRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGxlZnRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGxvY2tlZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcGFyZW50S2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dFN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0b3BFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHR5cGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHdpZHRoRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB6SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbm9kZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnBhZ2VDb2xvcl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHBhZ2VDb2xvcigpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3BhZ2VDb2xvcicpO1xyXG4gICAgfVxyXG4gICAgc2V0IHBhZ2VDb2xvcih2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwYWdlQ29sb3InLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnBhZ2VPcmllbnRhdGlvbl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHBhZ2VPcmllbnRhdGlvbigpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3BhZ2VPcmllbnRhdGlvbicpO1xyXG4gICAgfVxyXG4gICAgc2V0IHBhZ2VPcmllbnRhdGlvbih2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwYWdlT3JpZW50YXRpb24nLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnBhZ2VTaXplXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgcGFnZVNpemUoKTogeyBoZWlnaHQ/OiBudW1iZXIsIGl0ZW1zPzogQXJyYXk8YW55IHwgeyBoZWlnaHQ/OiBudW1iZXIsIHRleHQ/OiBzdHJpbmcsIHdpZHRoPzogbnVtYmVyIH0+LCB3aWR0aD86IG51bWJlciB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWdlU2l6ZScpO1xyXG4gICAgfVxyXG4gICAgc2V0IHBhZ2VTaXplKHZhbHVlOiB7IGhlaWdodD86IG51bWJlciwgaXRlbXM/OiBBcnJheTxhbnkgfCB7IGhlaWdodD86IG51bWJlciwgdGV4dD86IHN0cmluZywgd2lkdGg/OiBudW1iZXIgfT4sIHdpZHRoPzogbnVtYmVyIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhZ2VTaXplJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5wcm9wZXJ0aWVzUGFuZWxdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBwcm9wZXJ0aWVzUGFuZWwoKTogeyB0YWJzPzogQXJyYXk8YW55IHwgeyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIGdyb3Vwcz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxEZXZFeHByZXNzLnVpLmR4RGlhZ3JhbUN1c3RvbUNvbW1hbmQgfCBzdHJpbmc+LCB0aXRsZT86IHN0cmluZyB9PiwgdGl0bGU/OiBzdHJpbmcgfT4sIHZpc2liaWxpdHk/OiBzdHJpbmcgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncHJvcGVydGllc1BhbmVsJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgcHJvcGVydGllc1BhbmVsKHZhbHVlOiB7IHRhYnM/OiBBcnJheTxhbnkgfCB7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgZ3JvdXBzPzogQXJyYXk8YW55IHwgeyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIHRpdGxlPzogc3RyaW5nIH0+LCB0aXRsZT86IHN0cmluZyB9PiwgdmlzaWJpbGl0eT86IHN0cmluZyB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwcm9wZXJ0aWVzUGFuZWwnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnJlYWRPbmx5XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgcmVhZE9ubHkoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVhZE9ubHknKTtcclxuICAgIH1cclxuICAgIHNldCByZWFkT25seSh2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncmVhZE9ubHknLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudC5PcHRpb25zLnJ0bEVuYWJsZWRdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBydGxFbmFibGVkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3J0bEVuYWJsZWQnKTtcclxuICAgIH1cclxuICAgIHNldCBydGxFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdydGxFbmFibGVkJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5zaG93R3JpZF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHNob3dHcmlkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dHcmlkJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgc2hvd0dyaWQodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Nob3dHcmlkJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5zaW1wbGVWaWV3XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgc2ltcGxlVmlldygpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaW1wbGVWaWV3Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgc2ltcGxlVmlldyh2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2ltcGxlVmlldycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMuc25hcFRvR3JpZF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHNuYXBUb0dyaWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc25hcFRvR3JpZCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IHNuYXBUb0dyaWQodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NuYXBUb0dyaWQnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnRvb2xib3hdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCB0b29sYm94KCk6IHsgZ3JvdXBzPzogQXJyYXk8YW55IHwgc3RyaW5nIHwgeyBjYXRlZ29yeT86IHN0cmluZywgZGlzcGxheU1vZGU/OiBzdHJpbmcsIGV4cGFuZGVkPzogYm9vbGVhbiwgc2hhcGVzPzogQXJyYXk8c3RyaW5nPiwgdGl0bGU/OiBzdHJpbmcgfT4sIHNoYXBlSWNvbnNQZXJSb3c/OiBudW1iZXIsIHNob3dTZWFyY2g/OiBib29sZWFuLCB2aXNpYmlsaXR5Pzogc3RyaW5nLCB3aWR0aD86IG51bWJlciB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b29sYm94Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgdG9vbGJveCh2YWx1ZTogeyBncm91cHM/OiBBcnJheTxhbnkgfCBzdHJpbmcgfCB7IGNhdGVnb3J5Pzogc3RyaW5nLCBkaXNwbGF5TW9kZT86IHN0cmluZywgZXhwYW5kZWQ/OiBib29sZWFuLCBzaGFwZXM/OiBBcnJheTxzdHJpbmc+LCB0aXRsZT86IHN0cmluZyB9Piwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hvd1NlYXJjaD86IGJvb2xlYW4sIHZpc2liaWxpdHk/OiBzdHJpbmcsIHdpZHRoPzogbnVtYmVyIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rvb2xib3gnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnVuaXRzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgdW5pdHMoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd1bml0cycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHVuaXRzKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3VuaXRzJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy52aWV3VG9vbGJhcl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHZpZXdUb29sYmFyKCk6IHsgY29tbWFuZHM/OiBBcnJheTxEZXZFeHByZXNzLnVpLmR4RGlhZ3JhbUN1c3RvbUNvbW1hbmQgfCBzdHJpbmc+LCB2aXNpYmxlPzogYm9vbGVhbiB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aWV3VG9vbGJhcicpO1xyXG4gICAgfVxyXG4gICAgc2V0IHZpZXdUb29sYmFyKHZhbHVlOiB7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgdmlzaWJsZT86IGJvb2xlYW4gfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlld1Rvb2xiYXInLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnZpZXdVbml0c11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHZpZXdVbml0cygpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZpZXdVbml0cycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHZpZXdVbml0cyh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2aWV3VW5pdHMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOldpZGdldC5PcHRpb25zLnZpc2libGVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Zpc2libGUnKTtcclxuICAgIH1cclxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2aXNpYmxlJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy53aWR0aF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHdpZHRoKCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd3aWR0aCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IHdpZHRoKHZhbHVlOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignd2lkdGgnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbS5PcHRpb25zLnpvb21MZXZlbF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHpvb21MZXZlbCgpOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignem9vbUxldmVsJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgem9vbUxldmVsKHZhbHVlOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignem9vbUxldmVsJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6V2lkZ2V0Lk9wdGlvbnMub25Db250ZW50UmVhZHldXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25Db250ZW50UmVhZHk6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMub25DdXN0b21Db21tYW5kXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uQ3VzdG9tQ29tbWFuZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy5vbkRpc3Bvc2luZ11cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvbkRpc3Bvc2luZzogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpDb21wb25lbnQuT3B0aW9ucy5vbkluaXRpYWxpemVkXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uSW5pdGlhbGl6ZWQ6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMub25JdGVtQ2xpY2tdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25JdGVtQ2xpY2s6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMub25JdGVtRGJsQ2xpY2tdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25JdGVtRGJsQ2xpY2s6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50Lk9wdGlvbnMub25PcHRpb25DaGFuZ2VkXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5vblJlcXVlc3RFZGl0T3BlcmF0aW9uXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVxdWVzdEVkaXRPcGVyYXRpb246IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtLk9wdGlvbnMub25SZXF1ZXN0TGF5b3V0VXBkYXRlXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVxdWVzdExheW91dFVwZGF0ZTogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeERpYWdyYW0uT3B0aW9ucy5vblNlbGVjdGlvbkNoYW5nZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25TZWxlY3Rpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgYXV0b1pvb21Nb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgY29udGV4dE1lbnVDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgZW5hYmxlZD86IGJvb2xlYW4gfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGNvbnRleHRUb29sYm94Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjYXRlZ29yeT86IHN0cmluZywgZGlzcGxheU1vZGU/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBzaGFwZUljb25zUGVyUm93PzogbnVtYmVyLCBzaGFwZXM/OiBBcnJheTxzdHJpbmc+LCB3aWR0aD86IG51bWJlciB9PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgY3VzdG9tU2hhcGVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55IHwgeyBhbGxvd0VkaXRJbWFnZT86IGJvb2xlYW4sIGFsbG93RWRpdFRleHQ/OiBib29sZWFuLCBhbGxvd1Jlc2l6ZT86IGJvb2xlYW4sIGJhY2tncm91bmRJbWFnZUhlaWdodD86IG51bWJlciwgYmFja2dyb3VuZEltYWdlTGVmdD86IG51bWJlciwgYmFja2dyb3VuZEltYWdlVG9vbGJveFVybD86IHN0cmluZywgYmFja2dyb3VuZEltYWdlVG9wPzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VVcmw/OiBzdHJpbmcsIGJhY2tncm91bmRJbWFnZVdpZHRoPzogbnVtYmVyLCBiYXNlVHlwZT86IHN0cmluZywgY2F0ZWdvcnk/OiBzdHJpbmcsIGNvbm5lY3Rpb25Qb2ludHM/OiBBcnJheTxhbnkgfCB7IHg/OiBudW1iZXIsIHk/OiBudW1iZXIgfT4sIGRlZmF1bHRIZWlnaHQ/OiBudW1iZXIsIGRlZmF1bHRJbWFnZVVybD86IHN0cmluZywgZGVmYXVsdFRleHQ/OiBzdHJpbmcsIGRlZmF1bHRXaWR0aD86IG51bWJlciwgaW1hZ2VIZWlnaHQ/OiBudW1iZXIsIGltYWdlTGVmdD86IG51bWJlciwgaW1hZ2VUb3A/OiBudW1iZXIsIGltYWdlV2lkdGg/OiBudW1iZXIsIGtlZXBSYXRpb09uQXV0b1NpemU/OiBib29sZWFuLCBtYXhIZWlnaHQ/OiBudW1iZXIsIG1heFdpZHRoPzogbnVtYmVyLCBtaW5IZWlnaHQ/OiBudW1iZXIsIG1pbldpZHRoPzogbnVtYmVyLCB0ZW1wbGF0ZT86IGFueSwgdGVtcGxhdGVIZWlnaHQ/OiBudW1iZXIsIHRlbXBsYXRlTGVmdD86IG51bWJlciwgdGVtcGxhdGVUb3A/OiBudW1iZXIsIHRlbXBsYXRlV2lkdGg/OiBudW1iZXIsIHRleHRIZWlnaHQ/OiBudW1iZXIsIHRleHRMZWZ0PzogbnVtYmVyLCB0ZXh0VG9wPzogbnVtYmVyLCB0ZXh0V2lkdGg/OiBudW1iZXIsIHRpdGxlPzogc3RyaW5nLCB0b29sYm94VGVtcGxhdGU/OiBhbnksIHRvb2xib3hXaWR0aFRvSGVpZ2h0UmF0aW8/OiBudW1iZXIsIHR5cGU/OiBzdHJpbmcgfT4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBjdXN0b21TaGFwZVRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBkZWZhdWx0SXRlbVByb3BlcnRpZXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbm5lY3RvckxpbmVFbmQ/OiBzdHJpbmcsIGNvbm5lY3RvckxpbmVTdGFydD86IHN0cmluZywgY29ubmVjdG9yTGluZVR5cGU/OiBzdHJpbmcsIHNoYXBlTWF4SGVpZ2h0PzogbnVtYmVyLCBzaGFwZU1heFdpZHRoPzogbnVtYmVyLCBzaGFwZU1pbkhlaWdodD86IG51bWJlciwgc2hhcGVNaW5XaWR0aD86IG51bWJlciwgc3R5bGU/OiBhbnksIHRleHRTdHlsZT86IGFueSB9PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZGlzYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZWRnZXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGZyb21FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGZyb21MaW5lRW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBmcm9tUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsaW5lVHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbG9ja2VkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwb2ludHNFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0U3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0b0xpbmVFbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRvUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgekluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBlZGl0aW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhbGxvd0FkZFNoYXBlPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0aW9uPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0b3JQb2ludHM/OiBib29sZWFuLCBhbGxvd0NoYW5nZUNvbm5lY3RvclRleHQ/OiBib29sZWFuLCBhbGxvd0NoYW5nZVNoYXBlVGV4dD86IGJvb2xlYW4sIGFsbG93RGVsZXRlQ29ubmVjdG9yPzogYm9vbGVhbiwgYWxsb3dEZWxldGVTaGFwZT86IGJvb2xlYW4sIGFsbG93TW92ZVNoYXBlPzogYm9vbGVhbiwgYWxsb3dSZXNpemVTaGFwZT86IGJvb2xlYW4gfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGVsZW1lbnRBdHRyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZXhwb3J0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBmaWxlTmFtZT86IHN0cmluZywgcHJveHlVcmw/OiBzdHJpbmcgfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGZ1bGxTY3JlZW5DaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZ3JpZFNpemVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGhhc0NoYW5nZXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBoaXN0b3J5VG9vbGJhckNoYW5nZTogRXZlbnRFbWl0dGVyPHsgY29tbWFuZHM/OiBBcnJheTxEZXZFeHByZXNzLnVpLmR4RGlhZ3JhbUN1c3RvbUNvbW1hbmQgfCBzdHJpbmc+LCB2aXNpYmxlPzogYm9vbGVhbiB9PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgbWFpblRvb2xiYXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgdmlzaWJsZT86IGJvb2xlYW4gfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG5vZGVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhdXRvTGF5b3V0Pzogc3RyaW5nIHwgeyBvcmllbnRhdGlvbj86IHN0cmluZywgdHlwZT86IHN0cmluZyB9LCBhdXRvU2l6ZUVuYWJsZWQ/OiBib29sZWFuLCBjb250YWluZXJDaGlsZHJlbkV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgY29udGFpbmVyS2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBjdXN0b21EYXRhRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBkYXRhU291cmNlPzogRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2UgfCBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZU9wdGlvbnMgfCBBcnJheTxhbnk+LCBoZWlnaHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGltYWdlVXJsRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBpdGVtc0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsZWZ0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsb2NrZWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHBhcmVudEtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgc3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRTdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdG9wRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0eXBlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB3aWR0aEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgekluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBwYWdlQ29sb3JDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBwYWdlT3JpZW50YXRpb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBwYWdlU2l6ZUNoYW5nZTogRXZlbnRFbWl0dGVyPHsgaGVpZ2h0PzogbnVtYmVyLCBpdGVtcz86IEFycmF5PGFueSB8IHsgaGVpZ2h0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nLCB3aWR0aD86IG51bWJlciB9Piwgd2lkdGg/OiBudW1iZXIgfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHByb3BlcnRpZXNQYW5lbENoYW5nZTogRXZlbnRFbWl0dGVyPHsgdGFicz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxEZXZFeHByZXNzLnVpLmR4RGlhZ3JhbUN1c3RvbUNvbW1hbmQgfCBzdHJpbmc+LCBncm91cHM/OiBBcnJheTxhbnkgfCB7IGNvbW1hbmRzPzogQXJyYXk8RGV2RXhwcmVzcy51aS5keERpYWdyYW1DdXN0b21Db21tYW5kIHwgc3RyaW5nPiwgdGl0bGU/OiBzdHJpbmcgfT4sIHRpdGxlPzogc3RyaW5nIH0+LCB2aXNpYmlsaXR5Pzogc3RyaW5nIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSByZWFkT25seUNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBydGxFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHNob3dHcmlkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHNpbXBsZVZpZXdDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgc25hcFRvR3JpZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB0b29sYm94Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBncm91cHM/OiBBcnJheTxhbnkgfCBzdHJpbmcgfCB7IGNhdGVnb3J5Pzogc3RyaW5nLCBkaXNwbGF5TW9kZT86IHN0cmluZywgZXhwYW5kZWQ/OiBib29sZWFuLCBzaGFwZXM/OiBBcnJheTxzdHJpbmc+LCB0aXRsZT86IHN0cmluZyB9Piwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hvd1NlYXJjaD86IGJvb2xlYW4sIHZpc2liaWxpdHk/OiBzdHJpbmcsIHdpZHRoPzogbnVtYmVyIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB1bml0c0NoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHZpZXdUb29sYmFyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb21tYW5kcz86IEFycmF5PERldkV4cHJlc3MudWkuZHhEaWFncmFtQ3VzdG9tQ29tbWFuZCB8IHN0cmluZz4sIHZpc2libGU/OiBib29sZWFuIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB2aWV3VW5pdHNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB2aXNpYmxlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHdpZHRoQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB6b29tTGV2ZWxDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfT47XHJcblxyXG5cclxuXHJcblxyXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlDdXN0b21TaGFwZUNvbXBvbmVudClcclxuICAgIGdldCBjdXN0b21TaGFwZXNDaGlsZHJlbigpOiBRdWVyeUxpc3Q8RHhpQ3VzdG9tU2hhcGVDb21wb25lbnQ+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjdXN0b21TaGFwZXMnKTtcclxuICAgIH1cclxuICAgIHNldCBjdXN0b21TaGFwZXNDaGlsZHJlbih2YWx1ZSkge1xyXG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2N1c3RvbVNoYXBlcycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG5cclxuXHJcbiAgICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBuZ1pvbmU6IE5nWm9uZSwgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcclxuICAgICAgICAgICAgcHJpdmF0ZSBfd2F0Y2hlckhlbHBlcjogV2F0Y2hlckhlbHBlcixcclxuICAgICAgICAgICAgcHJpdmF0ZSBfaWRoOiBJdGVyYWJsZURpZmZlckhlbHBlcixcclxuICAgICAgICAgICAgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgICAgICAgICAgdHJhbnNmZXJTdGF0ZTogVHJhbnNmZXJTdGF0ZSxcclxuICAgICAgICAgICAgQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogYW55KSB7XHJcblxyXG4gICAgICAgIHN1cGVyKGVsZW1lbnRSZWYsIG5nWm9uZSwgdGVtcGxhdGVIb3N0LCBfd2F0Y2hlckhlbHBlciwgdHJhbnNmZXJTdGF0ZSwgcGxhdGZvcm1JZCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NyZWF0ZUV2ZW50RW1pdHRlcnMoW1xyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NvbnRlbnRSZWFkeScsIGVtaXQ6ICdvbkNvbnRlbnRSZWFkeScgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjdXN0b21Db21tYW5kJywgZW1pdDogJ29uQ3VzdG9tQ29tbWFuZCcgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkaXNwb3NpbmcnLCBlbWl0OiAnb25EaXNwb3NpbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpdGVtQ2xpY2snLCBlbWl0OiAnb25JdGVtQ2xpY2snIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaXRlbURibENsaWNrJywgZW1pdDogJ29uSXRlbURibENsaWNrJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ29wdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25PcHRpb25DaGFuZ2VkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3JlcXVlc3RFZGl0T3BlcmF0aW9uJywgZW1pdDogJ29uUmVxdWVzdEVkaXRPcGVyYXRpb24nIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVxdWVzdExheW91dFVwZGF0ZScsIGVtaXQ6ICdvblJlcXVlc3RMYXlvdXRVcGRhdGUnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnc2VsZWN0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvblNlbGVjdGlvbkNoYW5nZWQnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2F1dG9ab29tTW9kZUNoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnY29udGV4dE1lbnVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2NvbnRleHRUb29sYm94Q2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdjdXN0b21TaGFwZXNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbVNoYXBlVGVtcGxhdGVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbVNoYXBlVG9vbGJveFRlbXBsYXRlQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdkZWZhdWx0SXRlbVByb3BlcnRpZXNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2Rpc2FibGVkQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdlZGdlc0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZWRpdGluZ0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZWxlbWVudEF0dHJDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2V4cG9ydENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZnVsbFNjcmVlbkNoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZ3JpZFNpemVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2hhc0NoYW5nZXNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2hlaWdodENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnaGlzdG9yeVRvb2xiYXJDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ21haW5Ub29sYmFyQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdub2Rlc0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAncGFnZUNvbG9yQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdwYWdlT3JpZW50YXRpb25DaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3BhZ2VTaXplQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdwcm9wZXJ0aWVzUGFuZWxDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3JlYWRPbmx5Q2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdydGxFbmFibGVkQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdzaG93R3JpZENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnc2ltcGxlVmlld0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnc25hcFRvR3JpZENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAndG9vbGJveENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAndW5pdHNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZpZXdUb29sYmFyQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICd2aWV3VW5pdHNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3dpZHRoQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICd6b29tTGV2ZWxDaGFuZ2UnIH1cclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgdGhpcy5faWRoLnNldEhvc3QodGhpcyk7XHJcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfY3JlYXRlSW5zdGFuY2UoZWxlbWVudCwgb3B0aW9ucykge1xyXG5cclxuICAgICAgICByZXR1cm4gbmV3IER4RGlhZ3JhbShlbGVtZW50LCBvcHRpb25zKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICAgICAgdGhpcy5fZGVzdHJveVdpZGdldCgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcclxuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnY3VzdG9tU2hhcGVzJywgY2hhbmdlcyk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0dXBDaGFuZ2VzKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG4gICAgICAgIGlmICghKHByb3AgaW4gdGhpcy5fb3B0aW9uc1RvVXBkYXRlKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9pZGguc2V0dXAocHJvcCwgY2hhbmdlcyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nRG9DaGVjaygpIHtcclxuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnY3VzdG9tU2hhcGVzJyk7XHJcbiAgICAgICAgdGhpcy5fd2F0Y2hlckhlbHBlci5jaGVja1dhdGNoZXJzKCk7XHJcbiAgICAgICAgc3VwZXIubmdEb0NoZWNrKCk7XHJcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xyXG4gICAgfVxyXG5cclxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XHJcbiAgICAgICAgbGV0IGlzU2V0dXAgPSB0aGlzLl9pZGguc2V0dXBTaW5nbGUobmFtZSwgdmFsdWUpO1xyXG4gICAgICAgIGxldCBpc0NoYW5nZWQgPSB0aGlzLl9pZGguZ2V0Q2hhbmdlcyhuYW1lLCB2YWx1ZSkgIT09IG51bGw7XHJcblxyXG4gICAgICAgIGlmIChpc1NldHVwIHx8IGlzQ2hhbmdlZCkge1xyXG4gICAgICAgICAgICBzdXBlci5fc2V0T3B0aW9uKG5hbWUsIHZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgaW1wb3J0czogW1xyXG4gICAgRHhvQ29udGV4dE1lbnVNb2R1bGUsXHJcbiAgICBEeGlDb21tYW5kTW9kdWxlLFxyXG4gICAgRHhpSXRlbU1vZHVsZSxcclxuICAgIER4b0NvbnRleHRUb29sYm94TW9kdWxlLFxyXG4gICAgRHhpQ3VzdG9tU2hhcGVNb2R1bGUsXHJcbiAgICBEeGlDb25uZWN0aW9uUG9pbnRNb2R1bGUsXHJcbiAgICBEeG9EZWZhdWx0SXRlbVByb3BlcnRpZXNNb2R1bGUsXHJcbiAgICBEeG9FZGdlc01vZHVsZSxcclxuICAgIER4b0VkaXRpbmdNb2R1bGUsXHJcbiAgICBEeG9FeHBvcnRNb2R1bGUsXHJcbiAgICBEeG9HcmlkU2l6ZU1vZHVsZSxcclxuICAgIER4b0hpc3RvcnlUb29sYmFyTW9kdWxlLFxyXG4gICAgRHhvTWFpblRvb2xiYXJNb2R1bGUsXHJcbiAgICBEeG9Ob2Rlc01vZHVsZSxcclxuICAgIER4b0F1dG9MYXlvdXRNb2R1bGUsXHJcbiAgICBEeG9QYWdlU2l6ZU1vZHVsZSxcclxuICAgIER4b1Byb3BlcnRpZXNQYW5lbE1vZHVsZSxcclxuICAgIER4aVRhYk1vZHVsZSxcclxuICAgIER4aUdyb3VwTW9kdWxlLFxyXG4gICAgRHhvVG9vbGJveE1vZHVsZSxcclxuICAgIER4b1ZpZXdUb29sYmFyTW9kdWxlLFxyXG4gICAgRHhvWm9vbUxldmVsTW9kdWxlLFxyXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcclxuICAgIER4VGVtcGxhdGVNb2R1bGUsXHJcbiAgICBCcm93c2VyVHJhbnNmZXJTdGF0ZU1vZHVsZVxyXG4gIF0sXHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBEeERpYWdyYW1Db21wb25lbnRcclxuICBdLFxyXG4gIGV4cG9ydHM6IFtcclxuICAgIER4RGlhZ3JhbUNvbXBvbmVudCxcclxuICAgIER4b0NvbnRleHRNZW51TW9kdWxlLFxyXG4gICAgRHhpQ29tbWFuZE1vZHVsZSxcclxuICAgIER4aUl0ZW1Nb2R1bGUsXHJcbiAgICBEeG9Db250ZXh0VG9vbGJveE1vZHVsZSxcclxuICAgIER4aUN1c3RvbVNoYXBlTW9kdWxlLFxyXG4gICAgRHhpQ29ubmVjdGlvblBvaW50TW9kdWxlLFxyXG4gICAgRHhvRGVmYXVsdEl0ZW1Qcm9wZXJ0aWVzTW9kdWxlLFxyXG4gICAgRHhvRWRnZXNNb2R1bGUsXHJcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxyXG4gICAgRHhvRXhwb3J0TW9kdWxlLFxyXG4gICAgRHhvR3JpZFNpemVNb2R1bGUsXHJcbiAgICBEeG9IaXN0b3J5VG9vbGJhck1vZHVsZSxcclxuICAgIER4b01haW5Ub29sYmFyTW9kdWxlLFxyXG4gICAgRHhvTm9kZXNNb2R1bGUsXHJcbiAgICBEeG9BdXRvTGF5b3V0TW9kdWxlLFxyXG4gICAgRHhvUGFnZVNpemVNb2R1bGUsXHJcbiAgICBEeG9Qcm9wZXJ0aWVzUGFuZWxNb2R1bGUsXHJcbiAgICBEeGlUYWJNb2R1bGUsXHJcbiAgICBEeGlHcm91cE1vZHVsZSxcclxuICAgIER4b1Rvb2xib3hNb2R1bGUsXHJcbiAgICBEeG9WaWV3VG9vbGJhck1vZHVsZSxcclxuICAgIER4b1pvb21MZXZlbE1vZHVsZSxcclxuICAgIER4VGVtcGxhdGVNb2R1bGVcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEeERpYWdyYW1Nb2R1bGUgeyB9XHJcbiJdfQ==