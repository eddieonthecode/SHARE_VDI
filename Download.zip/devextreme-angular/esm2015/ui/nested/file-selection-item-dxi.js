/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiFileManagerToolbarItem } from './base/file-manager-toolbar-item-dxi';
let DxiFileSelectionItemComponent = class DxiFileSelectionItemComponent extends DxiFileManagerToolbarItem {
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    get _optionPath() {
        return 'fileSelectionItems';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
};
DxiFileSelectionItemComponent.ctorParameters = () => [
    { type: NestedOptionHost, decorators: [{ type: SkipSelf }, { type: Host }] },
    { type: NestedOptionHost, decorators: [{ type: Host }] }
];
DxiFileSelectionItemComponent = tslib_1.__decorate([
    Component({
        selector: 'dxi-file-selection-item',
        template: '',
        providers: [NestedOptionHost],
        inputs: [
            'cssClass',
            'disabled',
            'icon',
            'locateInMenu',
            'location',
            'name',
            'options',
            'showText',
            'text',
            'visible',
            'widget'
        ],
        styles: ['']
    }),
    tslib_1.__param(0, SkipSelf()), tslib_1.__param(0, Host()),
    tslib_1.__param(1, Host()),
    tslib_1.__metadata("design:paramtypes", [NestedOptionHost,
        NestedOptionHost])
], DxiFileSelectionItemComponent);
export { DxiFileSelectionItemComponent };
let DxiFileSelectionItemModule = class DxiFileSelectionItemModule {
};
DxiFileSelectionItemModule = tslib_1.__decorate([
    NgModule({
        declarations: [
            DxiFileSelectionItemComponent
        ],
        exports: [
            DxiFileSelectionItemComponent
        ],
    })
], DxiFileSelectionItemModule);
export { DxiFileSelectionItemModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1zZWxlY3Rpb24taXRlbS1keGkuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkLyIsInNvdXJjZXMiOlsiZmlsZS1zZWxlY3Rpb24taXRlbS1keGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7O0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUNULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNYLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUseUJBQXlCLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQztBQXNCakYsSUFBYSw2QkFBNkIsR0FBMUMsTUFBYSw2QkFBOEIsU0FBUSx5QkFBeUI7SUFPeEUsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQVZELElBQWMsV0FBVztRQUNyQixPQUFPLG9CQUFvQixDQUFDO0lBQ2hDLENBQUM7SUFZRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7Q0FFSixDQUFBOztZQWJxRCxnQkFBZ0IsdUJBQXJELFFBQVEsWUFBSSxJQUFJO1lBQ0QsZ0JBQWdCLHVCQUFuQyxJQUFJOztBQVJKLDZCQUE2QjtJQW5CekMsU0FBUyxDQUFDO1FBQ1AsUUFBUSxFQUFFLHlCQUF5QjtRQUNuQyxRQUFRLEVBQUUsRUFBRTtRQUVaLFNBQVMsRUFBRSxDQUFDLGdCQUFnQixDQUFDO1FBQzdCLE1BQU0sRUFBRTtZQUNKLFVBQVU7WUFDVixVQUFVO1lBQ1YsTUFBTTtZQUNOLGNBQWM7WUFDZCxVQUFVO1lBQ1YsTUFBTTtZQUNOLFNBQVM7WUFDVCxVQUFVO1lBQ1YsTUFBTTtZQUNOLFNBQVM7WUFDVCxRQUFRO1NBQ1g7aUJBZFEsRUFBRTtLQWVkLENBQUM7SUFRZSxtQkFBQSxRQUFRLEVBQUUsQ0FBQSxFQUFFLG1CQUFBLElBQUksRUFBRSxDQUFBO0lBQ3RCLG1CQUFBLElBQUksRUFBRSxDQUFBOzZDQURtQyxnQkFBZ0I7UUFDdEMsZ0JBQWdCO0dBUm5DLDZCQUE2QixDQW9CekM7U0FwQlksNkJBQTZCO0FBOEIxQyxJQUFhLDBCQUEwQixHQUF2QyxNQUFhLDBCQUEwQjtDQUFJLENBQUE7QUFBOUIsMEJBQTBCO0lBUnRDLFFBQVEsQ0FBQztRQUNSLFlBQVksRUFBRTtZQUNaLDZCQUE2QjtTQUM5QjtRQUNELE9BQU8sRUFBRTtZQUNQLDZCQUE2QjtTQUM5QjtLQUNGLENBQUM7R0FDVywwQkFBMEIsQ0FBSTtTQUE5QiwwQkFBMEIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xyXG5cclxuLyogdHNsaW50OmRpc2FibGU6dXNlLWlucHV0LXByb3BlcnR5LWRlY29yYXRvciAqL1xyXG5cclxuaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE5nTW9kdWxlLFxyXG4gICAgSG9zdCxcclxuICAgIFNraXBTZWxmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5cclxuXHJcblxyXG5cclxuaW1wb3J0IHtcclxuICAgIE5lc3RlZE9wdGlvbkhvc3QsXHJcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBEeGlGaWxlTWFuYWdlclRvb2xiYXJJdGVtIH0gZnJvbSAnLi9iYXNlL2ZpbGUtbWFuYWdlci10b29sYmFyLWl0ZW0tZHhpJztcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnZHhpLWZpbGUtc2VsZWN0aW9uLWl0ZW0nLFxyXG4gICAgdGVtcGxhdGU6ICcnLFxyXG4gICAgc3R5bGVzOiBbJyddLFxyXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdF0sXHJcbiAgICBpbnB1dHM6IFtcclxuICAgICAgICAnY3NzQ2xhc3MnLFxyXG4gICAgICAgICdkaXNhYmxlZCcsXHJcbiAgICAgICAgJ2ljb24nLFxyXG4gICAgICAgICdsb2NhdGVJbk1lbnUnLFxyXG4gICAgICAgICdsb2NhdGlvbicsXHJcbiAgICAgICAgJ25hbWUnLFxyXG4gICAgICAgICdvcHRpb25zJyxcclxuICAgICAgICAnc2hvd1RleHQnLFxyXG4gICAgICAgICd0ZXh0JyxcclxuICAgICAgICAndmlzaWJsZScsXHJcbiAgICAgICAgJ3dpZGdldCdcclxuICAgIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIER4aUZpbGVTZWxlY3Rpb25JdGVtQ29tcG9uZW50IGV4dGVuZHMgRHhpRmlsZU1hbmFnZXJUb29sYmFySXRlbSB7XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcclxuICAgICAgICByZXR1cm4gJ2ZpbGVTZWxlY3Rpb25JdGVtcyc7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBTa2lwU2VsZigpIEBIb3N0KCkgcGFyZW50T3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICBwYXJlbnRPcHRpb25Ib3N0LnNldE5lc3RlZE9wdGlvbih0aGlzKTtcclxuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpIHtcclxuICAgICAgICB0aGlzLl9kZWxldGVSZW1vdmVkT3B0aW9ucyh0aGlzLl9mdWxsT3B0aW9uUGF0aCgpKTtcclxuICAgIH1cclxuXHJcbn1cclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBEeGlGaWxlU2VsZWN0aW9uSXRlbUNvbXBvbmVudFxyXG4gIF0sXHJcbiAgZXhwb3J0czogW1xyXG4gICAgRHhpRmlsZVNlbGVjdGlvbkl0ZW1Db21wb25lbnRcclxuICBdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgRHhpRmlsZVNlbGVjdGlvbkl0ZW1Nb2R1bGUgeyB9XHJcbiJdfQ==