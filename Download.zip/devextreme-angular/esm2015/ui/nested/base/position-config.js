/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
export class DxoPositionConfig extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9zaXRpb24tY29uZmlnLmpzIiwic291cmNlUm9vdCI6Im5nOi8vZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZC8iLCJzb3VyY2VzIjpbImJhc2UvcG9zaXRpb24tY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUd2RCxNQUFNLE9BQWdCLGlCQUFrQixTQUFRLFlBQVk7SUFDeEQsSUFBSSxFQUFFO1FBQ0YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxJQUFJLEVBQUUsQ0FBQyxLQUEwQztRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUF5QztRQUNsRCxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsSUFBSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQTBDO1FBQ3pELElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELElBQUksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBMEM7UUFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELElBQUksRUFBRTtRQUNGLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ0QsSUFBSSxFQUFFLENBQUMsS0FBMEM7UUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVELElBQUksRUFBRTtRQUNGLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ0QsSUFBSSxFQUFFLENBQUMsS0FBeUM7UUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVELElBQUksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBMEM7UUFDakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDIwLjIuMTJcbiAqIEJ1aWxkIGRhdGU6IFR1ZSBPY3QgMTggMjAyMlxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjIgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cclxuXHJcbmltcG9ydCB7IE5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcclxuXHJcblxyXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgRHhvUG9zaXRpb25Db25maWcgZXh0ZW5kcyBOZXN0ZWRPcHRpb24ge1xyXG4gICAgZ2V0IGF0KCk6IHN0cmluZyB8IHsgeD86IHN0cmluZywgeT86IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhdCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IGF0KHZhbHVlOiBzdHJpbmcgfCB7IHg/OiBzdHJpbmcsIHk/OiBzdHJpbmcgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYXQnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IGJvdW5kYXJ5KCk6IEVsZW1lbnQgfCBKUXVlcnkgfCBzdHJpbmcgfCBXaW5kb3cge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JvdW5kYXJ5Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgYm91bmRhcnkodmFsdWU6IEVsZW1lbnQgfCBKUXVlcnkgfCBzdHJpbmcgfCBXaW5kb3cpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JvdW5kYXJ5JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGdldCBib3VuZGFyeU9mZnNldCgpOiBzdHJpbmcgfCB7IHg/OiBudW1iZXIsIHk/OiBudW1iZXIgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYm91bmRhcnlPZmZzZXQnKTtcclxuICAgIH1cclxuICAgIHNldCBib3VuZGFyeU9mZnNldCh2YWx1ZTogc3RyaW5nIHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JvdW5kYXJ5T2Zmc2V0JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGdldCBjb2xsaXNpb24oKTogc3RyaW5nIHwgeyB4Pzogc3RyaW5nLCB5Pzogc3RyaW5nIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbGxpc2lvbicpO1xyXG4gICAgfVxyXG4gICAgc2V0IGNvbGxpc2lvbih2YWx1ZTogc3RyaW5nIHwgeyB4Pzogc3RyaW5nLCB5Pzogc3RyaW5nIH0pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbGxpc2lvbicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXQgbXkoKTogc3RyaW5nIHwgeyB4Pzogc3RyaW5nLCB5Pzogc3RyaW5nIH0ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ215Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgbXkodmFsdWU6IHN0cmluZyB8IHsgeD86IHN0cmluZywgeT86IHN0cmluZyB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdteScsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXQgb2YoKTogRWxlbWVudCB8IEpRdWVyeSB8IHN0cmluZyB8IFdpbmRvdyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb2YnKTtcclxuICAgIH1cclxuICAgIHNldCBvZih2YWx1ZTogRWxlbWVudCB8IEpRdWVyeSB8IHN0cmluZyB8IFdpbmRvdykge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignb2YnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IG9mZnNldCgpOiBzdHJpbmcgfCB7IHg/OiBudW1iZXIsIHk/OiBudW1iZXIgfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb2Zmc2V0Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgb2Zmc2V0KHZhbHVlOiBzdHJpbmcgfCB7IHg/OiBudW1iZXIsIHk/OiBudW1iZXIgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignb2Zmc2V0JywgdmFsdWUpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==