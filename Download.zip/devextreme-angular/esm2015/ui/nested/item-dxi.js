/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
var DxiItemComponent_1;
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, ElementRef, Renderer2, Inject, AfterViewInit, SkipSelf, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { NestedOptionHost, extractTemplate, DxTemplateDirective, IDxTemplateHost, DxTemplateHost } from 'devextreme-angular/core';
import { DxiButtonGroupItem } from './base/button-group-item-dxi';
import { DxiValidationRuleComponent } from './validation-rule-dxi';
import { DxiTabComponent } from './tab-dxi';
import { DxiLocationComponent } from './location-dxi';
let DxiItemComponent = DxiItemComponent_1 = class DxiItemComponent extends DxiButtonGroupItem {
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    get _optionPath() {
        return 'items';
    }
    get itemsChildren() {
        return this._getOption('items');
    }
    set itemsChildren(value) {
        this.setChildren('items', value);
    }
    get validationRulesChildren() {
        return this._getOption('validationRules');
    }
    set validationRulesChildren(value) {
        this.setChildren('validationRules', value);
    }
    get tabsChildren() {
        return this._getOption('tabs');
    }
    set tabsChildren(value) {
        this.setChildren('tabs', value);
    }
    get locationChildren() {
        return this._getOption('location');
    }
    set locationChildren(value) {
        this.setChildren('location', value);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
};
DxiItemComponent.ctorParameters = () => [
    { type: NestedOptionHost, decorators: [{ type: SkipSelf }, { type: Host }] },
    { type: NestedOptionHost, decorators: [{ type: Host }] },
    { type: Renderer2 },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] },
    { type: DxTemplateHost, decorators: [{ type: Host }] },
    { type: ElementRef }
];
tslib_1.__decorate([
    ContentChildren(forwardRef(() => DxiItemComponent_1)),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxiItemComponent.prototype, "itemsChildren", null);
tslib_1.__decorate([
    ContentChildren(forwardRef(() => DxiValidationRuleComponent)),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxiItemComponent.prototype, "validationRulesChildren", null);
tslib_1.__decorate([
    ContentChildren(forwardRef(() => DxiTabComponent)),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxiItemComponent.prototype, "tabsChildren", null);
tslib_1.__decorate([
    ContentChildren(forwardRef(() => DxiLocationComponent)),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxiItemComponent.prototype, "locationChildren", null);
DxiItemComponent = DxiItemComponent_1 = tslib_1.__decorate([
    Component({
        selector: 'dxi-item',
        template: '<ng-content></ng-content>',
        providers: [NestedOptionHost, DxTemplateHost],
        inputs: [
            'disabled',
            'html',
            'icon',
            'template',
            'text',
            'title',
            'visible',
            'onClick',
            'type',
            'baseSize',
            'box',
            'ratio',
            'shrink',
            'hint',
            'beginGroup',
            'closeMenuOnClick',
            'items',
            'selectable',
            'selected',
            'colSpan',
            'cssClass',
            'dataField',
            'editorOptions',
            'editorType',
            'helpText',
            'isRequired',
            'itemType',
            'label',
            'name',
            'validationRules',
            'visibleIndex',
            'alignItemLabels',
            'caption',
            'colCount',
            'colCountByScreen',
            'tabPanelOptions',
            'tabs',
            'badge',
            'tabTemplate',
            'buttonOptions',
            'horizontalAlignment',
            'verticalAlignment',
            'height',
            'width',
            'locateInMenu',
            'location',
            'options',
            'showText',
            'widget',
            'imageAlt',
            'imageSrc',
            'menuItemTemplate',
            'formatName',
            'formatValues',
            'key',
            'showChevron',
            'menuTemplate',
            'heightRatio',
            'widthRatio',
            'expanded',
            'hasItems',
            'id',
            'parentId'
        ],
        styles: [':host { display: block; }']
    }),
    tslib_1.__param(0, SkipSelf()), tslib_1.__param(0, Host()),
    tslib_1.__param(1, Host()),
    tslib_1.__param(3, Inject(DOCUMENT)),
    tslib_1.__param(4, Host()),
    tslib_1.__metadata("design:paramtypes", [NestedOptionHost,
        NestedOptionHost,
        Renderer2, Object, DxTemplateHost,
        ElementRef])
], DxiItemComponent);
export { DxiItemComponent };
let DxiItemModule = class DxiItemModule {
};
DxiItemModule = tslib_1.__decorate([
    NgModule({
        declarations: [
            DxiItemComponent
        ],
        exports: [
            DxiItemComponent
        ],
    })
], DxiItemModule);
export { DxiItemModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1keGkuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkLyIsInNvdXJjZXMiOlsiaXRlbS1keGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7OztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFVBQVUsRUFDVixTQUFTLEVBQ1QsTUFBTSxFQUNOLGFBQWEsRUFDYixRQUFRLEVBQ1IsZUFBZSxFQUNmLFVBQVUsRUFDVixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBSTNDLE9BQU8sRUFDSCxnQkFBZ0IsRUFDaEIsZUFBZSxFQUNmLG1CQUFtQixFQUNuQixlQUFlLEVBQ2YsY0FBYyxFQUNqQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSwwQkFBMEIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDNUMsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUEwRXRELElBQWEsZ0JBQWdCLHdCQUE3QixNQUFhLGdCQUFpQixTQUFRLGtCQUFrQjtJQXdDcEQsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCLEVBQzVCLFFBQW1CLEVBQ0QsUUFBYSxFQUMvQixZQUE0QixFQUM1QixPQUFtQjtRQUMvQixLQUFLLEVBQUUsQ0FBQztRQUpJLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDRCxhQUFRLEdBQVIsUUFBUSxDQUFLO1FBRS9CLFlBQU8sR0FBUCxPQUFPLENBQVk7UUFFL0IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBL0NELElBQWMsV0FBVztRQUNyQixPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBSUQsSUFBSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFLO1FBQ25CLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRCxJQUFJLHVCQUF1QjtRQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSx1QkFBdUIsQ0FBQyxLQUFLO1FBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUdELElBQUksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBSztRQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0QsSUFBSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQUs7UUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQWNELFdBQVcsQ0FBQyxRQUE2QjtRQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUM3QixDQUFDO0lBQ0QsZUFBZTtRQUNYLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBSUQsV0FBVztRQUNQLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDO0NBRUosQ0FBQTs7WUF6QnFELGdCQUFnQix1QkFBckQsUUFBUSxZQUFJLElBQUk7WUFDRCxnQkFBZ0IsdUJBQW5DLElBQUk7WUFDYSxTQUFTOzRDQUMxQixNQUFNLFNBQUMsUUFBUTtZQUNNLGNBQWMsdUJBQW5DLElBQUk7WUFDWSxVQUFVOztBQXBDbkM7SUFEQyxlQUFlLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGtCQUFnQixDQUFDLENBQUM7c0NBQy9CLFNBQVM7O3FEQUU3QjtBQU1EO0lBREMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO3NDQUMvQixTQUFTOzsrREFFdkM7QUFNRDtJQURDLGVBQWUsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsZUFBZSxDQUFDLENBQUM7c0NBQy9CLFNBQVM7O29EQUU1QjtBQU1EO0lBREMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO3NDQUNoQyxTQUFTOzt3REFFaEM7QUFuQ1EsZ0JBQWdCO0lBdkU1QixTQUFTLENBQUM7UUFDUCxRQUFRLEVBQUUsVUFBVTtRQUNwQixRQUFRLEVBQUUsMkJBQTJCO1FBRXJDLFNBQVMsRUFBRSxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQztRQUM3QyxNQUFNLEVBQUU7WUFDSixVQUFVO1lBQ1YsTUFBTTtZQUNOLE1BQU07WUFDTixVQUFVO1lBQ1YsTUFBTTtZQUNOLE9BQU87WUFDUCxTQUFTO1lBQ1QsU0FBUztZQUNULE1BQU07WUFDTixVQUFVO1lBQ1YsS0FBSztZQUNMLE9BQU87WUFDUCxRQUFRO1lBQ1IsTUFBTTtZQUNOLFlBQVk7WUFDWixrQkFBa0I7WUFDbEIsT0FBTztZQUNQLFlBQVk7WUFDWixVQUFVO1lBQ1YsU0FBUztZQUNULFVBQVU7WUFDVixXQUFXO1lBQ1gsZUFBZTtZQUNmLFlBQVk7WUFDWixVQUFVO1lBQ1YsWUFBWTtZQUNaLFVBQVU7WUFDVixPQUFPO1lBQ1AsTUFBTTtZQUNOLGlCQUFpQjtZQUNqQixjQUFjO1lBQ2QsaUJBQWlCO1lBQ2pCLFNBQVM7WUFDVCxVQUFVO1lBQ1Ysa0JBQWtCO1lBQ2xCLGlCQUFpQjtZQUNqQixNQUFNO1lBQ04sT0FBTztZQUNQLGFBQWE7WUFDYixlQUFlO1lBQ2YscUJBQXFCO1lBQ3JCLG1CQUFtQjtZQUNuQixRQUFRO1lBQ1IsT0FBTztZQUNQLGNBQWM7WUFDZCxVQUFVO1lBQ1YsU0FBUztZQUNULFVBQVU7WUFDVixRQUFRO1lBQ1IsVUFBVTtZQUNWLFVBQVU7WUFDVixrQkFBa0I7WUFDbEIsWUFBWTtZQUNaLGNBQWM7WUFDZCxLQUFLO1lBQ0wsYUFBYTtZQUNiLGNBQWM7WUFDZCxhQUFhO1lBQ2IsWUFBWTtZQUNaLFVBQVU7WUFDVixVQUFVO1lBQ1YsSUFBSTtZQUNKLFVBQVU7U0FDYjtpQkFsRVEsMkJBQTJCO0tBbUV2QyxDQUFDO0lBeUNlLG1CQUFBLFFBQVEsRUFBRSxDQUFBLEVBQUUsbUJBQUEsSUFBSSxFQUFFLENBQUE7SUFDdEIsbUJBQUEsSUFBSSxFQUFFLENBQUE7SUFFTixtQkFBQSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDaEIsbUJBQUEsSUFBSSxFQUFFLENBQUE7NkNBSm1DLGdCQUFnQjtRQUN0QyxnQkFBZ0I7UUFDbEIsU0FBUyxVQUVMLGNBQWM7UUFDbkIsVUFBVTtHQTdDMUIsZ0JBQWdCLENBaUU1QjtTQWpFWSxnQkFBZ0I7QUEyRTdCLElBQWEsYUFBYSxHQUExQixNQUFhLGFBQWE7Q0FBSSxDQUFBO0FBQWpCLGFBQWE7SUFSekIsUUFBUSxDQUFDO1FBQ1IsWUFBWSxFQUFFO1lBQ1osZ0JBQWdCO1NBQ2pCO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsZ0JBQWdCO1NBQ2pCO0tBQ0YsQ0FBQztHQUNXLGFBQWEsQ0FBSTtTQUFqQixhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDIwLjIuMTJcbiAqIEJ1aWxkIGRhdGU6IFR1ZSBPY3QgMTggMjAyMlxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjIgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cclxuXHJcbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cclxuXHJcbmltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBOZ01vZHVsZSxcclxuICAgIEhvc3QsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgUmVuZGVyZXIyLFxyXG4gICAgSW5qZWN0LFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIFNraXBTZWxmLFxyXG4gICAgQ29udGVudENoaWxkcmVuLFxyXG4gICAgZm9yd2FyZFJlZixcclxuICAgIFF1ZXJ5TGlzdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5cclxuXHJcblxyXG5pbXBvcnQge1xyXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgIGV4dHJhY3RUZW1wbGF0ZSxcclxuICAgIER4VGVtcGxhdGVEaXJlY3RpdmUsXHJcbiAgICBJRHhUZW1wbGF0ZUhvc3QsXHJcbiAgICBEeFRlbXBsYXRlSG9zdFxyXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRHhpQnV0dG9uR3JvdXBJdGVtIH0gZnJvbSAnLi9iYXNlL2J1dHRvbi1ncm91cC1pdGVtLWR4aSc7XHJcbmltcG9ydCB7IER4aVZhbGlkYXRpb25SdWxlQ29tcG9uZW50IH0gZnJvbSAnLi92YWxpZGF0aW9uLXJ1bGUtZHhpJztcclxuaW1wb3J0IHsgRHhpVGFiQ29tcG9uZW50IH0gZnJvbSAnLi90YWItZHhpJztcclxuaW1wb3J0IHsgRHhpTG9jYXRpb25Db21wb25lbnQgfSBmcm9tICcuL2xvY2F0aW9uLWR4aSc7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2R4aS1pdGVtJyxcclxuICAgIHRlbXBsYXRlOiAnPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PicsXHJcbiAgICBzdHlsZXM6IFsnOmhvc3QgeyBkaXNwbGF5OiBibG9jazsgfSddLFxyXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdCwgRHhUZW1wbGF0ZUhvc3RdLFxyXG4gICAgaW5wdXRzOiBbXHJcbiAgICAgICAgJ2Rpc2FibGVkJyxcclxuICAgICAgICAnaHRtbCcsXHJcbiAgICAgICAgJ2ljb24nLFxyXG4gICAgICAgICd0ZW1wbGF0ZScsXHJcbiAgICAgICAgJ3RleHQnLFxyXG4gICAgICAgICd0aXRsZScsXHJcbiAgICAgICAgJ3Zpc2libGUnLFxyXG4gICAgICAgICdvbkNsaWNrJyxcclxuICAgICAgICAndHlwZScsXHJcbiAgICAgICAgJ2Jhc2VTaXplJyxcclxuICAgICAgICAnYm94JyxcclxuICAgICAgICAncmF0aW8nLFxyXG4gICAgICAgICdzaHJpbmsnLFxyXG4gICAgICAgICdoaW50JyxcclxuICAgICAgICAnYmVnaW5Hcm91cCcsXHJcbiAgICAgICAgJ2Nsb3NlTWVudU9uQ2xpY2snLFxyXG4gICAgICAgICdpdGVtcycsXHJcbiAgICAgICAgJ3NlbGVjdGFibGUnLFxyXG4gICAgICAgICdzZWxlY3RlZCcsXHJcbiAgICAgICAgJ2NvbFNwYW4nLFxyXG4gICAgICAgICdjc3NDbGFzcycsXHJcbiAgICAgICAgJ2RhdGFGaWVsZCcsXHJcbiAgICAgICAgJ2VkaXRvck9wdGlvbnMnLFxyXG4gICAgICAgICdlZGl0b3JUeXBlJyxcclxuICAgICAgICAnaGVscFRleHQnLFxyXG4gICAgICAgICdpc1JlcXVpcmVkJyxcclxuICAgICAgICAnaXRlbVR5cGUnLFxyXG4gICAgICAgICdsYWJlbCcsXHJcbiAgICAgICAgJ25hbWUnLFxyXG4gICAgICAgICd2YWxpZGF0aW9uUnVsZXMnLFxyXG4gICAgICAgICd2aXNpYmxlSW5kZXgnLFxyXG4gICAgICAgICdhbGlnbkl0ZW1MYWJlbHMnLFxyXG4gICAgICAgICdjYXB0aW9uJyxcclxuICAgICAgICAnY29sQ291bnQnLFxyXG4gICAgICAgICdjb2xDb3VudEJ5U2NyZWVuJyxcclxuICAgICAgICAndGFiUGFuZWxPcHRpb25zJyxcclxuICAgICAgICAndGFicycsXHJcbiAgICAgICAgJ2JhZGdlJyxcclxuICAgICAgICAndGFiVGVtcGxhdGUnLFxyXG4gICAgICAgICdidXR0b25PcHRpb25zJyxcclxuICAgICAgICAnaG9yaXpvbnRhbEFsaWdubWVudCcsXHJcbiAgICAgICAgJ3ZlcnRpY2FsQWxpZ25tZW50JyxcclxuICAgICAgICAnaGVpZ2h0JyxcclxuICAgICAgICAnd2lkdGgnLFxyXG4gICAgICAgICdsb2NhdGVJbk1lbnUnLFxyXG4gICAgICAgICdsb2NhdGlvbicsXHJcbiAgICAgICAgJ29wdGlvbnMnLFxyXG4gICAgICAgICdzaG93VGV4dCcsXHJcbiAgICAgICAgJ3dpZGdldCcsXHJcbiAgICAgICAgJ2ltYWdlQWx0JyxcclxuICAgICAgICAnaW1hZ2VTcmMnLFxyXG4gICAgICAgICdtZW51SXRlbVRlbXBsYXRlJyxcclxuICAgICAgICAnZm9ybWF0TmFtZScsXHJcbiAgICAgICAgJ2Zvcm1hdFZhbHVlcycsXHJcbiAgICAgICAgJ2tleScsXHJcbiAgICAgICAgJ3Nob3dDaGV2cm9uJyxcclxuICAgICAgICAnbWVudVRlbXBsYXRlJyxcclxuICAgICAgICAnaGVpZ2h0UmF0aW8nLFxyXG4gICAgICAgICd3aWR0aFJhdGlvJyxcclxuICAgICAgICAnZXhwYW5kZWQnLFxyXG4gICAgICAgICdoYXNJdGVtcycsXHJcbiAgICAgICAgJ2lkJyxcclxuICAgICAgICAncGFyZW50SWQnXHJcbiAgICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEeGlJdGVtQ29tcG9uZW50IGV4dGVuZHMgRHhpQnV0dG9uR3JvdXBJdGVtIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIElEeFRlbXBsYXRlSG9zdCB7XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcclxuICAgICAgICByZXR1cm4gJ2l0ZW1zJztcclxuICAgIH1cclxuXHJcblxyXG4gICAgQENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IER4aUl0ZW1Db21wb25lbnQpKVxyXG4gICAgZ2V0IGl0ZW1zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUl0ZW1Db21wb25lbnQ+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtcycpO1xyXG4gICAgfVxyXG4gICAgc2V0IGl0ZW1zQ2hpbGRyZW4odmFsdWUpIHtcclxuICAgICAgICB0aGlzLnNldENoaWxkcmVuKCdpdGVtcycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBAQ29udGVudENoaWxkcmVuKGZvcndhcmRSZWYoKCkgPT4gRHhpVmFsaWRhdGlvblJ1bGVDb21wb25lbnQpKVxyXG4gICAgZ2V0IHZhbGlkYXRpb25SdWxlc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlWYWxpZGF0aW9uUnVsZUNvbXBvbmVudD4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbGlkYXRpb25SdWxlcycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHZhbGlkYXRpb25SdWxlc0NoaWxkcmVuKHZhbHVlKSB7XHJcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbigndmFsaWRhdGlvblJ1bGVzJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIEBDb250ZW50Q2hpbGRyZW4oZm9yd2FyZFJlZigoKSA9PiBEeGlUYWJDb21wb25lbnQpKVxyXG4gICAgZ2V0IHRhYnNDaGlsZHJlbigpOiBRdWVyeUxpc3Q8RHhpVGFiQ29tcG9uZW50PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFicycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHRhYnNDaGlsZHJlbih2YWx1ZSkge1xyXG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ3RhYnMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgQENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IER4aUxvY2F0aW9uQ29tcG9uZW50KSlcclxuICAgIGdldCBsb2NhdGlvbkNoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlMb2NhdGlvbkNvbXBvbmVudD4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2xvY2F0aW9uJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgbG9jYXRpb25DaGlsZHJlbih2YWx1ZSkge1xyXG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2xvY2F0aW9uJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBTa2lwU2VsZigpIEBIb3N0KCkgcGFyZW50T3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gICAgICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IGFueSxcclxuICAgICAgICAgICAgQEhvc3QoKSB0ZW1wbGF0ZUhvc3Q6IER4VGVtcGxhdGVIb3N0LFxyXG4gICAgICAgICAgICBwcml2YXRlIGVsZW1lbnQ6IEVsZW1lbnRSZWYpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xyXG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcclxuICAgICAgICB0ZW1wbGF0ZUhvc3Quc2V0SG9zdCh0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRUZW1wbGF0ZSh0ZW1wbGF0ZTogRHhUZW1wbGF0ZURpcmVjdGl2ZSkge1xyXG4gICAgICAgIHRoaXMudGVtcGxhdGUgPSB0ZW1wbGF0ZTtcclxuICAgIH1cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcclxuICAgICAgICBleHRyYWN0VGVtcGxhdGUodGhpcywgdGhpcy5lbGVtZW50LCB0aGlzLnJlbmRlcmVyLCB0aGlzLmRvY3VtZW50KTtcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIG5nT25EZXN0cm95KCkge1xyXG4gICAgICAgIHRoaXMuX2RlbGV0ZVJlbW92ZWRPcHRpb25zKHRoaXMuX2Z1bGxPcHRpb25QYXRoKCkpO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuQE5nTW9kdWxlKHtcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIER4aUl0ZW1Db21wb25lbnRcclxuICBdLFxyXG4gIGV4cG9ydHM6IFtcclxuICAgIER4aUl0ZW1Db21wb25lbnRcclxuICBdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgRHhpSXRlbU1vZHVsZSB7IH1cclxuIl19