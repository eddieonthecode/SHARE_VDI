/*!
 * devextreme-angular
 * Version: 20.2.12
 * Build date: Tue Oct 18 2022
 *
 * Copyright (c) 2012 - 2022 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import * as tslib_1 from "tslib";
/* tslint:disable:max-line-length */
import { BrowserTransferStateModule } from '@angular/platform-browser';
import { TransferState } from '@angular/platform-browser';
import { Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, OnDestroy, EventEmitter, OnChanges, DoCheck, SimpleChanges, ContentChildren, QueryList } from '@angular/core';
import DxGantt from 'devextreme/ui/gantt';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxiColumnModule } from 'devextreme-angular/ui/nested';
import { DxiButtonModule } from 'devextreme-angular/ui/nested';
import { DxoHeaderFilterModule } from 'devextreme-angular/ui/nested';
import { DxoLookupModule } from 'devextreme-angular/ui/nested';
import { DxoFormatModule } from 'devextreme-angular/ui/nested';
import { DxoFormItemModule } from 'devextreme-angular/ui/nested';
import { DxoLabelModule } from 'devextreme-angular/ui/nested';
import { DxiValidationRuleModule } from 'devextreme-angular/ui/nested';
import { DxoContextMenuModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoDependenciesModule } from 'devextreme-angular/ui/nested';
import { DxoEditingModule } from 'devextreme-angular/ui/nested';
import { DxoResourceAssignmentsModule } from 'devextreme-angular/ui/nested';
import { DxoResourcesModule } from 'devextreme-angular/ui/nested';
import { DxiStripLineModule } from 'devextreme-angular/ui/nested';
import { DxoTasksModule } from 'devextreme-angular/ui/nested';
import { DxoToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoValidationModule } from 'devextreme-angular/ui/nested';
import { DxiColumnComponent } from 'devextreme-angular/ui/nested';
import { DxiStripLineComponent } from 'devextreme-angular/ui/nested';
/**
 * The Gantt is a UI component that displays the task flow and dependencies between tasks.

 */
let DxGanttComponent = class DxGanttComponent extends DxComponent {
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'dependencyDeleted', emit: 'onDependencyDeleted' },
            { subscribe: 'dependencyDeleting', emit: 'onDependencyDeleting' },
            { subscribe: 'dependencyInserted', emit: 'onDependencyInserted' },
            { subscribe: 'dependencyInserting', emit: 'onDependencyInserting' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'resourceAssigned', emit: 'onResourceAssigned' },
            { subscribe: 'resourceAssigning', emit: 'onResourceAssigning' },
            { subscribe: 'resourceDeleted', emit: 'onResourceDeleted' },
            { subscribe: 'resourceDeleting', emit: 'onResourceDeleting' },
            { subscribe: 'resourceInserted', emit: 'onResourceInserted' },
            { subscribe: 'resourceInserting', emit: 'onResourceInserting' },
            { subscribe: 'resourceUnassigned', emit: 'onResourceUnassigned' },
            { subscribe: 'resourceUnassigning', emit: 'onResourceUnassigning' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'taskClick', emit: 'onTaskClick' },
            { subscribe: 'taskDblClick', emit: 'onTaskDblClick' },
            { subscribe: 'taskDeleted', emit: 'onTaskDeleted' },
            { subscribe: 'taskDeleting', emit: 'onTaskDeleting' },
            { subscribe: 'taskEditDialogShowing', emit: 'onTaskEditDialogShowing' },
            { subscribe: 'taskInserted', emit: 'onTaskInserted' },
            { subscribe: 'taskInserting', emit: 'onTaskInserting' },
            { subscribe: 'taskMoving', emit: 'onTaskMoving' },
            { subscribe: 'taskUpdated', emit: 'onTaskUpdated' },
            { subscribe: 'taskUpdating', emit: 'onTaskUpdating' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowSelectionChange' },
            { emit: 'columnsChange' },
            { emit: 'contextMenuChange' },
            { emit: 'dependenciesChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'firstDayOfWeekChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'resourceAssignmentsChange' },
            { emit: 'resourcesChange' },
            { emit: 'rootValueChange' },
            { emit: 'scaleTypeChange' },
            { emit: 'selectedRowKeyChange' },
            { emit: 'showResourcesChange' },
            { emit: 'showRowLinesChange' },
            { emit: 'stripLinesChange' },
            { emit: 'tabIndexChange' },
            { emit: 'taskListWidthChange' },
            { emit: 'tasksChange' },
            { emit: 'taskTitlePositionChange' },
            { emit: 'taskTooltipContentTemplateChange' },
            { emit: 'toolbarChange' },
            { emit: 'validationChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    /**
     * Specifies the shortcut key that sets focus on the UI component.
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * Specifies whether or not the UI component changes its state when interacting with a user.
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * Specifies whether users can select tasks in the Gantt.
    
     */
    get allowSelection() {
        return this._getOption('allowSelection');
    }
    set allowSelection(value) {
        this._setOption('allowSelection', value);
    }
    /**
     * An array of columns in the Gantt.
    
     */
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    /**
     * Configures the context menu settings.
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * Configures dependencies.
    
     */
    get dependencies() {
        return this._getOption('dependencies');
    }
    set dependencies(value) {
        this._setOption('dependencies', value);
    }
    /**
     * Specifies whether the UI component responds to user interaction.
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * Configures edit properties.
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * Specifies the global attributes to be attached to the UI component's container element.
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * Specifies the first day of a week.
    
     */
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    /**
     * Specifies whether the UI component can be focused using keyboard navigation.
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * Specifies the UI component's height.
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * Specifies text for a hint that appears when a user pauses on the UI component.
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * Specifies whether the UI component changes its state when a user pauses on it.
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * Configures resource assignments.
    
     */
    get resourceAssignments() {
        return this._getOption('resourceAssignments');
    }
    set resourceAssignments(value) {
        this._setOption('resourceAssignments', value);
    }
    /**
     * Configures task resources.
    
     */
    get resources() {
        return this._getOption('resources');
    }
    set resources(value) {
        this._setOption('resources', value);
    }
    /**
     * Specifies the root task's identifier.
    
     */
    get rootValue() {
        return this._getOption('rootValue');
    }
    set rootValue(value) {
        this._setOption('rootValue', value);
    }
    /**
     * Specifies the zoom level of tasks in the Gantt chart.
    
     */
    get scaleType() {
        return this._getOption('scaleType');
    }
    set scaleType(value) {
        this._setOption('scaleType', value);
    }
    /**
     * Allows you to select a row or determine which row is selected.
    
     */
    get selectedRowKey() {
        return this._getOption('selectedRowKey');
    }
    set selectedRowKey(value) {
        this._setOption('selectedRowKey', value);
    }
    /**
     * Specifies whether to display task resources.
    
     */
    get showResources() {
        return this._getOption('showResources');
    }
    set showResources(value) {
        this._setOption('showResources', value);
    }
    /**
     * Specifies whether to show/hide horizontal faint lines that separate tasks.
    
     */
    get showRowLines() {
        return this._getOption('showRowLines');
    }
    set showRowLines(value) {
        this._setOption('showRowLines', value);
    }
    /**
     * Configures strip lines.
    
     */
    get stripLines() {
        return this._getOption('stripLines');
    }
    set stripLines(value) {
        this._setOption('stripLines', value);
    }
    /**
     * Specifies the number of the element when the Tab key is used for navigating.
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * Specifies the width of the task list in pixels.
    
     */
    get taskListWidth() {
        return this._getOption('taskListWidth');
    }
    set taskListWidth(value) {
        this._setOption('taskListWidth', value);
    }
    /**
     * Configures tasks.
    
     */
    get tasks() {
        return this._getOption('tasks');
    }
    set tasks(value) {
        this._setOption('tasks', value);
    }
    /**
     * Specifies a task's title position.
    
     */
    get taskTitlePosition() {
        return this._getOption('taskTitlePosition');
    }
    set taskTitlePosition(value) {
        this._setOption('taskTitlePosition', value);
    }
    /**
     * Specifies custom content for the task tooltip.
    
     */
    get taskTooltipContentTemplate() {
        return this._getOption('taskTooltipContentTemplate');
    }
    set taskTooltipContentTemplate(value) {
        this._setOption('taskTooltipContentTemplate', value);
    }
    /**
     * Configures toolbar settings.
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * Configures validation properties.
    
     */
    get validation() {
        return this._getOption('validation');
    }
    set validation(value) {
        this._setOption('validation', value);
    }
    /**
     * Specifies whether the UI component is visible.
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * Specifies the UI component's width.
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get columnsChildren() {
        return this._getOption('columns');
    }
    set columnsChildren(value) {
        this.setChildren('columns', value);
    }
    get stripLinesChildren() {
        return this._getOption('stripLines');
    }
    set stripLinesChildren(value) {
        this.setChildren('stripLines', value);
    }
    _createInstance(element, options) {
        return new DxGantt(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('columns', changes);
        this.setupChanges('stripLines', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('columns');
        this._idh.doCheck('stripLines');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
};
DxGanttComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: DxTemplateHost },
    { type: WatcherHelper },
    { type: IterableDifferHelper },
    { type: NestedOptionHost },
    { type: TransferState },
    { type: undefined, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
];
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxGanttComponent.prototype, "accessKey", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "activeStateEnabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "allowSelection", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Array),
    tslib_1.__metadata("design:paramtypes", [Array])
], DxGanttComponent.prototype, "columns", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "contextMenu", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "dependencies", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "disabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "editing", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "elementAttr", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "firstDayOfWeek", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "focusStateEnabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "height", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxGanttComponent.prototype, "hint", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "hoverStateEnabled", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "resourceAssignments", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "resources", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "rootValue", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxGanttComponent.prototype, "scaleType", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "selectedRowKey", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "showResources", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "showRowLines", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Array),
    tslib_1.__metadata("design:paramtypes", [Array])
], DxGanttComponent.prototype, "stripLines", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Number),
    tslib_1.__metadata("design:paramtypes", [Number])
], DxGanttComponent.prototype, "tabIndex", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Number),
    tslib_1.__metadata("design:paramtypes", [Number])
], DxGanttComponent.prototype, "taskListWidth", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "tasks", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String),
    tslib_1.__metadata("design:paramtypes", [String])
], DxGanttComponent.prototype, "taskTitlePosition", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "taskTooltipContentTemplate", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "toolbar", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "validation", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean),
    tslib_1.__metadata("design:paramtypes", [Boolean])
], DxGanttComponent.prototype, "visible", null);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "width", null);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onContentReady", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onContextMenuPreparing", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onCustomCommand", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onDependencyDeleted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onDependencyDeleting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onDependencyInserted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onDependencyInserting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onDisposing", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onInitialized", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onOptionChanged", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceAssigned", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceAssigning", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceDeleted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceDeleting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceInserted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceInserting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceUnassigned", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onResourceUnassigning", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onSelectionChanged", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskClick", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskDblClick", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskDeleted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskDeleting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskEditDialogShowing", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskInserted", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskInserting", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskMoving", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskUpdated", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "onTaskUpdating", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "accessKeyChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "activeStateEnabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "allowSelectionChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "columnsChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "contextMenuChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "dependenciesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "disabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "editingChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "elementAttrChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "firstDayOfWeekChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "focusStateEnabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "heightChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "hintChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "hoverStateEnabledChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "resourceAssignmentsChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "resourcesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "rootValueChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "scaleTypeChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "selectedRowKeyChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "showResourcesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "showRowLinesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "stripLinesChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "tabIndexChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "taskListWidthChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "tasksChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "taskTitlePositionChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "taskTooltipContentTemplateChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "toolbarChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "validationChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "visibleChange", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", EventEmitter)
], DxGanttComponent.prototype, "widthChange", void 0);
tslib_1.__decorate([
    ContentChildren(DxiColumnComponent),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "columnsChildren", null);
tslib_1.__decorate([
    ContentChildren(DxiStripLineComponent),
    tslib_1.__metadata("design:type", QueryList),
    tslib_1.__metadata("design:paramtypes", [Object])
], DxGanttComponent.prototype, "stripLinesChildren", null);
DxGanttComponent = tslib_1.__decorate([
    Component({
        selector: 'dx-gantt',
        template: '',
        providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ]
    }),
    tslib_1.__param(7, Inject(PLATFORM_ID)),
    tslib_1.__metadata("design:paramtypes", [ElementRef, NgZone, DxTemplateHost,
        WatcherHelper,
        IterableDifferHelper,
        NestedOptionHost,
        TransferState, Object])
], DxGanttComponent);
export { DxGanttComponent };
let DxGanttModule = class DxGanttModule {
};
DxGanttModule = tslib_1.__decorate([
    NgModule({
        imports: [
            DxiColumnModule,
            DxiButtonModule,
            DxoHeaderFilterModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxIntegrationModule,
            DxTemplateModule,
            BrowserTransferStateModule
        ],
        declarations: [
            DxGanttComponent
        ],
        exports: [
            DxGanttComponent,
            DxiColumnModule,
            DxiButtonModule,
            DxoHeaderFilterModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxTemplateModule
        ]
    })
], DxGanttModule);
export { DxGanttModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9kZXZleHRyZW1lLWFuZ3VsYXIvdWkvZ2FudHQvIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRzs7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUFFLDBCQUEwQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDdkUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBRTFELE9BQU8sRUFDSCxTQUFTLEVBQ1QsUUFBUSxFQUNSLFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxFQUNYLE1BQU0sRUFFTixLQUFLLEVBQ0wsTUFBTSxFQUNOLFNBQVMsRUFDVCxZQUFZLEVBQ1osU0FBUyxFQUNULE9BQU8sRUFDUCxhQUFhLEVBQ2IsZUFBZSxFQUNmLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQU12QixPQUFPLE9BQU8sTUFBTSxxQkFBcUIsQ0FBQztBQUcxQyxPQUFPLEVBQ0gsV0FBVyxFQUNYLGNBQWMsRUFDZCxtQkFBbUIsRUFDbkIsZ0JBQWdCLEVBQ2hCLGdCQUFnQixFQUNoQixvQkFBb0IsRUFDcEIsYUFBYSxFQUNoQixNQUFNLHlCQUF5QixDQUFDO0FBRWpDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDckUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNqRSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdkUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3JFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzVFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUVuRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUlyRTs7O0dBR0c7QUFXSCxJQUFhLGdCQUFnQixHQUE3QixNQUFhLGdCQUFpQixTQUFRLFdBQVc7SUE0MkI3QyxZQUFZLFVBQXNCLEVBQUUsTUFBYyxFQUFFLFlBQTRCLEVBQ2hFLGNBQTZCLEVBQzdCLElBQTBCLEVBQ2xDLFVBQTRCLEVBQzVCLGFBQTRCLEVBQ1AsVUFBZTtRQUV4QyxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQztRQU52RSxtQkFBYyxHQUFkLGNBQWMsQ0FBZTtRQUM3QixTQUFJLEdBQUosSUFBSSxDQUFzQjtRQU90QyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDdEIsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNyRCxFQUFFLFNBQVMsRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDckUsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0QsRUFBRSxTQUFTLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2pFLEVBQUUsU0FBUyxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUNqRSxFQUFFLFNBQVMsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDbkUsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDbkQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9ELEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtZQUMzRCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzdELEVBQUUsU0FBUyxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvRCxFQUFFLFNBQVMsRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDakUsRUFBRSxTQUFTLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ25FLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ3ZFLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUNqRCxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtZQUM3QixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUNuQyxFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRTtZQUNyQyxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUNoQyxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvQixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsa0NBQWtDLEVBQUU7WUFDNUMsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7U0FDMUIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBbjdCRDs7O09BR0c7SUFFSCxJQUFJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQWE7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWM7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFxRDtRQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUF5QjtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUEwTztRQUN2UCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQTJUO1FBQ25VLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksV0FBVyxDQUFDLEtBQVU7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFzQjtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBaUM7UUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxpQkFBaUI7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQUksaUJBQWlCLENBQUMsS0FBYztRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUFvTTtRQUN4TixJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQTZMO1FBQ3ZNLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQVU7UUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQVU7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFjO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBNEM7UUFDdkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFhO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQThUO1FBQ3BVLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFhO1FBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUVILElBQUksMEJBQTBCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFJLDBCQUEwQixDQUFDLEtBQVU7UUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFxQjtRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUEwRztRQUNySCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBRUgsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFFSCxJQUFJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQWlDO1FBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUF1Y0QsSUFBSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFLO1FBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRCxJQUFJLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksa0JBQWtCLENBQUMsS0FBSztRQUN4QixJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBaUZTLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUV0QyxPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0QsV0FBVztRQUNQLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFZLEVBQUUsT0FBc0I7UUFDN0MsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFZLEVBQUUsS0FBVTtRQUMvQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDakQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztRQUUzRCxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDdEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0NBQ0osQ0FBQTs7WUFsSDJCLFVBQVU7WUFBVSxNQUFNO1lBQWdCLGNBQWM7WUFDaEQsYUFBYTtZQUN2QixvQkFBb0I7WUFDdEIsZ0JBQWdCO1lBQ2IsYUFBYTs0Q0FDM0IsTUFBTSxTQUFDLFdBQVc7O0FBejJCM0I7SUFEQyxLQUFLLEVBQUU7OztpREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7MERBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3NEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7c0NBSVcsS0FBSzs2Q0FBTCxLQUFLOytDQUR2QjtBQVdEO0lBREMsS0FBSyxFQUFFOzs7bURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O29EQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztnREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7K0NBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O21EQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztzREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7eURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7OzhDQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7Ozs0Q0FHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7eURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7OzJEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztpREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7aURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2lEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OztzREFHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7cURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O29EQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7c0NBSWMsS0FBSzs2Q0FBTCxLQUFLO2tEQUQxQjtBQVdEO0lBREMsS0FBSyxFQUFFOzs7Z0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O3FEQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7Ozs2Q0FHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7eURBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7O2tFQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7OzsrQ0FHUDtBQVdEO0lBREMsS0FBSyxFQUFFOzs7a0RBR1A7QUFXRDtJQURDLEtBQUssRUFBRTs7OytDQUdQO0FBV0Q7SUFEQyxLQUFLLEVBQUU7Ozs2Q0FHUDtBQVdTO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZO3dEQUFNO0FBUWxDO0lBQVQsTUFBTSxFQUFFO3NDQUF5QixZQUFZO2dFQUFNO0FBUTFDO0lBQVQsTUFBTSxFQUFFO3NDQUFrQixZQUFZO3lEQUFNO0FBUW5DO0lBQVQsTUFBTSxFQUFFO3NDQUFzQixZQUFZOzZEQUFNO0FBUXZDO0lBQVQsTUFBTSxFQUFFO3NDQUF1QixZQUFZOzhEQUFNO0FBUXhDO0lBQVQsTUFBTSxFQUFFO3NDQUF1QixZQUFZOzhEQUFNO0FBUXhDO0lBQVQsTUFBTSxFQUFFO3NDQUF3QixZQUFZOytEQUFNO0FBUXpDO0lBQVQsTUFBTSxFQUFFO3NDQUFjLFlBQVk7cURBQU07QUFRL0I7SUFBVCxNQUFNLEVBQUU7c0NBQWdCLFlBQVk7dURBQU07QUFRakM7SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7eURBQU07QUFRbkM7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7NERBQU07QUFRdEM7SUFBVCxNQUFNLEVBQUU7c0NBQXNCLFlBQVk7NkRBQU07QUFRdkM7SUFBVCxNQUFNLEVBQUU7c0NBQW9CLFlBQVk7MkRBQU07QUFRckM7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7NERBQU07QUFRdEM7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7NERBQU07QUFRdEM7SUFBVCxNQUFNLEVBQUU7c0NBQXNCLFlBQVk7NkRBQU07QUFRdkM7SUFBVCxNQUFNLEVBQUU7c0NBQXVCLFlBQVk7OERBQU07QUFReEM7SUFBVCxNQUFNLEVBQUU7c0NBQXdCLFlBQVk7K0RBQU07QUFRekM7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7NERBQU07QUFRdEM7SUFBVCxNQUFNLEVBQUU7c0NBQWMsWUFBWTtxREFBTTtBQVEvQjtJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTt3REFBTTtBQVFsQztJQUFULE1BQU0sRUFBRTtzQ0FBZ0IsWUFBWTt1REFBTTtBQVFqQztJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTt3REFBTTtBQVFsQztJQUFULE1BQU0sRUFBRTtzQ0FBMEIsWUFBWTtpRUFBTTtBQVEzQztJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTt3REFBTTtBQVFsQztJQUFULE1BQU0sRUFBRTtzQ0FBa0IsWUFBWTt5REFBTTtBQVFuQztJQUFULE1BQU0sRUFBRTtzQ0FBZSxZQUFZO3NEQUFNO0FBUWhDO0lBQVQsTUFBTSxFQUFFO3NDQUFnQixZQUFZO3VEQUFNO0FBUWpDO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZO3dEQUFNO0FBT2xDO0lBQVQsTUFBTSxFQUFFO3NDQUFrQixZQUFZO3lEQUFTO0FBT3RDO0lBQVQsTUFBTSxFQUFFO3NDQUEyQixZQUFZO2tFQUFVO0FBT2hEO0lBQVQsTUFBTSxFQUFFO3NDQUF1QixZQUFZOzhEQUFVO0FBTzVDO0lBQVQsTUFBTSxFQUFFO3NDQUFnQixZQUFZO3VEQUFpRDtBQU81RTtJQUFULE1BQU0sRUFBRTtzQ0FBb0IsWUFBWTsyREFBcUI7QUFPcEQ7SUFBVCxNQUFNLEVBQUU7c0NBQXFCLFlBQVk7NERBQXNPO0FBT3RRO0lBQVQsTUFBTSxFQUFFO3NDQUFpQixZQUFZO3dEQUFVO0FBT3RDO0lBQVQsTUFBTSxFQUFFO3NDQUFnQixZQUFZO3VEQUF1VDtBQU9sVjtJQUFULE1BQU0sRUFBRTtzQ0FBb0IsWUFBWTsyREFBTTtBQU9yQztJQUFULE1BQU0sRUFBRTtzQ0FBdUIsWUFBWTs4REFBa0I7QUFPcEQ7SUFBVCxNQUFNLEVBQUU7c0NBQTBCLFlBQVk7aUVBQVU7QUFPL0M7SUFBVCxNQUFNLEVBQUU7c0NBQWUsWUFBWTtzREFBNkI7QUFPdkQ7SUFBVCxNQUFNLEVBQUU7c0NBQWEsWUFBWTtvREFBUztBQU9qQztJQUFULE1BQU0sRUFBRTtzQ0FBMEIsWUFBWTtpRUFBVTtBQU8vQztJQUFULE1BQU0sRUFBRTtzQ0FBNEIsWUFBWTttRUFBZ007QUFPdk87SUFBVCxNQUFNLEVBQUU7c0NBQWtCLFlBQVk7eURBQXlMO0FBT3ROO0lBQVQsTUFBTSxFQUFFO3NDQUFrQixZQUFZO3lEQUFNO0FBT25DO0lBQVQsTUFBTSxFQUFFO3NDQUFrQixZQUFZO3lEQUFTO0FBT3RDO0lBQVQsTUFBTSxFQUFFO3NDQUF1QixZQUFZOzhEQUFNO0FBT3hDO0lBQVQsTUFBTSxFQUFFO3NDQUFzQixZQUFZOzZEQUFVO0FBTzNDO0lBQVQsTUFBTSxFQUFFO3NDQUFxQixZQUFZOzREQUFVO0FBTzFDO0lBQVQsTUFBTSxFQUFFO3NDQUFtQixZQUFZOzBEQUF3QztBQU90RTtJQUFULE1BQU0sRUFBRTtzQ0FBaUIsWUFBWTt3REFBUztBQU9yQztJQUFULE1BQU0sRUFBRTtzQ0FBc0IsWUFBWTs2REFBUztBQU8xQztJQUFULE1BQU0sRUFBRTtzQ0FBYyxZQUFZO3FEQUEwVDtBQU9uVjtJQUFULE1BQU0sRUFBRTtzQ0FBMEIsWUFBWTtpRUFBUztBQU85QztJQUFULE1BQU0sRUFBRTtzQ0FBbUMsWUFBWTswRUFBTTtBQU9wRDtJQUFULE1BQU0sRUFBRTtzQ0FBZ0IsWUFBWTt1REFBaUI7QUFPNUM7SUFBVCxNQUFNLEVBQUU7c0NBQW1CLFlBQVk7MERBQXNHO0FBT3BJO0lBQVQsTUFBTSxFQUFFO3NDQUFnQixZQUFZO3VEQUFVO0FBT3JDO0lBQVQsTUFBTSxFQUFFO3NDQUFjLFlBQVk7cURBQTZCO0FBTWhFO0lBREMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO3NDQUNiLFNBQVM7O3VEQUUvQjtBQU1EO0lBREMsZUFBZSxDQUFDLHFCQUFxQixDQUFDO3NDQUNiLFNBQVM7OzBEQUVsQztBQXAyQlEsZ0JBQWdCO0lBVjVCLFNBQVMsQ0FBQztRQUNQLFFBQVEsRUFBRSxVQUFVO1FBQ3BCLFFBQVEsRUFBRSxFQUFFO1FBQ1osU0FBUyxFQUFFO1lBQ1AsY0FBYztZQUNkLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsb0JBQW9CO1NBQ3ZCO0tBQ0osQ0FBQztJQWszQlcsbUJBQUEsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFBOzZDQUxKLFVBQVUsRUFBVSxNQUFNLEVBQWdCLGNBQWM7UUFDaEQsYUFBYTtRQUN2QixvQkFBb0I7UUFDdEIsZ0JBQWdCO1FBQ2IsYUFBYTtHQWgzQjNCLGdCQUFnQixDQTg5QjVCO1NBOTlCWSxnQkFBZ0I7QUFraEM3QixJQUFhLGFBQWEsR0FBMUIsTUFBYSxhQUFhO0NBQUksQ0FBQTtBQUFqQixhQUFhO0lBbER6QixRQUFRLENBQUM7UUFDUixPQUFPLEVBQUU7WUFDUCxlQUFlO1lBQ2YsZUFBZTtZQUNmLHFCQUFxQjtZQUNyQixlQUFlO1lBQ2YsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQixjQUFjO1lBQ2QsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQixhQUFhO1lBQ2IscUJBQXFCO1lBQ3JCLGdCQUFnQjtZQUNoQiw0QkFBNEI7WUFDNUIsa0JBQWtCO1lBQ2xCLGtCQUFrQjtZQUNsQixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixtQkFBbUI7WUFDbkIsZ0JBQWdCO1lBQ2hCLDBCQUEwQjtTQUMzQjtRQUNELFlBQVksRUFBRTtZQUNaLGdCQUFnQjtTQUNqQjtRQUNELE9BQU8sRUFBRTtZQUNQLGdCQUFnQjtZQUNoQixlQUFlO1lBQ2YsZUFBZTtZQUNmLHFCQUFxQjtZQUNyQixlQUFlO1lBQ2YsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQixjQUFjO1lBQ2QsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQixhQUFhO1lBQ2IscUJBQXFCO1lBQ3JCLGdCQUFnQjtZQUNoQiw0QkFBNEI7WUFDNUIsa0JBQWtCO1lBQ2xCLGtCQUFrQjtZQUNsQixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixnQkFBZ0I7U0FDakI7S0FDRixDQUFDO0dBQ1csYUFBYSxDQUFJO1NBQWpCLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjAuMi4xMlxuICogQnVpbGQgZGF0ZTogVHVlIE9jdCAxOCAyMDIyXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyMiBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xyXG5cclxuXHJcbmltcG9ydCB7IEJyb3dzZXJUcmFuc2ZlclN0YXRlTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IFRyYW5zZmVyU3RhdGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuXHJcbmltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBOZ01vZHVsZSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBOZ1pvbmUsXHJcbiAgICBQTEFURk9STV9JRCxcclxuICAgIEluamVjdCxcclxuXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIERvQ2hlY2ssXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgQ29udGVudENoaWxkcmVuLFxyXG4gICAgUXVlcnlMaXN0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5cclxuaW1wb3J0IERldkV4cHJlc3MgZnJvbSAnZGV2ZXh0cmVtZS9idW5kbGVzL2R4LmFsbCc7XHJcbmltcG9ydCB7IGR4R2FudHRDb250ZXh0TWVudSwgZHhHYW50dFRvb2xiYXIgfSBmcm9tICdkZXZleHRyZW1lL3VpL2dhbnR0JztcclxuXHJcbmltcG9ydCBEeEdhbnR0IGZyb20gJ2RldmV4dHJlbWUvdWkvZ2FudHQnO1xyXG5cclxuXHJcbmltcG9ydCB7XHJcbiAgICBEeENvbXBvbmVudCxcclxuICAgIER4VGVtcGxhdGVIb3N0LFxyXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcclxuICAgIER4VGVtcGxhdGVNb2R1bGUsXHJcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gICAgSXRlcmFibGVEaWZmZXJIZWxwZXIsXHJcbiAgICBXYXRjaGVySGVscGVyXHJcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgRHhpQ29sdW1uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4aUJ1dHRvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9IZWFkZXJGaWx0ZXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvTG9va3VwTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0Zvcm1hdE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9Gb3JtSXRlbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9MYWJlbE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlWYWxpZGF0aW9uUnVsZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9Db250ZXh0TWVudU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlJdGVtTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b0RlcGVuZGVuY2llc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9FZGl0aW5nTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b1Jlc291cmNlQXNzaWdubWVudHNNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuaW1wb3J0IHsgRHhvUmVzb3VyY2VzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4aVN0cmlwTGluZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9UYXNrc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeG9Ub29sYmFyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XHJcbmltcG9ydCB7IER4b1ZhbGlkYXRpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuXHJcbmltcG9ydCB7IER4aUNvbHVtbkNvbXBvbmVudCB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xyXG5pbXBvcnQgeyBEeGlTdHJpcExpbmVDb21wb25lbnQgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcclxuXHJcblxyXG5cclxuLyoqXHJcbiAqIFtkZXNjcjpkeEdhbnR0XVxyXG5cclxuICovXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdkeC1nYW50dCcsXHJcbiAgICB0ZW1wbGF0ZTogJycsXHJcbiAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcclxuICAgICAgICBXYXRjaGVySGVscGVyLFxyXG4gICAgICAgIE5lc3RlZE9wdGlvbkhvc3QsXHJcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcclxuICAgIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIER4R2FudHRDb21wb25lbnQgZXh0ZW5kcyBEeENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBEb0NoZWNrIHtcclxuICAgIGluc3RhbmNlOiBEeEdhbnR0O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOldpZGdldC5PcHRpb25zLmFjY2Vzc0tleV1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGFjY2Vzc0tleSgpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FjY2Vzc0tleScpO1xyXG4gICAgfVxyXG4gICAgc2V0IGFjY2Vzc0tleSh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhY2Nlc3NLZXknLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOldpZGdldC5PcHRpb25zLmFjdGl2ZVN0YXRlRW5hYmxlZF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGFjdGl2ZVN0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY3RpdmVTdGF0ZUVuYWJsZWQnKTtcclxuICAgIH1cclxuICAgIHNldCBhY3RpdmVTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLmFsbG93U2VsZWN0aW9uXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgYWxsb3dTZWxlY3Rpb24oKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dTZWxlY3Rpb24nKTtcclxuICAgIH1cclxuICAgIHNldCBhbGxvd1NlbGVjdGlvbih2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dTZWxlY3Rpb24nLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5jb2x1bW5zXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgY29sdW1ucygpOiBBcnJheTxEZXZFeHByZXNzLnVpLmR4VHJlZUxpc3RDb2x1bW4gfCBzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb2x1bW5zJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgY29sdW1ucyh2YWx1ZTogQXJyYXk8RGV2RXhwcmVzcy51aS5keFRyZWVMaXN0Q29sdW1uIHwgc3RyaW5nPikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY29sdW1ucycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLmNvbnRleHRNZW51XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgY29udGV4dE1lbnUoKTogZHhHYW50dENvbnRleHRNZW51IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb250ZXh0TWVudScpO1xyXG4gICAgfVxyXG4gICAgc2V0IGNvbnRleHRNZW51KHZhbHVlOiBkeEdhbnR0Q29udGV4dE1lbnUpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbnRleHRNZW51JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMuZGVwZW5kZW5jaWVzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZGVwZW5kZW5jaWVzKCk6IHsgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcmVkZWNlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdWNjZXNzb3JJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkZXBlbmRlbmNpZXMnKTtcclxuICAgIH1cclxuICAgIHNldCBkZXBlbmRlbmNpZXModmFsdWU6IHsgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcmVkZWNlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdWNjZXNzb3JJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkZXBlbmRlbmNpZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOldpZGdldC5PcHRpb25zLmRpc2FibGVkXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWQnKTtcclxuICAgIH1cclxuICAgIHNldCBkaXNhYmxlZCh2YWx1ZTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWQnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5lZGl0aW5nXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZWRpdGluZygpOiB7IGFsbG93RGVwZW5kZW5jeUFkZGluZz86IGJvb2xlYW4sIGFsbG93RGVwZW5kZW5jeURlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZUFkZGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VEZWxldGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VVcGRhdGluZz86IGJvb2xlYW4sIGFsbG93VGFza0FkZGluZz86IGJvb2xlYW4sIGFsbG93VGFza0RlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrUmVzb3VyY2VVcGRhdGluZz86IGJvb2xlYW4sIGFsbG93VGFza1VwZGF0aW5nPzogYm9vbGVhbiwgZW5hYmxlZD86IGJvb2xlYW4gfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWRpdGluZycpO1xyXG4gICAgfVxyXG4gICAgc2V0IGVkaXRpbmcodmFsdWU6IHsgYWxsb3dEZXBlbmRlbmN5QWRkaW5nPzogYm9vbGVhbiwgYWxsb3dEZXBlbmRlbmN5RGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlQWRkaW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZURlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZVVwZGF0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrQWRkaW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrRGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tSZXNvdXJjZVVwZGF0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrVXBkYXRpbmc/OiBib29sZWFuLCBlbmFibGVkPzogYm9vbGVhbiB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlZGl0aW5nJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy5lbGVtZW50QXR0cl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGVsZW1lbnRBdHRyKCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcclxuICAgIH1cclxuICAgIHNldCBlbGVtZW50QXR0cih2YWx1ZTogYW55KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLmZpcnN0RGF5T2ZXZWVrXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgZmlyc3REYXlPZldlZWsoKTogbnVtYmVyIHwgc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmaXJzdERheU9mV2VlaycpO1xyXG4gICAgfVxyXG4gICAgc2V0IGZpcnN0RGF5T2ZXZWVrKHZhbHVlOiBudW1iZXIgfCBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2ZpcnN0RGF5T2ZXZWVrJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpXaWRnZXQuT3B0aW9ucy5mb2N1c1N0YXRlRW5hYmxlZF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGZvY3VzU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2ZvY3VzU3RhdGVFbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgZm9jdXNTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2ZvY3VzU3RhdGVFbmFibGVkJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy5oZWlnaHRdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBoZWlnaHQoKTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hlaWdodCcpO1xyXG4gICAgfVxyXG4gICAgc2V0IGhlaWdodCh2YWx1ZTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hlaWdodCcsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6V2lkZ2V0Lk9wdGlvbnMuaGludF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGhpbnQoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoaW50Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgaGludCh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoaW50JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpXaWRnZXQuT3B0aW9ucy5ob3ZlclN0YXRlRW5hYmxlZF1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGhvdmVyU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hvdmVyU3RhdGVFbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgaG92ZXJTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hvdmVyU3RhdGVFbmFibGVkJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMucmVzb3VyY2VBc3NpZ25tZW50c11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHJlc291cmNlQXNzaWdubWVudHMoKTogeyBkYXRhU291cmNlPzogRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2UgfCBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZU9wdGlvbnMgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHJlc291cmNlSWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRhc2tJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyZXNvdXJjZUFzc2lnbm1lbnRzJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgcmVzb3VyY2VBc3NpZ25tZW50cyh2YWx1ZTogeyBkYXRhU291cmNlPzogRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2UgfCBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZU9wdGlvbnMgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHJlc291cmNlSWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRhc2tJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyZXNvdXJjZUFzc2lnbm1lbnRzJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMucmVzb3VyY2VzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgcmVzb3VyY2VzKCk6IHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyZXNvdXJjZXMnKTtcclxuICAgIH1cclxuICAgIHNldCByZXNvdXJjZXModmFsdWU6IHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyZXNvdXJjZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5yb290VmFsdWVdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCByb290VmFsdWUoKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyb290VmFsdWUnKTtcclxuICAgIH1cclxuICAgIHNldCByb290VmFsdWUodmFsdWU6IGFueSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncm9vdFZhbHVlJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMuc2NhbGVUeXBlXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgc2NhbGVUeXBlKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2NhbGVUeXBlJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgc2NhbGVUeXBlKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NjYWxlVHlwZScsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLnNlbGVjdGVkUm93S2V5XVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgc2VsZWN0ZWRSb3dLZXkoKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzZWxlY3RlZFJvd0tleScpO1xyXG4gICAgfVxyXG4gICAgc2V0IHNlbGVjdGVkUm93S2V5KHZhbHVlOiBhbnkpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NlbGVjdGVkUm93S2V5JywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMuc2hvd1Jlc291cmNlc11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHNob3dSZXNvdXJjZXMoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd1Jlc291cmNlcycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHNob3dSZXNvdXJjZXModmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Nob3dSZXNvdXJjZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5zaG93Um93TGluZXNdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCBzaG93Um93TGluZXMoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd1Jvd0xpbmVzJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgc2hvd1Jvd0xpbmVzKHZhbHVlOiBib29sZWFuKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaG93Um93TGluZXMnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5zdHJpcExpbmVzXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgc3RyaXBMaW5lcygpOiBBcnJheTxEZXZFeHByZXNzLnVpLmR4R2FudHRTdHJpcExpbmU+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzdHJpcExpbmVzJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgc3RyaXBMaW5lcyh2YWx1ZTogQXJyYXk8RGV2RXhwcmVzcy51aS5keEdhbnR0U3RyaXBMaW5lPikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc3RyaXBMaW5lcycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6V2lkZ2V0Lk9wdGlvbnMudGFiSW5kZXhdXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCB0YWJJbmRleCgpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RhYkluZGV4Jyk7XHJcbiAgICB9XHJcbiAgICBzZXQgdGFiSW5kZXgodmFsdWU6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFiSW5kZXgnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy50YXNrTGlzdFdpZHRoXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgdGFza0xpc3RXaWR0aCgpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Rhc2tMaXN0V2lkdGgnKTtcclxuICAgIH1cclxuICAgIHNldCB0YXNrTGlzdFdpZHRoKHZhbHVlOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rhc2tMaXN0V2lkdGgnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy50YXNrc11cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHRhc2tzKCk6IHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGVuZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwYXJlbnRJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcHJvZ3Jlc3NFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN0YXJ0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0aXRsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YXNrcycpO1xyXG4gICAgfVxyXG4gICAgc2V0IHRhc2tzKHZhbHVlOiB7IGNvbG9yRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBkYXRhU291cmNlPzogRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2UgfCBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZU9wdGlvbnMgfCBBcnJheTxhbnk+LCBlbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcGFyZW50SWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHByb2dyZXNzRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdGFydEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGl0bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFza3MnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy50YXNrVGl0bGVQb3NpdGlvbl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHRhc2tUaXRsZVBvc2l0aW9uKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza1RpdGxlUG9zaXRpb24nKTtcclxuICAgIH1cclxuICAgIHNldCB0YXNrVGl0bGVQb3NpdGlvbih2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0YXNrVGl0bGVQb3NpdGlvbicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLnRhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgdGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGUoKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YXNrVG9vbHRpcENvbnRlbnRUZW1wbGF0ZScpO1xyXG4gICAgfVxyXG4gICAgc2V0IHRhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMudG9vbGJhcl1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHRvb2xiYXIoKTogZHhHYW50dFRvb2xiYXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Rvb2xiYXInKTtcclxuICAgIH1cclxuICAgIHNldCB0b29sYmFyKHZhbHVlOiBkeEdhbnR0VG9vbGJhcikge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndG9vbGJhcicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLnZhbGlkYXRpb25dXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQElucHV0KClcclxuICAgIGdldCB2YWxpZGF0aW9uKCk6IHsgYXV0b1VwZGF0ZVBhcmVudFRhc2tzPzogYm9vbGVhbiwgZW5hYmxlUHJlZGVjZXNzb3JHYXA/OiBib29sZWFuLCB2YWxpZGF0ZURlcGVuZGVuY2llcz86IGJvb2xlYW4gfSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmFsaWRhdGlvbicpO1xyXG4gICAgfVxyXG4gICAgc2V0IHZhbGlkYXRpb24odmFsdWU6IHsgYXV0b1VwZGF0ZVBhcmVudFRhc2tzPzogYm9vbGVhbiwgZW5hYmxlUHJlZGVjZXNzb3JHYXA/OiBib29sZWFuLCB2YWxpZGF0ZURlcGVuZGVuY2llcz86IGJvb2xlYW4gfSkge1xyXG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmFsaWRhdGlvbicsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzY3I6V2lkZ2V0Lk9wdGlvbnMudmlzaWJsZV1cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IHZpc2libGUoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlzaWJsZScpO1xyXG4gICAgfVxyXG4gICAgc2V0IHZpc2libGUodmFsdWU6IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Zpc2libGUnLCB2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudC5PcHRpb25zLndpZHRoXVxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBJbnB1dCgpXHJcbiAgICBnZXQgd2lkdGgoKTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3dpZHRoJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgd2lkdGgodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3aWR0aCcsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOldpZGdldC5PcHRpb25zLm9uQ29udGVudFJlYWR5XVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uQ29udGVudFJlYWR5OiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vbkNvbnRleHRNZW51UHJlcGFyaW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uQ29udGV4dE1lbnVQcmVwYXJpbmc6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uQ3VzdG9tQ29tbWFuZF1cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvbkN1c3RvbUNvbW1hbmQ6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uRGVwZW5kZW5jeURlbGV0ZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25EZXBlbmRlbmN5RGVsZXRlZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25EZXBlbmRlbmN5RGVsZXRpbmddXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25EZXBlbmRlbmN5RGVsZXRpbmc6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uRGVwZW5kZW5jeUluc2VydGVkXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uRGVwZW5kZW5jeUluc2VydGVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vbkRlcGVuZGVuY3lJbnNlcnRpbmddXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25EZXBlbmRlbmN5SW5zZXJ0aW5nOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudC5PcHRpb25zLm9uRGlzcG9zaW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uRGlzcG9zaW5nOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOkNvbXBvbmVudC5PcHRpb25zLm9uSW5pdGlhbGl6ZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25Jbml0aWFsaXplZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnQuT3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25PcHRpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlQXNzaWduZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZUFzc2lnbmVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlQXNzaWduaW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VBc3NpZ25pbmc6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uUmVzb3VyY2VEZWxldGVkXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VEZWxldGVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlRGVsZXRpbmddXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZURlbGV0aW5nOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlSW5zZXJ0ZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZUluc2VydGVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlSW5zZXJ0aW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VJbnNlcnRpbmc6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uUmVzb3VyY2VVbmFzc2lnbmVkXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VVbmFzc2lnbmVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblJlc291cmNlVW5hc3NpZ25pbmddXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZVVuYXNzaWduaW5nOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblNlbGVjdGlvbkNoYW5nZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25TZWxlY3Rpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblRhc2tDbGlja11cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvblRhc2tDbGljazogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25UYXNrRGJsQ2xpY2tdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25UYXNrRGJsQ2xpY2s6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uVGFza0RlbGV0ZWRdXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25UYXNrRGVsZXRlZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25UYXNrRGVsZXRpbmddXHJcbiAgICBcclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgb25UYXNrRGVsZXRpbmc6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBbZGVzY3I6ZHhHYW50dC5PcHRpb25zLm9uVGFza0VkaXREaWFsb2dTaG93aW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uVGFza0VkaXREaWFsb2dTaG93aW5nOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblRhc2tJbnNlcnRlZF1cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvblRhc2tJbnNlcnRlZDogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25UYXNrSW5zZXJ0aW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uVGFza0luc2VydGluZzogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25UYXNrTW92aW5nXVxyXG4gICAgXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIG9uVGFza01vdmluZzogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFtkZXNjcjpkeEdhbnR0Lk9wdGlvbnMub25UYXNrVXBkYXRlZF1cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvblRhc2tVcGRhdGVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogW2Rlc2NyOmR4R2FudHQuT3B0aW9ucy5vblRhc2tVcGRhdGluZ11cclxuICAgIFxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBvblRhc2tVcGRhdGluZzogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGFjY2Vzc0tleUNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGFjdGl2ZVN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBhbGxvd1NlbGVjdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBjb2x1bW5zQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8RGV2RXhwcmVzcy51aS5keFRyZWVMaXN0Q29sdW1uIHwgc3RyaW5nPj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGNvbnRleHRNZW51Q2hhbmdlOiBFdmVudEVtaXR0ZXI8ZHhHYW50dENvbnRleHRNZW51PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZGVwZW5kZW5jaWVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBkYXRhU291cmNlPzogRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2UgfCBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZU9wdGlvbnMgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHByZWRlY2Vzc29ySWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN1Y2Nlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0eXBlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBkaXNhYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBlZGl0aW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhbGxvd0RlcGVuZGVuY3lBZGRpbmc/OiBib29sZWFuLCBhbGxvd0RlcGVuZGVuY3lEZWxldGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VBZGRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlRGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlVXBkYXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tBZGRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tEZWxldGluZz86IGJvb2xlYW4sIGFsbG93VGFza1Jlc291cmNlVXBkYXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tVcGRhdGluZz86IGJvb2xlYW4sIGVuYWJsZWQ/OiBib29sZWFuIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBlbGVtZW50QXR0ckNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIGZpcnN0RGF5T2ZXZWVrQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgc3RyaW5nPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgZm9jdXNTdGF0ZUVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBoaW50Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgaG92ZXJTdGF0ZUVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgcmVzb3VyY2VBc3NpZ25tZW50c0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCByZXNvdXJjZUlkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0YXNrSWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHJlc291cmNlc0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBEZXZFeHByZXNzLmRhdGEuRGF0YVNvdXJjZSB8IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlT3B0aW9ucyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgcm9vdFZhbHVlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgc2NhbGVUeXBlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWRSb3dLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBzaG93UmVzb3VyY2VzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHNob3dSb3dMaW5lc0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSBzdHJpcExpbmVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8RGV2RXhwcmVzcy51aS5keEdhbnR0U3RyaXBMaW5lPj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHRhYkluZGV4Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgdGFza0xpc3RXaWR0aENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHRhc2tzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb2xvckV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgZGF0YVNvdXJjZT86IERldkV4cHJlc3MuZGF0YS5EYXRhU291cmNlIHwgRGV2RXhwcmVzcy5kYXRhLkRhdGFTb3VyY2VPcHRpb25zIHwgQXJyYXk8YW55PiwgZW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHBhcmVudElkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcm9ncmVzc0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgc3RhcnRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRpdGxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgXHJcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxyXG4gICAgXHJcbiAgICAgKi9cclxuICAgIEBPdXRwdXQoKSB0YXNrVGl0bGVQb3NpdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHRhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgdG9vbGJhckNoYW5nZTogRXZlbnRFbWl0dGVyPGR4R2FudHRUb29sYmFyPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgdmFsaWRhdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPHsgYXV0b1VwZGF0ZVBhcmVudFRhc2tzPzogYm9vbGVhbiwgZW5hYmxlUHJlZGVjZXNzb3JHYXA/OiBib29sZWFuLCB2YWxpZGF0ZURlcGVuZGVuY2llcz86IGJvb2xlYW4gfT47XHJcblxyXG4gICAgLyoqXHJcbiAgICBcclxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXHJcbiAgICBcclxuICAgICAqL1xyXG4gICAgQE91dHB1dCgpIHZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcclxuXHJcbiAgICAvKipcclxuICAgIFxyXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cclxuICAgIFxyXG4gICAgICovXHJcbiAgICBAT3V0cHV0KCkgd2lkdGhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZz47XHJcblxyXG5cclxuXHJcblxyXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlDb2x1bW5Db21wb25lbnQpXHJcbiAgICBnZXQgY29sdW1uc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlDb2x1bW5Db21wb25lbnQ+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb2x1bW5zJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgY29sdW1uc0NoaWxkcmVuKHZhbHVlKSB7XHJcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignY29sdW1ucycsIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBAQ29udGVudENoaWxkcmVuKER4aVN0cmlwTGluZUNvbXBvbmVudClcclxuICAgIGdldCBzdHJpcExpbmVzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVN0cmlwTGluZUNvbXBvbmVudD4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3N0cmlwTGluZXMnKTtcclxuICAgIH1cclxuICAgIHNldCBzdHJpcExpbmVzQ2hpbGRyZW4odmFsdWUpIHtcclxuICAgICAgICB0aGlzLnNldENoaWxkcmVuKCdzdHJpcExpbmVzJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIG5nWm9uZTogTmdab25lLCB0ZW1wbGF0ZUhvc3Q6IER4VGVtcGxhdGVIb3N0LFxyXG4gICAgICAgICAgICBwcml2YXRlIF93YXRjaGVySGVscGVyOiBXYXRjaGVySGVscGVyLFxyXG4gICAgICAgICAgICBwcml2YXRlIF9pZGg6IEl0ZXJhYmxlRGlmZmVySGVscGVyLFxyXG4gICAgICAgICAgICBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gICAgICAgICAgICB0cmFuc2ZlclN0YXRlOiBUcmFuc2ZlclN0YXRlLFxyXG4gICAgICAgICAgICBASW5qZWN0KFBMQVRGT1JNX0lEKSBwbGF0Zm9ybUlkOiBhbnkpIHtcclxuXHJcbiAgICAgICAgc3VwZXIoZWxlbWVudFJlZiwgbmdab25lLCB0ZW1wbGF0ZUhvc3QsIF93YXRjaGVySGVscGVyLCB0cmFuc2ZlclN0YXRlLCBwbGF0Zm9ybUlkKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY3JlYXRlRXZlbnRFbWl0dGVycyhbXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY29udGVudFJlYWR5JywgZW1pdDogJ29uQ29udGVudFJlYWR5JyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NvbnRleHRNZW51UHJlcGFyaW5nJywgZW1pdDogJ29uQ29udGV4dE1lbnVQcmVwYXJpbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY3VzdG9tQ29tbWFuZCcsIGVtaXQ6ICdvbkN1c3RvbUNvbW1hbmQnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGVwZW5kZW5jeURlbGV0ZWQnLCBlbWl0OiAnb25EZXBlbmRlbmN5RGVsZXRlZCcgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkZXBlbmRlbmN5RGVsZXRpbmcnLCBlbWl0OiAnb25EZXBlbmRlbmN5RGVsZXRpbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGVwZW5kZW5jeUluc2VydGVkJywgZW1pdDogJ29uRGVwZW5kZW5jeUluc2VydGVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2RlcGVuZGVuY3lJbnNlcnRpbmcnLCBlbWl0OiAnb25EZXBlbmRlbmN5SW5zZXJ0aW5nJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2Rpc3Bvc2luZycsIGVtaXQ6ICdvbkRpc3Bvc2luZycgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpbml0aWFsaXplZCcsIGVtaXQ6ICdvbkluaXRpYWxpemVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ29wdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25PcHRpb25DaGFuZ2VkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlQXNzaWduZWQnLCBlbWl0OiAnb25SZXNvdXJjZUFzc2lnbmVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlQXNzaWduaW5nJywgZW1pdDogJ29uUmVzb3VyY2VBc3NpZ25pbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVzb3VyY2VEZWxldGVkJywgZW1pdDogJ29uUmVzb3VyY2VEZWxldGVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlRGVsZXRpbmcnLCBlbWl0OiAnb25SZXNvdXJjZURlbGV0aW5nJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlSW5zZXJ0ZWQnLCBlbWl0OiAnb25SZXNvdXJjZUluc2VydGVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlSW5zZXJ0aW5nJywgZW1pdDogJ29uUmVzb3VyY2VJbnNlcnRpbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVzb3VyY2VVbmFzc2lnbmVkJywgZW1pdDogJ29uUmVzb3VyY2VVbmFzc2lnbmVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlVW5hc3NpZ25pbmcnLCBlbWl0OiAnb25SZXNvdXJjZVVuYXNzaWduaW5nJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NlbGVjdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25TZWxlY3Rpb25DaGFuZ2VkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tDbGljaycsIGVtaXQ6ICdvblRhc2tDbGljaycgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrRGJsQ2xpY2snLCBlbWl0OiAnb25UYXNrRGJsQ2xpY2snIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndGFza0RlbGV0ZWQnLCBlbWl0OiAnb25UYXNrRGVsZXRlZCcgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrRGVsZXRpbmcnLCBlbWl0OiAnb25UYXNrRGVsZXRpbmcnIH0sXHJcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndGFza0VkaXREaWFsb2dTaG93aW5nJywgZW1pdDogJ29uVGFza0VkaXREaWFsb2dTaG93aW5nJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tJbnNlcnRlZCcsIGVtaXQ6ICdvblRhc2tJbnNlcnRlZCcgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrSW5zZXJ0aW5nJywgZW1pdDogJ29uVGFza0luc2VydGluZycgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrTW92aW5nJywgZW1pdDogJ29uVGFza01vdmluZycgfSxcclxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrVXBkYXRlZCcsIGVtaXQ6ICdvblRhc2tVcGRhdGVkJyB9LFxyXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tVcGRhdGluZycsIGVtaXQ6ICdvblRhc2tVcGRhdGluZycgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnYWNjZXNzS2V5Q2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdhY3RpdmVTdGF0ZUVuYWJsZWRDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2FsbG93U2VsZWN0aW9uQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdjb2x1bW5zQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdjb250ZXh0TWVudUNoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZGVwZW5kZW5jaWVzQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdkaXNhYmxlZENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZWRpdGluZ0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnZWxlbWVudEF0dHJDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ2ZpcnN0RGF5T2ZXZWVrQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdmb2N1c1N0YXRlRW5hYmxlZENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnaGVpZ2h0Q2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdoaW50Q2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdob3ZlclN0YXRlRW5hYmxlZENoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAncmVzb3VyY2VBc3NpZ25tZW50c0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAncmVzb3VyY2VzQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICdyb290VmFsdWVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3NjYWxlVHlwZUNoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnc2VsZWN0ZWRSb3dLZXlDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dSZXNvdXJjZXNDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dSb3dMaW5lc0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAnc3RyaXBMaW5lc0NoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAndGFiSW5kZXhDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rhc2tMaXN0V2lkdGhDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rhc2tzQ2hhbmdlJyB9LFxyXG4gICAgICAgICAgICB7IGVtaXQ6ICd0YXNrVGl0bGVQb3NpdGlvbkNoYW5nZScgfSxcclxuICAgICAgICAgICAgeyBlbWl0OiAndGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rvb2xiYXJDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZhbGlkYXRpb25DaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVDaGFuZ2UnIH0sXHJcbiAgICAgICAgICAgIHsgZW1pdDogJ3dpZHRoQ2hhbmdlJyB9XHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lkaC5zZXRIb3N0KHRoaXMpO1xyXG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgX2NyZWF0ZUluc3RhbmNlKGVsZW1lbnQsIG9wdGlvbnMpIHtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ldyBEeEdhbnR0KGVsZW1lbnQsIG9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpIHtcclxuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG4gICAgICAgIHN1cGVyLm5nT25DaGFuZ2VzKGNoYW5nZXMpO1xyXG4gICAgICAgIHRoaXMuc2V0dXBDaGFuZ2VzKCdjb2x1bW5zJywgY2hhbmdlcyk7XHJcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ3N0cmlwTGluZXMnLCBjaGFuZ2VzKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXR1cENoYW5nZXMocHJvcDogc3RyaW5nLCBjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcbiAgICAgICAgaWYgKCEocHJvcCBpbiB0aGlzLl9vcHRpb25zVG9VcGRhdGUpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lkaC5zZXR1cChwcm9wLCBjaGFuZ2VzKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdEb0NoZWNrKCkge1xyXG4gICAgICAgIHRoaXMuX2lkaC5kb0NoZWNrKCdjb2x1bW5zJyk7XHJcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ3N0cmlwTGluZXMnKTtcclxuICAgICAgICB0aGlzLl93YXRjaGVySGVscGVyLmNoZWNrV2F0Y2hlcnMoKTtcclxuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcclxuICAgICAgICBzdXBlci5jbGVhckNoYW5nZWRPcHRpb25zKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX3NldE9wdGlvbihuYW1lOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcclxuICAgICAgICBsZXQgaXNTZXR1cCA9IHRoaXMuX2lkaC5zZXR1cFNpbmdsZShuYW1lLCB2YWx1ZSk7XHJcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcclxuXHJcbiAgICAgICAgaWYgKGlzU2V0dXAgfHwgaXNDaGFuZ2VkKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBEeGlDb2x1bW5Nb2R1bGUsXHJcbiAgICBEeGlCdXR0b25Nb2R1bGUsXHJcbiAgICBEeG9IZWFkZXJGaWx0ZXJNb2R1bGUsXHJcbiAgICBEeG9Mb29rdXBNb2R1bGUsXHJcbiAgICBEeG9Gb3JtYXRNb2R1bGUsXHJcbiAgICBEeG9Gb3JtSXRlbU1vZHVsZSxcclxuICAgIER4b0xhYmVsTW9kdWxlLFxyXG4gICAgRHhpVmFsaWRhdGlvblJ1bGVNb2R1bGUsXHJcbiAgICBEeG9Db250ZXh0TWVudU1vZHVsZSxcclxuICAgIER4aUl0ZW1Nb2R1bGUsXHJcbiAgICBEeG9EZXBlbmRlbmNpZXNNb2R1bGUsXHJcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxyXG4gICAgRHhvUmVzb3VyY2VBc3NpZ25tZW50c01vZHVsZSxcclxuICAgIER4b1Jlc291cmNlc01vZHVsZSxcclxuICAgIER4aVN0cmlwTGluZU1vZHVsZSxcclxuICAgIER4b1Rhc2tzTW9kdWxlLFxyXG4gICAgRHhvVG9vbGJhck1vZHVsZSxcclxuICAgIER4b1ZhbGlkYXRpb25Nb2R1bGUsXHJcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxyXG4gICAgRHhUZW1wbGF0ZU1vZHVsZSxcclxuICAgIEJyb3dzZXJUcmFuc2ZlclN0YXRlTW9kdWxlXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIER4R2FudHRDb21wb25lbnRcclxuICBdLFxyXG4gIGV4cG9ydHM6IFtcclxuICAgIER4R2FudHRDb21wb25lbnQsXHJcbiAgICBEeGlDb2x1bW5Nb2R1bGUsXHJcbiAgICBEeGlCdXR0b25Nb2R1bGUsXHJcbiAgICBEeG9IZWFkZXJGaWx0ZXJNb2R1bGUsXHJcbiAgICBEeG9Mb29rdXBNb2R1bGUsXHJcbiAgICBEeG9Gb3JtYXRNb2R1bGUsXHJcbiAgICBEeG9Gb3JtSXRlbU1vZHVsZSxcclxuICAgIER4b0xhYmVsTW9kdWxlLFxyXG4gICAgRHhpVmFsaWRhdGlvblJ1bGVNb2R1bGUsXHJcbiAgICBEeG9Db250ZXh0TWVudU1vZHVsZSxcclxuICAgIER4aUl0ZW1Nb2R1bGUsXHJcbiAgICBEeG9EZXBlbmRlbmNpZXNNb2R1bGUsXHJcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxyXG4gICAgRHhvUmVzb3VyY2VBc3NpZ25tZW50c01vZHVsZSxcclxuICAgIER4b1Jlc291cmNlc01vZHVsZSxcclxuICAgIER4aVN0cmlwTGluZU1vZHVsZSxcclxuICAgIER4b1Rhc2tzTW9kdWxlLFxyXG4gICAgRHhvVG9vbGJhck1vZHVsZSxcclxuICAgIER4b1ZhbGlkYXRpb25Nb2R1bGUsXHJcbiAgICBEeFRlbXBsYXRlTW9kdWxlXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRHhHYW50dE1vZHVsZSB7IH1cclxuIl19